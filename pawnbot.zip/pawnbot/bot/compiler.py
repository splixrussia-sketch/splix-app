"""Запуск pawncc в песочнице (отдельный процесс, лимиты, чистое окружение, таймаут) и разбор вывода."""
from __future__ import annotations

import asyncio
import os
import re
import resource
import time
from dataclasses import dataclass, field
from pathlib import Path

from .config import Config
from .includes import SHIM_DIR, cleanup_includes, prepare_includes
from .modtools import include_dirs, read_flags

DIAG_RE = re.compile(
    r"^(?P<file>.+?)\((?P<line>\d+)(?:\s*--\s*\d+)?\)\s*:\s*(?P<kind>fatal error|error|warning)\s+(?P<code>\d+):\s*(?P<msg>.*)$"
)


@dataclass
class Diag:
    file: str
    line: int
    kind: str  # error | warning | fatal error
    code: int
    msg: str

    @property
    def is_error(self) -> bool:
        return self.kind != "warning"

    def short(self) -> str:
        return f"{self.file}({self.line}): {self.kind} {self.code:03d}: {self.msg}"


@dataclass
class CompileResult:
    ok: bool
    amx_rel: str
    diags: list[Diag] = field(default_factory=list)
    raw: str = ""
    seconds: float = 0.0
    timed_out: bool = False
    missing_includes: list[str] = field(default_factory=list)

    @property
    def errors(self) -> list[Diag]:
        return [d for d in self.diags if d.is_error]

    @property
    def warnings(self) -> list[Diag]:
        return [d for d in self.diags if not d.is_error]


def parse_output(raw: str, root: Path | None = None) -> list[Diag]:
    out: list[Diag] = []
    prefix = str(root) + "/" if root else None
    for line in raw.splitlines():
        m = DIAG_RE.match(line.strip())
        if not m:
            continue
        f = m["file"].strip()
        if prefix and f.startswith(prefix):
            f = f[len(prefix):]
        f = f[2:] if f.startswith("./") else f
        out.append(Diag(f, int(m["line"]), m["kind"], int(m["code"]), m["msg"].strip()))
        if len(out) >= 800:
            break
    return out


def _limits():
    resource.setrlimit(resource.RLIMIT_CPU, (600, 600))
    resource.setrlimit(resource.RLIMIT_AS, (3 << 30, 3 << 30))
    resource.setrlimit(resource.RLIMIT_FSIZE, (512 << 20, 512 << 20))
    os.setsid()


_sem: asyncio.Semaphore | None = None


async def compile_mod(cfg: Config, root: Path, main_rel: str) -> CompileResult:
    global _sem
    if _sem is None:
        _sem = asyncio.Semaphore(cfg.compile_concurrency)
    amx_rel = Path(main_rel).with_suffix(".amx").as_posix()
    (root / amx_rel).unlink(missing_ok=True)
    shimmed, missing = prepare_includes(root)
    args = [
        cfg.pawncc_path,
        main_rel,
        f"-o{amx_rel}",
        *[f"-i{d}" for d in include_dirs(root)],
        *([f"-i{SHIM_DIR}"] if shimmed else []),
        *read_flags(root),
    ]
    env = {"PATH": "/usr/local/bin:/usr/bin:/bin", "HOME": "/tmp", "LANG": "C.UTF-8"}
    lib = Path(cfg.pawncc_path).resolve().parent.parent / "lib"
    if lib.is_dir():
        env["LD_LIBRARY_PATH"] = str(lib)

    try:
        return await _run(cfg, root, args, env, amx_rel, missing)
    finally:
        cleanup_includes(root)


async def _run(cfg, root, args, env, amx_rel, missing) -> CompileResult:
    async with _sem:
        t0 = time.monotonic()
        try:
            proc = await asyncio.create_subprocess_exec(
                *args,
                cwd=str(root),
                env=env,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
                preexec_fn=_limits,
            )
        except FileNotFoundError:
            return CompileResult(False, amx_rel, [], f"pawncc не найден по пути {cfg.pawncc_path}")
        try:
            out, _ = await asyncio.wait_for(proc.communicate(), timeout=cfg.compile_timeout)
            timed_out = False
        except asyncio.TimeoutError:
            proc.kill()
            await proc.wait()
            out, timed_out = b"", True
        seconds = time.monotonic() - t0

    raw = out.decode("cp1251", errors="replace")
    diags = parse_output(raw, root)
    ok = (not timed_out) and proc.returncode == 0 and (root / amx_rel).is_file()
    return CompileResult(ok, amx_rel, diags, raw, seconds, timed_out, missing)
