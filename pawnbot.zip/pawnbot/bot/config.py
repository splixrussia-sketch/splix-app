from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

try:
    from dotenv import load_dotenv

    load_dotenv()
except ImportError:  # .env может подгружаться самим docker compose
    pass


def _int(name: str, default: int) -> int:
    v = os.getenv(name, "").strip()
    return int(v) if v else default


@dataclass(frozen=True)
class Config:
    bot_token: str
    owner_id: int
    data_dir: Path
    pawncc_path: str
    ai_provider: str  # anthropic | openai
    ai_api_key: str
    ai_model: str
    ai_base_url: str
    max_zip_mb: int
    max_unpacked_mb: int
    max_files: int
    compile_timeout: int
    compile_concurrency: int
    ai_max_rounds: int
    telegram_api_url: str
    webapp_url: str = ""
    webapp_port: int = 8080


def load_config() -> Config:
    token = os.getenv("BOT_TOKEN", "").strip()
    if not token:
        raise SystemExit("BOT_TOKEN не задан. Скопируй .env.example в .env и заполни.")
    owner = _int("OWNER_ID", 0)
    if not owner:
        raise SystemExit("OWNER_ID не задан.")
    provider = os.getenv("AI_PROVIDER", "anthropic").strip().lower()
    default_url = "https://api.anthropic.com" if provider == "anthropic" else "https://api.openai.com/v1"
    data_dir = Path(os.getenv("DATA_DIR", "data")).resolve()
    data_dir.mkdir(parents=True, exist_ok=True)
    return Config(
        bot_token=token,
        owner_id=owner,
        data_dir=data_dir,
        pawncc_path=os.getenv("PAWNCC_PATH", "/opt/pawn/bin/pawncc"),
        ai_provider=provider,
        ai_api_key=os.getenv("AI_API_KEY", "").strip(),
        ai_model=os.getenv("AI_MODEL", "claude-sonnet-5-5").strip(),
        ai_base_url=os.getenv("AI_BASE_URL", default_url).strip().rstrip("/"),
        max_zip_mb=_int("MAX_ZIP_MB", 20),
        max_unpacked_mb=_int("MAX_UNPACKED_MB", 400),
        max_files=_int("MAX_FILES", 5000),
        compile_timeout=_int("COMPILE_TIMEOUT", 300),
        compile_concurrency=_int("COMPILE_CONCURRENCY", 2),
        ai_max_rounds=_int("AI_MAX_ROUNDS", 12),
        telegram_api_url=os.getenv("TELEGRAM_API_URL", "").strip(),
        webapp_url=os.getenv("WEBAPP_URL", "").strip().rstrip("/"),
        webapp_port=_int("WEBAPP_PORT", 8080),
    )
