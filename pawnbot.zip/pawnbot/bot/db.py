from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

import aiosqlite

SCHEMA = """
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY, username TEXT, first_name TEXT,
  balance INTEGER NOT NULL DEFAULT 0,
  referrer_id INTEGER, ref_counted INTEGER NOT NULL DEFAULT 0, ref_count INTEGER NOT NULL DEFAULT 0,
  joined_at TEXT NOT NULL, last_seen TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS admins(user_id INTEGER PRIMARY KEY);
CREATE TABLE IF NOT EXISTS promos(
  code TEXT PRIMARY KEY, requests INTEGER NOT NULL, max_uses INTEGER NOT NULL, used INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS promo_uses(code TEXT NOT NULL, user_id INTEGER NOT NULL, PRIMARY KEY(code, user_id));
CREATE TABLE IF NOT EXISTS channels(chat_id INTEGER PRIMARY KEY, title TEXT NOT NULL, link TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS mods(
  user_id INTEGER PRIMARY KEY, name TEXT NOT NULL, root TEXT NOT NULL, zip_path TEXT NOT NULL,
  main_file TEXT NOT NULL, size INTEGER NOT NULL DEFAULT 0, uploaded_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS events(
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, action TEXT NOT NULL, ok INTEGER NOT NULL, ts TEXT NOT NULL);
"""


def now_str() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")


@dataclass
class User:
    id: int
    username: str | None
    first_name: str | None
    balance: int
    referrer_id: int | None
    ref_count: int


@dataclass
class Mod:
    user_id: int
    name: str
    root: str
    zip_path: str
    main_file: str
    size: int
    uploaded_at: str


@dataclass
class Channel:
    chat_id: int
    title: str
    link: str


_USER_COLS = "id,username,first_name,balance,referrer_id,ref_count"
_MOD_COLS = "user_id,name,root,zip_path,main_file,size,uploaded_at"


class DB:
    def __init__(self, path):
        self.path = str(path)
        self.conn: aiosqlite.Connection | None = None
        self.owner_id = 0

    async def init(self, owner_id: int) -> None:
        self.owner_id = owner_id
        self.conn = await aiosqlite.connect(self.path)
        await self.conn.execute("PRAGMA journal_mode=WAL")
        await self.conn.executescript(SCHEMA)
        await self.conn.commit()

    async def _x(self, sql: str, args: tuple = ()) -> int:
        cur = await self.conn.execute(sql, args)
        await self.conn.commit()
        return cur.rowcount

    async def _all(self, sql: str, args: tuple = ()):
        cur = await self.conn.execute(sql, args)
        return await cur.fetchall()

    async def _one(self, sql: str, args: tuple = ()):
        cur = await self.conn.execute(sql, args)
        return await cur.fetchone()

    # ---------- users ----------
    async def upsert_user(self, uid: int, username: str | None, first_name: str | None, ref: int | None = None) -> bool:
        if ref == uid or (ref and not await self._one("SELECT 1 FROM users WHERE id=?", (ref,))):
            ref = None
        n = await self._x(
            "INSERT OR IGNORE INTO users(id,username,first_name,referrer_id,joined_at,last_seen) VALUES(?,?,?,?,?,?)",
            (uid, username, first_name, ref, now_str(), now_str()),
        )
        if n == 0:
            await self._x(
                "UPDATE users SET username=?, first_name=?, last_seen=? WHERE id=?",
                (username, first_name, now_str(), uid),
            )
        return n == 1

    async def get_user(self, uid: int) -> User | None:
        r = await self._one(f"SELECT {_USER_COLS} FROM users WHERE id=?", (uid,))
        return User(*r) if r else None

    async def find_user(self, key: str) -> User | None:
        key = key.strip()
        if key.lstrip("-").isdigit():
            return await self.get_user(int(key))
        r = await self._one(f"SELECT {_USER_COLS} FROM users WHERE lower(username)=?", (key.lstrip("@").lower(),))
        return User(*r) if r else None

    async def all_user_ids(self) -> list[int]:
        return [r[0] for r in await self._all("SELECT id FROM users")]

    async def add_balance(self, uid: int, n: int) -> None:
        await self._x("UPDATE users SET balance=MAX(0,balance+?) WHERE id=?", (n, uid))

    async def add_balance_all(self, n: int) -> int:
        return await self._x("UPDATE users SET balance=MAX(0,balance+?)", (n,))

    async def spend(self, uid: int, n: int = 1) -> bool:
        return await self._x("UPDATE users SET balance=balance-? WHERE id=? AND balance>=?", (n, uid, n)) == 1

    async def is_admin(self, uid: int) -> bool:
        if uid == self.owner_id:
            return True
        return await self._one("SELECT 1 FROM admins WHERE user_id=?", (uid,)) is not None

    async def has_access(self, uid: int) -> bool:
        if await self.is_admin(uid):
            return True
        u = await self.get_user(uid)
        return bool(u and u.balance > 0)

    async def list_admins(self) -> list[int]:
        return [r[0] for r in await self._all("SELECT user_id FROM admins ORDER BY user_id")]

    async def toggle_admin(self, uid: int) -> bool:
        """True — добавлен, False — удалён."""
        if await self._x("DELETE FROM admins WHERE user_id=?", (uid,)):
            return False
        await self._x("INSERT OR IGNORE INTO admins(user_id) VALUES(?)", (uid,))
        return True

    # ---------- referrals ----------
    async def credit_referral(self, uid: int):
        """Засчитывает приглашение (один раз). Возвращает (referrer_id, count, rewarded) или None."""
        r = await self._one("SELECT referrer_id, ref_counted FROM users WHERE id=?", (uid,))
        if not r or not r[0] or r[1]:
            return None
        ref = r[0]
        await self._x("UPDATE users SET ref_counted=1 WHERE id=?", (uid,))
        await self._x("UPDATE users SET ref_count=ref_count+1 WHERE id=?", (ref,))
        cnt = (await self._one("SELECT ref_count FROM users WHERE id=?", (ref,)))[0]
        rewarded = cnt % 5 == 0
        if rewarded:
            await self.add_balance(ref, 2)
        return ref, cnt, rewarded

    # ---------- promo ----------
    async def create_promo(self, code: str, requests: int, max_uses: int) -> bool:
        n = await self._x(
            "INSERT OR IGNORE INTO promos(code,requests,max_uses) VALUES(?,?,?)", (code.upper(), requests, max_uses)
        )
        return n == 1

    async def activate_promo(self, code: str, uid: int) -> tuple[str, int]:
        code = code.strip().upper()
        p = await self._one("SELECT requests,max_uses,used FROM promos WHERE code=?", (code,))
        if not p:
            return "none", 0
        if p[2] >= p[1]:
            return "exhausted", 0
        if await self._one("SELECT 1 FROM promo_uses WHERE code=? AND user_id=?", (code, uid)):
            return "used", 0
        await self._x("INSERT INTO promo_uses(code,user_id) VALUES(?,?)", (code, uid))
        await self._x("UPDATE promos SET used=used+1 WHERE code=?", (code,))
        await self.add_balance(uid, p[0])
        return "ok", p[0]

    # ---------- channels ----------
    async def add_channel(self, chat_id: int, title: str, link: str) -> None:
        await self._x("INSERT OR REPLACE INTO channels(chat_id,title,link) VALUES(?,?,?)", (chat_id, title, link))

    async def del_channel(self, chat_id: int) -> None:
        await self._x("DELETE FROM channels WHERE chat_id=?", (chat_id,))

    async def list_channels(self) -> list[Channel]:
        return [Channel(*r) for r in await self._all("SELECT chat_id,title,link FROM channels")]

    # ---------- mods ----------
    async def save_mod(self, m: Mod) -> None:
        await self._x(
            f"INSERT OR REPLACE INTO mods({_MOD_COLS}) VALUES(?,?,?,?,?,?,?)",
            (m.user_id, m.name, m.root, m.zip_path, m.main_file, m.size, m.uploaded_at or now_str()),
        )

    async def get_mod(self, uid: int) -> Mod | None:
        r = await self._one(f"SELECT {_MOD_COLS} FROM mods WHERE user_id=?", (uid,))
        return Mod(*r) if r else None

    async def list_mods(self, offset: int = 0, limit: int = 8) -> list[Mod]:
        rows = await self._all(
            f"SELECT {_MOD_COLS} FROM mods ORDER BY uploaded_at DESC LIMIT ? OFFSET ?", (limit, offset)
        )
        return [Mod(*r) for r in rows]

    async def count_mods(self) -> int:
        return (await self._one("SELECT COUNT(*) FROM mods"))[0]

    # ---------- stats ----------
    async def log(self, uid: int, action: str, ok: bool) -> None:
        await self._x("INSERT INTO events(user_id,action,ok,ts) VALUES(?,?,?,?)", (uid, action, int(ok), now_str()))

    async def user_stats(self, uid: int) -> dict:
        """Личная статистика для экрана «Профиль»: {'acts': {action: (ok, total)}, 'joined': 'YYYY-MM-DD ...'}."""
        rows = await self._all("SELECT action, SUM(ok), COUNT(*) FROM events WHERE user_id=? GROUP BY action", (uid,))
        j = await self._one("SELECT joined_at FROM users WHERE id=?", (uid,))
        return {"acts": {a: (int(ok or 0), int(t)) for a, ok, t in rows}, "joined": j[0] if j else ""}

    async def stats(self) -> dict:
        def ago(**kw) -> str:
            return (datetime.now(timezone.utc) - timedelta(**kw)).strftime("%Y-%m-%d %H:%M:%S")

        users = (await self._one("SELECT COUNT(*) FROM users"))[0]
        day = (await self._one("SELECT COUNT(*) FROM users WHERE last_seen>=?", (ago(days=1),)))[0]
        live = (await self._one("SELECT COUNT(*) FROM users WHERE last_seen>=?", (ago(minutes=15),)))[0]
        acts = await self._all("SELECT action, SUM(ok), COUNT(*) FROM events GROUP BY action ORDER BY COUNT(*) DESC")
        return {
            "users": users,
            "day": day,
            "live": live,
            "mods": await self.count_mods(),
            "channels": len(await self.list_channels()),
            "acts": acts,
        }
