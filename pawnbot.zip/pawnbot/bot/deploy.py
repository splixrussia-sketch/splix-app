"""Конвейер «собрать мод → залить на FTP». Один общий менеджер для бота и Mini App.

Состояние задачи живёт в памяти: интерфейсы только опрашивают его (таймер, прогресс, логи).
Пароль хранится лишь на время задачи и стирается после неё.
"""
from __future__ import annotations

import asyncio
import logging
import re
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path

from .ai import AIFixer
from .config import Config
from .db import DB
from .fixer import autofix
from .ftpdeploy import (
    FtpError,
    FtpTarget,
    check_credentials,
    collect,
    normalize_remote,
    parse_host,
    resolve_public,
    upload_tree,
)
from .modtools import ModError, Workspace

log = logging.getLogger("deploy")

LOG_KEEP = 400
JOB_TTL = 3600


@dataclass
class Job:
    uid: int
    label: str  # host:port
    remote_dir: str
    amx_only: bool
    started: float = field(default_factory=time.time)
    finished: float | None = None
    stage: str = "compile"  # compile | upload | done
    state: str = "running"  # running | ok | failed | cancelled
    pct: float = 2.0
    note: str = ""
    error: str = ""
    files_done: int = 0
    files_total: int = 0
    bytes_done: int = 0
    bytes_total: int = 0
    secure: bool = False
    up_started: float | None = None
    result: dict = field(default_factory=dict)
    cancel: threading.Event = field(default_factory=threading.Event)
    _log: list[dict] = field(default_factory=list)
    _n: int = 0
    _lock: threading.Lock = field(default_factory=threading.Lock)
    _secret: str = ""

    # ---- лог ----
    def add(self, level: str, text: str) -> None:
        if self._secret and len(self._secret) >= 4:
            text = text.replace(self._secret, "••••")
        with self._lock:
            self._n += 1
            self._log.append({"i": self._n, "t": round(time.time() - self.started, 1), "lv": level, "m": text[:300]})
            if len(self._log) > LOG_KEEP:
                del self._log[: len(self._log) - LOG_KEEP]

    def lines(self, since: int = 0) -> list[dict]:
        with self._lock:
            return [x for x in self._log if x["i"] > since]

    def tail(self, n: int = 5) -> list[dict]:
        with self._lock:
            return list(self._log[-n:])

    @property
    def running(self) -> bool:
        return self.finished is None

    @property
    def elapsed(self) -> float:
        return (self.finished or time.time()) - self.started

    def snapshot(self, since: int = 0) -> dict:
        lines = self.lines(since)
        return {
            "state": self.state,
            "stage": self.stage,
            "pct": round(self.pct, 1),
            "note": self.note,
            "label": self.label,
            "remote_dir": self.remote_dir,
            "amx_only": self.amx_only,
            "started": self.started,
            "elapsed": round(self.elapsed, 1),
            "now": time.time(),
            "files": [self.files_done, self.files_total],
            "bytes": [self.bytes_done, self.bytes_total],
            "secure": self.secure,
            "up_started": self.up_started,
            "error": self.error,
            "result": self.result,
            "log": lines,
            "next": lines[-1]["i"] if lines else since,
        }

    def full_log_text(self) -> str:
        with self._lock:
            rows = [f"[{x['t']:7.1f}s] {x['lv'].upper():4} {x['m']}" for x in self._log]
        head = f"Pawn Forge · заливка на {self.label}{self.remote_dir if self.remote_dir != '/' else ''}\n"
        return head + "\n".join(rows) + "\n"


def _compile_pct(text: str) -> float:
    m = re.search(r"попытка (\d+)", text)
    n = int(m[1]) if m else 1
    if "ИИ" in text:
        return min(14 + n * 3, 42)
    if "Компиляция" in text:
        return min(8 + n * 3, 38)
    return 6


def _strip(text: str) -> str:
    return re.sub(r"<[^>]+>", "", text).strip()


class DeployManager:
    def __init__(self, cfg: Config, db: DB, ai: AIFixer, busy: set[int]):
        self.cfg, self.db, self.ai, self.busy = cfg, db, ai, busy
        self.jobs: dict[int, Job] = {}
        self._tasks: set[asyncio.Task] = set()

    def get(self, uid: int) -> Job | None:
        self._gc()
        return self.jobs.get(uid)

    def _gc(self) -> None:
        now = time.time()
        for uid, j in list(self.jobs.items()):
            if j.finished and now - j.finished > JOB_TTL:
                del self.jobs[uid]

    async def start(self, uid: int, host_raw: str, port: int | None, user: str, password: str, path: str, amx_only: bool) -> Job:
        """Проверяет данные и запускает задачу. Бросает FtpError с текстом для пользователя."""
        host, parsed_port, parsed_path = parse_host(host_raw)
        port = port if port is not None else parsed_port
        if not (port == 21 or 1024 <= port <= 65535):
            raise FtpError("Порт должен быть 21 или в диапазоне 1024–65535.")
        check_credentials(user, password)
        remote = normalize_remote(path or parsed_path)
        if uid in self.busy or (self.jobs.get(uid) and self.jobs[uid].running):
            raise FtpError("Предыдущая операция ещё выполняется — подождите.")
        admin = await self.db.is_admin(uid)
        if not (admin or await self.db.has_access(uid)):
            raise FtpError("Нет доступа: нужен хотя бы 1 запрос.")
        mod = await self.db.get_mod(uid)
        if not mod:
            raise FtpError("Сначала загрузите мод.")
        ip = await asyncio.to_thread(resolve_public, host, port)

        tgt = FtpTarget(host, port, user, password, remote, ip)
        job = Job(uid, f"{host}:{port}", remote, amx_only)
        job._secret = password
        self.jobs[uid] = job
        self.busy.add(uid)
        t = asyncio.create_task(self._run(job, tgt, admin))
        self._tasks.add(t)
        t.add_done_callback(self._tasks.discard)
        return job

    async def _run(self, job: Job, tgt: FtpTarget, admin: bool) -> None:
        uid = job.uid
        ok = False
        ws = None
        try:
            mod = await self.db.get_mod(uid)
            ws = Workspace(Path(mod.root))
            job.add("info", "🛠 Собираю мод (pawncc)…")
            last = [""]

            async def progress(text: str) -> None:
                t = _strip(text)
                job.note = t[:90]
                job.pct = max(job.pct, _compile_pct(t))
                if t and t != last[0]:
                    last[0] = t
                    job.add("info", t[:160])

            rep = await autofix(self.cfg, self.ai, ws, mod.main_file, progress, set(), "")
            if not rep.ok:
                ws.rollback()
                errs = (rep.result.errors[:3] if rep.result else [])
                for d in errs:
                    job.add("err", d.short()[:200])
                job.error = "Мод не собрался — заливать нечего. " + (rep.reason.split("\n")[0][:160] if rep.reason else "")
                raise FtpError(job.error)
            res = rep.result
            job.add("ok", f"✅ Мод собран за {res.seconds:.0f} с · попыток: {rep.rounds} · предупреждений: {len(res.warnings)}")
            for c in rep.changes[:4]:
                job.add("info", f"🔧 {c[:140]}")
            job.pct = 45.0
            if job.cancel.is_set():
                raise FtpError("Остановлено пользователем.")

            job.stage, job.note, job.up_started = "upload", "Подключение к серверу…", time.time()
            files = await asyncio.to_thread(
                collect, ws.root, res.amx_rel if job.amx_only else None, self.cfg.max_files, self.cfg.max_unpacked_mb << 20
            )
            job.files_total, job.bytes_total = len(files), sum(f.size for f in files)

            def on_progress(bd: int, bt: int, fd: int, ft: int, cur: str) -> None:
                job.bytes_done, job.files_done, job.note = bd, fd, cur
                job.pct = 45 + 55 * (bd / bt if bt else 1)

            up = await asyncio.to_thread(upload_tree, tgt, files, job.add, on_progress, job.cancel)
            job.secure = up.secure
            job.files_done, job.bytes_done, job.pct = up.files, up.bytes, 100.0
            job.result = {
                "files": up.files,
                "bytes": up.bytes,
                "seconds": round(job.elapsed, 1),
                "speed": round(up.speed),
                "secure": up.secure,
                "amx": res.amx_rel,
            }
            job.add("ok", f"🎉 Готово! Залито файлов: {up.files}")
            ok = True
            job.state, job.stage = "ok", "done"
            if not admin:
                await self.db.spend(uid)
        except FtpError as e:
            if job.cancel.is_set():
                job.state, job.error = "cancelled", "Остановлено."
                job.add("warn", "⏹ Остановлено пользователем")
            else:
                job.state, job.error = "failed", job.error or str(e)
                job.add("err", f"❌ {e}")
        except ModError as e:
            job.state, job.error = "failed", str(e)
            job.add("err", f"❌ {e}")
        except Exception:
            log.exception("deploy failed")
            job.state, job.error = "failed", "Внутренняя ошибка. Попробуйте ещё раз."
            job.add("err", "❌ Внутренняя ошибка")
        finally:
            if job.state == "running":
                job.state = "failed"
            tgt.password = ""
            job._secret = ""
            job.finished = time.time()
            try:
                await self.db.log(uid, "deploy", ok)
            except Exception:
                pass
            self.busy.discard(uid)
