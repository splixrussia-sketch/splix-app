"""Цикл «компиляция → разбор лога → правка → повтор». Сначала детерминированные фиксы, потом ИИ."""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Awaitable, Callable

from .ai import AIFixer, describe_ai_error
from .compiler import CompileResult, compile_mod
from .config import Config
from .modtools import Workspace
from .pawnsrc import func_span

Progress = Callable[[str], Awaitable[None]]


@dataclass
class FixReport:
    ok: bool
    rounds: int = 0
    changes: list[str] = field(default_factory=list)
    attempts: list[str] = field(default_factory=list)  # все правки ИИ, в том числе откатанные
    result: CompileResult | None = None
    reason: str = ""


def _rename_symbol(ws: Workspace, rel: str, name: str, prefix: str) -> bool:
    new = prefix + name
    if len(new) > 31 or name.startswith(prefix):
        return False
    text = ws.read(rel)
    pat = re.compile(rf"(?<![\w@]){re.escape(name)}(?![\w@])")
    if not pat.search(text):
        return False
    ws.write(rel, pat.sub(new, text))
    return True


_BARE_RET = re.compile(r"\breturn\s*;")
def _fix_mixed_return(ws: Workspace, rel: str, line_no: int) -> int:
    """Ошибка 078 (pawncc 3.10 строже старых): в функции есть и «return;», и «return значение;».
    Находим функцию по скобкам и заменяем «return;» на «return 0;». Возвращает число замен."""
    text = ws.read(rel)
    lines = text.split("\n")
    i = min(max(line_no - 1, 0), len(lines) - 1)
    span = func_span(lines, i)
    if span is None:
        span = (max(i - 3, 0), min(i + 3, len(lines) - 1))  # запасной вариант: рядом со строкой ошибки
    n = 0
    for x in range(span[0], span[1] + 1):
        code, sep, comment = lines[x].partition("//")
        new, c = _BARE_RET.subn("return 0;", code)
        if c:
            lines[x] = new + sep + comment
            n += c
    if n:
        ws.write(rel, "\n".join(lines))
    return n


_SELF_INIT = re.compile(r"^(\s*)(new|static)\s+((?:[A-Za-z_@][\w@]*:)?)([A-Za-z_@][\w@]*)\s*=\s*(.+?);(\s*//[^\r]*)?(\r?)$")


def _fix_self_init(ws: Workspace, rel: str, line_no: int, name: str) -> bool:
    """Ошибка 017 на «new x = F(x);»: старый компилятор видел x внутри собственного инициализатора, pawncc 3.10 — нет.
    Делаем «new x = 0;» + «x = F(x);» — компилируется везде и ведёт себя как раньше."""
    text = ws.read(rel)
    lines = text.split("\n")
    if not 1 <= line_no <= len(lines):
        return False
    m = _SELF_INIT.match(lines[line_no - 1])
    if not m or m[4] != name or not re.search(rf"(?<![\w@]){re.escape(name)}(?![\w@])", m[5]):
        return False
    indent, kw, tag, nm, expr, comment, cr = m.groups()
    zero = "0.0" if tag.lower() == "float:" else "0"
    lines[line_no - 1:line_no] = [f"{indent}{kw} {tag}{nm} = {zero};{cr}", f"{indent}{nm} = {expr};{comment or ''}{cr}"]
    ws.write(rel, "\n".join(lines))
    return True


_DECL = re.compile(r"^\s*(native|forward)\b[^\r]*;\s*(//[^\r]*)?\r?$")


def _fix_dup_decl(ws: Workspace, rel: str, line_no: int) -> bool:
    """Ошибка 021 на строке «native X(...);» / «forward X(...);»: повторное объявление (один и тот же инклюд
    подключён дважды разными путями). Повтор безопасно закомментировать."""
    lines = ws.read(rel).split("\n")
    if not 1 <= line_no <= len(lines) or not _DECL.match(lines[line_no - 1]):
        return False
    lines[line_no - 1] = "// [splixbot: дубликат] " + lines[line_no - 1]
    ws.write(rel, "\n".join(lines))
    return True


async def _autofix(
    cfg: Config,
    ai: AIFixer,
    ws: Workspace,
    main_rel: str,
    progress: Progress,
    own_files: set[str] | None = None,
    prefix: str = "",
) -> FixReport:
    """own_files — файлы только что вшитой системы: в них разрешены детерминированные переименования."""
    rep = FixReport(ok=False)
    prev_sig = None
    pending = None  # (checkpoint, число ошибок до ИИ-правки, число записей в changes до неё)
    best = None
    stale = 0
    for rnd in range(1, cfg.ai_max_rounds + 2):
        rep.rounds = rnd
        await progress(f"🛠 Компиляция · попытка {rnd}")
        res = await compile_mod(cfg, ws.root, main_rel)
        rep.result = res
        if res.timed_out:
            rep.reason = f"Компиляция не уложилась в {cfg.compile_timeout} с."
            return rep
        if res.ok:
            rep.ok = True
            return rep
        errs = res.errors
        if pending and errs:
            cp, before, n_changes, files_before = pending
            pending = None
            new_files = {d.file for d in errs} - files_before
            if len(errs) > before or new_files:
                ws.revert_to(cp)
                del rep.changes[n_changes:]
                rep.reason = "ИИ-правки ухудшили результат (новые ошибки) — откатил их, чтобы не испортить мод."
                return rep
        if errs:
            if best is None or len(errs) < best:
                best, stale = len(errs), 0
            else:
                stale += 1
                if stale >= 3:
                    rep.reason = "Три попытки подряд не уменьшили число ошибок — останавливаюсь."
                    return rep
        if not errs:
            rep.reason = "Компилятор завершился с ошибкой без диагностики:\n" + res.raw[-600:]
            return rep
        # нехватка файла инклюда ИИ не лечит — нужно положить файл в архив
        nf = [d for d in errs if d.code == 100]
        if nf:
            names = ", ".join(sorted(set(re.findall(r'"([^"]+)"', " ".join(d.msg for d in nf)))))
            miss = ", ".join(res.missing_includes) or names
            rep.reason = (f"Не найден инклюд: {miss}. Его нет в архиве (даже с учётом регистра). "
                          "Добавьте файл .inc в pawno/include/ или include/ внутри архива и отправьте мод заново.")
            return rep
        if rnd > cfg.ai_max_rounds:
            rep.reason = "Исчерпан лимит попыток автоисправления."
            return rep

        # 1) детерминированные фиксы: «symbol already defined» в только что вшитой системе
        changed = False
        if own_files and prefix:
            for d in errs:
                if d.code == 21 and d.file in own_files:
                    m = re.search(r'"([^"]+)"', d.msg)
                    if m and _rename_symbol(ws, d.file, m[1], prefix):
                        rep.changes.append(f"{d.file} — дубликат «{m[1]}» переименован в «{prefix}{m[1]}»")
                        changed = True
        # 1.0) ошибка 021 на дубликате native/forward
        for d in errs:
            if d.code == 21:
                try:
                    if _fix_dup_decl(ws, d.file, d.line):
                        changed = True
                        rep.changes.append(f"{d.file}({d.line}) — дублирующее объявление native/forward закомментировано")
                except Exception:
                    pass
        # 1a) ошибка 017 в «new x = F(x);»
        for d in sorted(errs, key=lambda e: (e.file, -e.line)):  # снизу вверх, чтобы номера строк не сдвигались
            if d.code == 17:
                m = re.search(r'"([^"]+)"', d.msg)
                try:
                    ok = bool(m) and _fix_self_init(ws, d.file, d.line, m[1])
                except Exception:
                    ok = False
                if ok:
                    rep.changes.append(f"{d.file}({d.line}) — «{m[1]}» использовалась в собственном инициализаторе")
                    changed = True
        # 1b) ошибка 078: смесь «return;» и «return x;» — чиним без ИИ
        done: set[tuple[str, int]] = set()
        for d in errs:
            if d.code == 78 and (d.file, d.line) not in done:
                done.add((d.file, d.line))
                try:
                    n = _fix_mixed_return(ws, d.file, d.line)
                except Exception:
                    n = 0
                if n:
                    rep.changes.append(f"{d.file}({d.line}) — «return;» заменён на «return 0;» ({n})")
                    changed = True
        if changed:
            continue

        # 2) ИИ
        sig = tuple(sorted((d.file, d.line, d.code) for d in errs[:30]))
        if sig == prev_sig:
            rep.reason = "Ошибки не меняются после правок — останавливаюсь, чтобы не испортить код."
            return rep
        prev_sig = sig
        if not ai.enabled:
            rep.reason = "Есть ошибки компиляции, а ИИ-модуль не настроен (AI_API_KEY)."
            return rep
        await progress(f"🤖 ИИ исправляет ошибки · попытка {rnd} · найдено {len(errs)}")
        cp = ws.checkpoint()
        n_changes = len(rep.changes)
        try:
            applied = await ai.fix(ws, errs)
        except Exception as e:  # сеть, лимиты и т.п.
            rep.reason = f"Ошибка ИИ-модуля: {describe_ai_error(e)}"
            return rep
        if not applied:
            rep.reason = "ИИ не смог предложить безопасных правок."
            return rep
        rep.changes.extend(applied)
        rep.attempts.extend(applied)
        pending = (cp, len(errs), n_changes, {d.file for d in errs})
    return rep


def _context(ws: Workspace, d, before: int = 6, after: int = 2) -> str:
    """Строки кода вокруг ошибки — чтобы было видно, что именно не так (показывается в сообщении об ошибке)."""
    try:
        lines = ws.read(d.file).split("\n")
        a, b = max(0, d.line - 1 - before), min(len(lines), d.line + after)
        out = [f"{d.file}({d.line}):"]
        for i in range(a, b):
            out.append(f"{i + 1}{'>' if i + 1 == d.line else '|'} {lines[i].rstrip(chr(13))[:110]}")
        return "\n".join(out)
    except Exception:
        return ""


async def autofix(cfg, ai, ws, main_rel, progress, own_files=None, prefix: str = "") -> FixReport:
    rep = await _autofix(cfg, ai, ws, main_rel, progress, own_files, prefix)
    if not rep.ok and rep.result and rep.result.errors:
        seen, parts = set(), []
        for d in rep.result.errors:
            key = (d.file, d.code)
            if key in seen:
                continue
            seen.add(key)
            c = _context(ws, d)
            if c:
                parts.append(c)
            if len(parts) >= 2:
                break
        if rep.attempts:
            rep.reason += "\n\nПравки ИИ (откачены):\n" + "\n".join("• " + a[:110] for a in rep.attempts[:5])
        if parts:
            rep.reason = (rep.reason + "\n\nКод у ошибок:\n" + "\n\n".join(parts))[:2400]
    return rep
