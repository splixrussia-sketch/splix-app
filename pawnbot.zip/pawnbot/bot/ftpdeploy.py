"""FTP-заливка мода: проверка адреса (защита от SSRF), FTPS-с-откатом-на-FTP, загрузка дерева файлов.

Всё синхронное (ftplib) — вызывается из asyncio через to_thread. Пароль нигде не сохраняется и не логируется.
"""
from __future__ import annotations

import ftplib
import ipaddress
import os
import posixpath
import re
import socket
import ssl
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

SKIP_DIRS = {".incshim", ".git", "__MACOSX", ".svn"}
BLOCK = 64 * 1024
HOST_RE = re.compile(r"^[A-Za-z0-9](?:[A-Za-z0-9.-]{0,251}[A-Za-z0-9])?$")


class FtpError(Exception):
    """Ошибка с текстом, который можно показать пользователю."""


@dataclass
class FtpTarget:
    host: str
    port: int
    user: str
    password: str
    remote_dir: str = "/"
    ip: str = ""  # заполняется resolve_public()


# ---------- проверка введённых данных ----------
def parse_host(raw: str) -> tuple[str, int, str]:
    """'ftp://host:2121/путь' → (host, port, '/путь'). Бросает FtpError с понятным текстом."""
    s = (raw or "").strip()
    if not s:
        raise FtpError("Введите адрес FTP-сервера.")
    low = s.lower()
    if low.startswith("sftp://") or low.startswith("ssh://"):
        raise FtpError("SFTP / SSH не поддерживается — нужен обычный FTP (порт 21).")
    s = re.sub(r"^ftps?://", "", s, flags=re.I)
    path = ""
    if "/" in s:
        s, _, rest = s.partition("/")
        path = "/" + rest
    if "@" in s:
        raise FtpError("Логин и пароль вводятся отдельно — оставьте в адресе только хост.")
    if s.startswith("["):
        raise FtpError("IPv6-адреса пока не поддерживаются.")
    port = 21
    if ":" in s:
        s, _, p = s.partition(":")
        if not p.isdigit():
            raise FtpError("Порт должен быть числом, например <code>host:21</code>.")
        port = int(p)
    if not HOST_RE.match(s):
        raise FtpError("Не похоже на адрес сервера. Пример: <code>185.12.34.56</code> или <code>ftp.example.ru</code>.")
    if not (port == 21 or 1024 <= port <= 65535):
        raise FtpError("Порт должен быть 21 или в диапазоне 1024–65535.")
    return s.lower(), port, path


def normalize_remote(path: str) -> str:
    """Безопасный абсолютный POSIX-путь на сервере ('' → '/'). Без '..' и управляющих символов."""
    p = (path or "").strip().replace("\\", "/")
    if any(ord(c) < 32 for c in p):
        raise FtpError("В пути на сервере есть недопустимые символы.")
    parts = [x for x in p.split("/") if x and x != "."]
    if any(x == ".." for x in parts):
        raise FtpError("В пути на сервере нельзя использовать «..».")
    return "/" + "/".join(parts)


def check_credentials(user: str, password: str) -> None:
    if not user or len(user) > 64 or any(ord(c) < 32 for c in user):
        raise FtpError("Некорректный логин (до 64 символов, без переводов строк).")
    if not password or len(password) > 128 or any(ord(c) < 32 for c in password):
        raise FtpError("Некорректный пароль (до 128 символов, без переводов строк).")


def resolve_public(host: str, port: int) -> str:
    """Резолвит имя и пускает только публичные IPv4 — бот не должен ходить во внутреннюю сеть Docker/сервера."""
    try:
        infos = socket.getaddrinfo(host, port, socket.AF_INET, socket.SOCK_STREAM)
    except socket.gaierror:
        raise FtpError("Не удалось найти сервер по этому адресу. Проверьте хост.") from None
    ips = sorted({i[4][0] for i in infos})
    if not ips:
        raise FtpError("Не удалось найти сервер по этому адресу.")
    for ip in ips:
        if not ipaddress.ip_address(ip).is_global:
            raise FtpError("Этот адрес ведёт во внутреннюю сеть — заливать можно только на публичные серверы.")
    return ips[0]


# ---------- соединение ----------
def _fmt_size(n: float) -> str:
    for unit in ("Б", "КБ", "МБ", "ГБ"):
        if n < 1024 or unit == "ГБ":
            return f"{n:.0f} {unit}" if unit == "Б" else f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} ГБ"


class Session:
    """Одно FTP-соединение с переподключением. Данные для входа лежат только в памяти."""

    def __init__(self, tgt: FtpTarget, log: Callable[[str, str], None], timeout: int = 30):
        self.tgt = tgt
        self.log = log
        self.timeout = timeout
        self.ftp: ftplib.FTP | None = None
        self.secure = False
        self.made: set[str] = set()

    def connect(self) -> None:
        self.close()
        t = self.tgt
        ctx = ssl.create_default_context()
        # у игровых хостингов почти всегда самоподписанные сертификаты: шифруем, но не проверяем цепочку
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        f: ftplib.FTP = ftplib.FTP_TLS(context=ctx, timeout=self.timeout)
        secure = False
        try:
            f.connect(t.ip, t.port)
        except OSError as e:
            raise FtpError(f"Не удалось подключиться к {t.host}:{t.port} — {_oserr(e)}") from None
        try:
            f.auth()  # type: ignore[attr-defined]
            secure = True
        except (ftplib.error_perm, ftplib.error_temp):
            pass  # сервер не знает AUTH TLS — продолжаем по обычному FTP на этом же соединении
        except (ssl.SSLError, OSError, EOFError):
            try:
                f.close()
            except Exception:
                pass
            f = ftplib.FTP(timeout=self.timeout)
            try:
                f.connect(t.ip, t.port)
            except OSError as e:
                raise FtpError(f"Не удалось подключиться к {t.host}:{t.port} — {_oserr(e)}") from None
        try:
            # FTP_TLS.login по умолчанию повторно шлёт AUTH TLS — на соединении, где TLS уже включён или недоступен, это ломает вход
            if isinstance(f, ftplib.FTP_TLS):
                f.login(t.user, t.password, secure=False)
            else:
                f.login(t.user, t.password)
        except ftplib.error_perm as e:
            f.close()
            if str(e).startswith("530"):
                raise FtpError("Сервер отклонил логин или пароль (530).") from None
            raise FtpError(f"Ошибка входа: {str(e)[:120]}") from None
        except (ftplib.Error, OSError, EOFError) as e:
            f.close()
            raise FtpError(f"Ошибка входа: {_oserr(e)}") from None
        if secure:
            f.prot_p()  # type: ignore[attr-defined]
        self.ftp, self.secure = f, secure
        self.made.clear()

    def close(self) -> None:
        f, self.ftp = self.ftp, None
        if f is not None:
            try:
                f.quit()
            except Exception:
                try:
                    f.close()
                except Exception:
                    pass

    def mkdirs(self, remote_dir: str) -> None:
        """Создаёт цепочку каталогов (существующие пропускает)."""
        cur = ""
        for part in [p for p in remote_dir.split("/") if p]:
            cur += "/" + part
            if cur in self.made:
                continue
            try:
                self.ftp.mkd(cur)  # type: ignore[union-attr]
            except ftplib.error_perm:
                pass  # уже существует (или нет прав — тогда упадёт сама загрузка с понятной ошибкой)
            self.made.add(cur)


def _oserr(e: BaseException) -> str:
    if isinstance(e, socket.timeout) or isinstance(e, TimeoutError):
        return "таймаут, сервер не отвечает"
    if isinstance(e, ConnectionRefusedError):
        return "соединение отклонено (проверьте порт и что FTP включён)"
    if isinstance(e, EOFError):
        return "сервер оборвал соединение"
    return str(e)[:120] or e.__class__.__name__


# ---------- сбор файлов ----------
@dataclass
class UploadFile:
    path: Path
    rel: str  # POSIX-путь относительно корня мода
    size: int


def collect(root: Path, amx_rel: str | None = None, max_files: int = 5000, max_bytes: int = 400 << 20) -> list[UploadFile]:
    """Файлы для заливки: весь мод или только готовый .amx. Симлинки и служебные каталоги пропускаются."""
    root = root.resolve()
    out: list[UploadFile] = []
    if amx_rel:
        p = root / amx_rel
        if not p.is_file():
            raise FtpError("Готовый .amx не найден после сборки.")
        return [UploadFile(p, Path(amx_rel).as_posix(), p.stat().st_size)]
    total = 0
    for dirpath, dirs, files in os.walk(root):
        dirs[:] = sorted(d for d in dirs if d not in SKIP_DIRS and not os.path.islink(os.path.join(dirpath, d)))
        for f in sorted(files):
            full = Path(dirpath) / f
            if full.is_symlink() or not full.is_file() or any(ord(c) < 32 for c in f):
                continue
            size = full.stat().st_size
            total += size
            out.append(UploadFile(full, full.relative_to(root).as_posix(), size))
            if len(out) > max_files:
                raise FtpError(f"Слишком много файлов (больше {max_files}). Попробуйте режим «только .amx».")
            if total > max_bytes:
                raise FtpError(f"Мод больше {max_bytes >> 20} МБ — залейте только .amx.")
    if not out:
        raise FtpError("Нечего заливать: в моде нет файлов.")
    return out


# ---------- загрузка ----------
@dataclass
class UploadResult:
    files: int
    bytes: int
    seconds: float
    secure: bool

    @property
    def speed(self) -> float:
        return self.bytes / self.seconds if self.seconds > 0 else 0.0


ProgressCb = Callable[[int, int, int, int, str], None]  # bytes_done, bytes_total, files_done, files_total, current


def upload_tree(
    tgt: FtpTarget,
    files: list[UploadFile],
    log: Callable[[str, str], None],
    progress: ProgressCb,
    cancel: threading.Event,
) -> UploadResult:
    """Заливает файлы в tgt.remote_dir. Ошибка файла → до 3 попыток с переподключением."""
    t0 = time.monotonic()
    total_b = sum(f.size for f in files)
    total_n = len(files)
    done_b = 0
    base = normalize_remote(tgt.remote_dir)
    s = Session(tgt, log)
    log("info", f"🔌 Подключаюсь к {tgt.host}:{tgt.port}…")
    s.connect()
    log("ok", "🔐 Подключено · FTPS (шифрование)" if s.secure else "✅ Подключено")
    if not s.secure:
        log("warn", "⚠️ Сервер не поддерживает шифрование — данные идут по обычному FTP")
    verbose = total_n <= 30
    try:
        s.mkdirs(base)
        try:
            s.ftp.cwd(base)  # type: ignore[union-attr]
        except ftplib.error_perm:
            raise FtpError(f"Нет доступа к папке {base} на сервере.") from None
        log("info", f"📁 Папка назначения: {base} · файлов: {total_n} · {_fmt_size(total_b)}")
        last_note = 0.0
        for n, uf in enumerate(files, 1):
            if cancel.is_set():
                raise FtpError("Остановлено пользователем.")
            remote = posixpath.join(base, uf.rel)
            s.mkdirs(posixpath.dirname(remote))
            attempt = 0
            while True:
                attempt += 1
                sent = 0

                def cb(chunk: bytes, _uf=uf) -> None:
                    nonlocal sent
                    if cancel.is_set():
                        raise FtpError("Остановлено пользователем.")
                    sent += len(chunk)
                    progress(done_b + sent, total_b, n - 1, total_n, _uf.rel)

                try:
                    with uf.path.open("rb") as fh:
                        s.ftp.storbinary(f"STOR {remote}", fh, blocksize=BLOCK, callback=cb)  # type: ignore[union-attr]
                    try:  # проверка целостности, если сервер умеет SIZE
                        rs = s.ftp.size(remote)  # type: ignore[union-attr]
                    except Exception:
                        rs = None
                    if rs is not None and rs != uf.size:
                        raise ftplib.error_temp(f"размер не совпал ({rs} ≠ {uf.size})")
                    break
                except FtpError:
                    raise
                except ftplib.error_perm as e:
                    raise FtpError(f"Сервер отказал в записи {uf.rel}: {str(e)[:100]}") from None
                except (ftplib.Error, OSError, EOFError) as e:
                    if attempt >= 3:
                        raise FtpError(f"Не удалось залить {uf.rel}: {_oserr(e)}") from None
                    log("warn", f"↻ {uf.rel}: {_oserr(e)} — повтор {attempt}/2")
                    time.sleep(1.5 * attempt)
                    s.connect()
                    s.mkdirs(posixpath.dirname(remote))
            done_b += uf.size
            progress(done_b, total_b, n, total_n, uf.rel)
            now = time.monotonic()
            if verbose or uf.size >= 256 * 1024:
                log("info", f"↑ {uf.rel} · {_fmt_size(uf.size)}")
            elif now - last_note > 4:
                last_note = now
                log("info", f"… {n}/{total_n} файлов")
        return UploadResult(total_n, total_b, time.monotonic() - t0, s.secure)
    finally:
        s.close()
