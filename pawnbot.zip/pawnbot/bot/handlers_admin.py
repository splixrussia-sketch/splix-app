from __future__ import annotations

import asyncio
import logging
import re
import secrets
from pathlib import Path

from aiogram import Bot, F, Router
from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError, TelegramRetryAfter
from aiogram.filters import BaseFilter, Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, FSInputFile, InlineKeyboardButton, InlineKeyboardMarkup, Message

from .config import Config
from .db import DB
from .ui import admin_kb, bar, card, edit, esc, kb, kv, panel, send, short, show

log = logging.getLogger("admin")
router = Router()
cmd_router = Router()
_TASKS: set[asyncio.Task] = set()
TG_SEND_LIMIT = 49 * 1024 * 1024
BACK_ADM = [("◀️ Назад", "adm")]


class IsAdmin(BaseFilter):
    async def __call__(self, event, db: DB) -> bool:
        u = getattr(event, "from_user", None)
        return bool(u and await db.is_admin(u.id))


router.message.filter(IsAdmin())
router.callback_query.filter(IsAdmin())
cmd_router.message.filter(IsAdmin())


class BcSt(StatesGroup):
    msg = State()
    buttons = State()
    confirm = State()


class OpSt(StatesGroup):
    add = State()


class PromoAdm(StatesGroup):
    new = State()


class BalSt(StatesGroup):
    one = State()
    all = State()


class AdmSt(StatesGroup):
    toggle = State()


def _spawn(coro) -> None:
    t = asyncio.create_task(coro)
    _TASKS.add(t)
    t.add_done_callback(_TASKS.discard)


# ---------- панель ----------
async def _panel(target, state: FSMContext, cfg: Config, db: DB):
    await state.clear()
    s = await db.stats()
    text = card(
        "⚙️ Админ-панель",
        panel(
            kv("👤", "Пользователей", str(s["users"])),
            kv("🟢", "Активны за 24 ч", str(s["day"])),
            kv("⚡️", "Онлайн сейчас", str(s["live"])),
            kv("🗂", "Модов в базе", str(s["mods"])),
        ),
        "",
        "<i>Выберите раздел 👇</i>",
    )
    await show(target, text, admin_kb(target.from_user.id == cfg.owner_id), banner="admin")


@cmd_router.message(Command("aitest"))
async def cmd_aitest(m: Message, ai):
    if not ai.enabled:
        await m.answer("❌ AI_API_KEY не задан в .env")
        return
    msg = await m.answer("⏳ Проверяю связь с ИИ…")
    await msg.edit_text(f"{await ai.ping()}\n\nМодель: {ai.cfg.ai_model}\nАдрес: {ai.cfg.ai_base_url}")


@cmd_router.message(Command("admins"))
async def cmd_admins(m: Message, state: FSMContext, cfg: Config, db: DB):
    await _panel(m, state, cfg, db)


@router.callback_query(F.data == "adm")
async def cb_panel(c: CallbackQuery, state: FSMContext, cfg: Config, db: DB):
    await c.answer()
    await _panel(c, state, cfg, db)


# ---------- статистика ----------
@router.callback_query(F.data == "adm:stats")
async def cb_stats(c: CallbackQuery, db: DB):
    s = await db.stats()
    names = {"add_mod": "📦 Загрузки модов", "add_system": "🧩 Вшито систем", "compile": "🛠 Компиляции"}
    lines = [
        panel(
            kv("👤", "Пользователей", str(s["users"])),
            kv("🟢", "Активны за 24 ч", str(s["day"])),
            kv("⚡️", "Онлайн (15 мин)", str(s["live"])),
            kv("🗂", "Модов в базе", str(s["mods"])),
            kv("🔒", "Каналов ОП", str(s["channels"])),
        ),
        "",
        "<b>Популярность функций</b>",
    ]
    top = max((t for _a, _o, t in s["acts"]), default=0)
    body = []
    for action, ok, total in s["acts"]:
        body.append(f"{names.get(action, action)}: <b>{total}</b> · ✅ {int(ok or 0)}")
        body.append(bar(total, top, 12))
    lines.append(panel(*body) if body else "<i>пока пусто</i>")
    await c.answer()
    await show(c, card("📊 Статистика", *lines), kb([("🔄 Обновить", "adm:stats")], BACK_ADM), banner="stats")


# ---------- рассылка ----------
@router.callback_query(F.data == "adm:bc")
async def cb_bc(c: CallbackQuery, state: FSMContext):
    await state.set_state(BcSt.msg)
    await c.answer()
    await show(c, card("📣 Рассылка", "Отправьте сообщение для рассылки — текст, фото или видео с форматированием."), kb(BACK_ADM), banner="bc")


@router.message(BcSt.msg)
async def bc_msg(m: Message, state: FSMContext):
    await state.update_data(chat=m.chat.id, mid=m.message_id)
    await state.set_state(BcSt.buttons)
    await m.answer(
        card(
            "🔘 Кнопки",
            "Пришлите кнопки-ссылки, по одной на строку:",
            "<code>Текст кнопки | https://ссылка</code>",
        ),
        reply_markup=kb([("➡️ Без кнопок", "adm:bc:skip")], BACK_ADM),
    )


def _markup(buttons: list[list[str]]) -> InlineKeyboardMarkup | None:
    if not buttons:
        return None
    return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text=t, url=u)] for t, u in buttons])


async def _bc_confirm(target, state: FSMContext, db: DB, bot: Bot, buttons):
    await state.update_data(buttons=buttons)
    data = await state.get_data()
    await state.set_state(BcSt.confirm)
    try:
        await bot.copy_message(target.from_user.id, data["chat"], data["mid"], reply_markup=_markup(buttons))
    except Exception:
        pass
    n = len(await db.all_user_ids())
    text = card("📣 Подтверждение", f"Так будет выглядеть сообщение (выше).", f"Получателей: <b>{n}</b>")
    markup = kb([("🚀 Отправить", "adm:bc:go")], [("✖️ Отмена", "adm")])
    if isinstance(target, CallbackQuery):
        await target.message.answer(text, reply_markup=markup)
    else:
        await target.answer(text, reply_markup=markup)


@router.message(BcSt.buttons, F.text)
async def bc_buttons(m: Message, state: FSMContext, db: DB, bot: Bot):
    buttons = []
    for line in m.text.splitlines():
        if "|" not in line:
            continue
        t, u = (x.strip() for x in line.split("|", 1))
        if t and re.match(r"^(https?://|tg://)", u):
            buttons.append([t, u])
    if not buttons:
        await m.answer("Не нашёл ни одной кнопки. Формат: <code>Текст | https://ссылка</code>")
        return
    await _bc_confirm(m, state, db, bot, buttons)


@router.callback_query(BcSt.buttons, F.data == "adm:bc:skip")
async def bc_skip(c: CallbackQuery, state: FSMContext, db: DB, bot: Bot):
    await c.answer()
    await _bc_confirm(c, state, db, bot, [])


@router.callback_query(BcSt.confirm, F.data == "adm:bc:go")
async def bc_go(c: CallbackQuery, state: FSMContext, db: DB, bot: Bot):
    data = await state.get_data()
    await state.clear()
    await c.answer("Рассылка запущена")
    status = await show(c, card("📣 Рассылка", panel(bar(0, 1), "⏳ Отправляю…")), banner="bc")
    _spawn(_broadcast(bot, db, status, data["chat"], data["mid"], _markup(data.get("buttons") or [])))


async def _copy(bot: Bot, uid: int, chat: int, mid: int, markup) -> bool:
    for _ in range(3):
        try:
            await bot.copy_message(uid, chat, mid, reply_markup=markup)
            return True
        except TelegramRetryAfter as e:
            await asyncio.sleep(e.retry_after + 1)
        except (TelegramForbiddenError, TelegramBadRequest):
            return False
        except Exception:
            return False
    return False


async def _broadcast(bot: Bot, db: DB, status: Message, chat: int, mid: int, markup):
    ids = await db.all_user_ids()
    ok = fail = 0
    for i, uid in enumerate(ids, 1):
        if await _copy(bot, uid, chat, mid, markup):
            ok += 1
        else:
            fail += 1
        await asyncio.sleep(0.05)
        if i % 100 == 0:
            try:
                status = await edit(status, card("📣 Рассылка", panel(bar(i, len(ids)), f"⏳ {i}/{len(ids)}")))
            except Exception:
                pass
    try:
        await edit(
            status,
            card("✅ Рассылка завершена", panel(f"✅ Доставлено: <b>{ok}</b>", f"🚫 Не доставлено: <b>{fail}</b>")),
            kb(BACK_ADM),
            banner="ok",
        )
    except Exception:
        pass


# ---------- обязательная подписка ----------
async def _op_view(target, db: DB):
    chans = await db.list_channels()
    lines = ["Пользователи должны быть подписаны на все каналы из списка.", ""]
    rows = []
    items = [f"📢 {esc(short(ch.title, 40))}" for ch in chans]
    for ch in chans:
        rows.append([(f"❌ {ch.title[:30]}", f"adm:op:del:{ch.chat_id}")])
    lines.append(panel(*items) if items else "<i>Список пуст — подписка не требуется.</i>")
    rows.append([("➕ Добавить канал", "adm:op:add")])
    rows.append(BACK_ADM)
    await show(target, card("🔒 Обязательная подписка", *lines), kb(*rows), banner="sub")


@router.callback_query(F.data == "adm:op")
async def cb_op(c: CallbackQuery, state: FSMContext, db: DB):
    await state.clear()
    await c.answer()
    await _op_view(c, db)


@router.callback_query(F.data == "adm:op:add")
async def cb_op_add(c: CallbackQuery, state: FSMContext):
    await state.set_state(OpSt.add)
    await c.answer()
    await show(
        c,
        card("➕ Новый канал", panel("1️⃣ Добавьте бота в канал <b>администратором</b>", "2️⃣ Отправьте @username, ссылку или ID канала")),
        kb([("◀️ Назад", "adm:op")]),
        banner="sub",
    )


@router.message(OpSt.add, F.text)
async def on_op_add(m: Message, state: FSMContext, db: DB, bot: Bot):
    key = m.text.strip()
    mt = re.match(r"^(?:https?://)?t\.me/([A-Za-z0-9_]+)/?$", key)
    if mt:
        key = "@" + mt[1]
    elif re.fullmatch(r"-?\d+", key):
        key = int(key)
    try:
        chat = await bot.get_chat(key)
        me = await bot.me()
        mem = await bot.get_chat_member(chat.id, me.id)
        if mem.status not in ("administrator", "creator"):
            raise ValueError("Бот не администратор канала.")
        if chat.username:
            link = f"https://t.me/{chat.username}"
        else:
            link = (await bot.create_chat_invite_link(chat.id)).invite_link
    except Exception as e:
        await send(m, card("❌ Не получилось", esc(str(e)[:200]), "Проверьте, что бот добавлен админом."), kb([("◀️ Назад", "adm:op")]), banner="fail")
        return
    await db.add_channel(chat.id, chat.title or str(chat.id), link)
    await state.clear()
    await send(m, card("✅ Канал добавлен", esc(chat.title or str(chat.id))), kb([("🔒 К списку", "adm:op")]), banner="ok")


@router.callback_query(F.data.startswith("adm:op:del:"))
async def cb_op_del(c: CallbackQuery, db: DB):
    await db.del_channel(int(c.data.rsplit(":", 1)[1]))
    await c.answer("Удалено")
    await _op_view(c, db)


# ---------- промокоды ----------
@router.callback_query(F.data == "adm:promo")
async def cb_promo(c: CallbackQuery, state: FSMContext):
    await state.set_state(PromoAdm.new)
    await c.answer()
    await show(
        c,
        card(
            "🎟 Генератор промокодов",
            "Отправьте: <code>активации запросы [КОД]</code>",
            "",
            panel(
                "<code>50 3</code> — случайный код, 50 активаций по 3 запроса",
                "<code>10 5 SUMMER</code> — свой код",
            ),
        ),
        kb(BACK_ADM),
        banner="promos",
    )


@router.message(PromoAdm.new, F.text, ~F.text.startswith("/"))
async def on_promo_new(m: Message, state: FSMContext, db: DB):
    p = m.text.split()
    if len(p) < 2 or not (p[0].isdigit() and p[1].isdigit()) or int(p[0]) < 1 or int(p[1]) < 1:
        await m.answer("Формат: <code>активации запросы [КОД]</code>, числа больше нуля.")
        return
    code = p[2].upper() if len(p) > 2 else secrets.token_hex(4).upper()
    if not re.fullmatch(r"[A-Z0-9_-]{3,32}", code):
        await m.answer("Код: 3–32 символа, латиница/цифры/-/_.")
        return
    if not await db.create_promo(code, int(p[1]), int(p[0])):
        await m.answer("Такой код уже существует.")
        return
    await state.clear()
    await send(
        m,
        card("✅ Промокод создан", panel(f"🎟 <code>{code}</code>", f"Активаций: <b>{p[0]}</b>", f"Запросов за код: <b>{p[1]}</b>")),
        kb([("🎟 Ещё", "adm:promo")], BACK_ADM),
        banner="ok",
    )


# ---------- баланс ----------
@router.callback_query(F.data == "adm:bal")
async def cb_bal(c: CallbackQuery, state: FSMContext):
    await state.clear()
    await c.answer()
    await show(c, card("💰 Управление балансом", "Кому начислить запросы?"), kb([("👤 Пользователю", "adm:bal:one")], [("👥 Всем", "adm:bal:all")], BACK_ADM), banner="bal")


@router.callback_query(F.data == "adm:bal:one")
async def cb_bal_one(c: CallbackQuery, state: FSMContext):
    await state.set_state(BalSt.one)
    await c.answer()
    await show(c, card("👤 Выдать запросы", "Отправьте: <code>ID или @username количество</code>", "", panel("Пример: <code>@vasya 10</code>")), kb([("◀️ Назад", "adm:bal")]), banner="bal")


@router.message(BalSt.one, F.text, ~F.text.startswith("/"))
async def on_bal_one(m: Message, state: FSMContext, db: DB, bot: Bot):
    p = m.text.split()
    if len(p) != 2 or not re.fullmatch(r"-?\d+", p[1]):
        await m.answer("Формат: <code>ID или @username количество</code>")
        return
    u = await db.find_user(p[0])
    if not u:
        await m.answer("Пользователь не найден (он должен хотя бы раз запустить бота).")
        return
    n = int(p[1])
    await db.add_balance(u.id, n)
    await state.clear()
    try:
        if n > 0:
            await bot.send_message(u.id, card("🎁 Начисление", f"Вам начислено <b>+{n}</b> запросов."))
    except Exception:
        pass
    await send(m, card("✅ Готово", panel(f"{esc(u.first_name or str(u.id))}: <b>{'+' if n > 0 else ''}{n}</b>")), kb(BACK_ADM), banner="ok")


@router.callback_query(F.data == "adm:bal:all")
async def cb_bal_all(c: CallbackQuery, state: FSMContext):
    await state.set_state(BalSt.all)
    await c.answer()
    await show(c, card("👥 Бонус всем", "Отправьте число запросов, которое получит каждый пользователь бота."), kb([("◀️ Назад", "adm:bal")]), banner="bal")


@router.message(BalSt.all, F.text, ~F.text.startswith("/"))
async def on_bal_all(m: Message, state: FSMContext, db: DB):
    if not m.text.strip().isdigit() or int(m.text) < 1:
        await m.answer("Нужно положительное число.")
        return
    cnt = await db.add_balance_all(int(m.text))
    await state.clear()
    await send(m, card("✅ Готово", panel(f"+{int(m.text)} запросов · пользователей: <b>{cnt}</b>")), kb(BACK_ADM), banner="ok")


# ---------- база модов ----------
PAGE = 8


@router.callback_query(F.data.startswith("adm:dump:"))
async def cb_dump(c: CallbackQuery, db: DB):
    page = int(c.data.rsplit(":", 1)[1])
    total = await db.count_mods()
    mods = await db.list_mods(page * PAGE, PAGE)
    rows = [[(f"{m.user_id} · {m.name[:22]} · {m.size / 1048576:.1f} МБ", f"adm:dl:{m.user_id}")] for m in mods]
    nav = []
    if page > 0:
        nav.append(("◀️", f"adm:dump:{page - 1}"))
    if (page + 1) * PAGE < total:
        nav.append(("▶️", f"adm:dump:{page + 1}"))
    if nav:
        rows.append(nav)
    if total:
        rows.append([("📥 Скачать все", "adm:dlall")])
    rows.append(BACK_ADM)
    await c.answer()
    await show(c, card("🗂 База модов", panel(f"Всего модов: <b>{total}</b>", f"Страница: <b>{page + 1}</b>"), "", "Нажмите на мод, чтобы скачать исходный архив."), kb(*rows), banner="dump")


async def _send_mod(bot: Bot, to: int, mod) -> None:
    p = Path(mod.zip_path)
    if not p.is_file():
        await bot.send_message(to, f"Файл мода {mod.user_id} не найден на диске.")
    elif p.stat().st_size > TG_SEND_LIMIT:
        await bot.send_message(to, f"Мод {mod.user_id} больше 50 МБ, лежит на сервере: <code>{esc(str(p))}</code>")
    else:
        await bot.send_document(to, FSInputFile(p, filename=f"{mod.user_id}_{mod.name}"), caption=f"👤 <code>{mod.user_id}</code> · {esc(mod.name)}")


@router.callback_query(F.data.startswith("adm:dl:"))
async def cb_dl_one(c: CallbackQuery, db: DB, bot: Bot):
    mod = await db.get_mod(int(c.data.rsplit(":", 1)[1]))
    await c.answer()
    if mod:
        await _send_mod(bot, c.from_user.id, mod)


@router.callback_query(F.data == "adm:dlall")
async def cb_dl_all(c: CallbackQuery, db: DB, bot: Bot):
    await c.answer("Отправляю все моды…")

    async def job():
        offset = 0
        while mods := await db.list_mods(offset, 20):
            for m in mods:
                await _send_mod(bot, c.from_user.id, m)
                await asyncio.sleep(0.7)
            offset += 20
        await bot.send_message(c.from_user.id, "✅ Все моды отправлены.")

    _spawn(job())


# ---------- админы (только владелец) ----------
@router.callback_query(F.data == "adm:admins")
async def cb_admins(c: CallbackQuery, state: FSMContext, db: DB, cfg: Config):
    if c.from_user.id != cfg.owner_id:
        await c.answer("Только владелец", show_alert=True)
        return
    await state.set_state(AdmSt.toggle)
    ids = await db.list_admins()
    await c.answer()
    await show(
        c,
        card(
            "👮 Администраторы",
            panel(f"👑 Владелец: <code>{cfg.owner_id}</code>", *[f"• <code>{i}</code>" for i in ids]),
            "",
            "Отправьте ID, чтобы <b>добавить</b> или <b>убрать</b> админа.",
        ),
        kb(BACK_ADM),
        banner="admins",
    )


@router.message(AdmSt.toggle, F.text, ~F.text.startswith("/"))
async def on_admin_toggle(m: Message, state: FSMContext, db: DB, cfg: Config):
    if m.from_user.id != cfg.owner_id:
        return
    if not m.text.strip().isdigit():
        await m.answer("Нужен числовой ID.")
        return
    uid = int(m.text)
    if uid == cfg.owner_id:
        await m.answer("Владельца менять нельзя.")
        return
    added = await db.toggle_admin(uid)
    await state.clear()
    await send(m, card("✅ Готово", panel(f"<code>{uid}</code> — {'теперь админ 👑' if added else 'больше не админ'}")), kb([("👮 К списку", "adm:admins")], BACK_ADM), banner="ok")
