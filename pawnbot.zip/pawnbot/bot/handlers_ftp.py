"""Раздел «🚀 Залить на FTP» в боте: хост → логин → пароль → сборка → заливка с таймером и логами."""
from __future__ import annotations

import asyncio
import logging

from aiogram import Bot, F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import BufferedInputFile, CallbackQuery, Message

from .config import Config
from .db import DB
from .deploy import DeployManager, Job
from .ftpdeploy import FtpError, check_credentials, parse_host
from .ui import BACK, CANCEL, bar, card, edit, esc, kb, panel, send, short, show

log = logging.getLogger("ftp")
router = Router()
cmd_router = Router()
_TASKS: set[asyncio.Task] = set()

LV_ICON = {"info": "•", "ok": "✓", "warn": "!", "err": "✗"}


class FtpSt(StatesGroup):
    host = State()
    user = State()
    password = State()


# ---------- вспомогательное ----------
def _clock(sec: float) -> str:
    sec = int(sec)
    return f"{sec // 60:02d}:{sec % 60:02d}"


def _mb(n: float) -> str:
    return f"{n / 1048576:.1f} МБ" if n >= 1048576 else f"{n / 1024:.0f} КБ"


def _steps(n: int) -> str:
    names = ["Хост", "Логин", "Пароль"]
    return "  ".join(("✅ " if i < n else "👉 " if i == n else "▫️ ") + names[i] for i in range(3))


def _form(step: int, amx_only: bool, host: str | None = None, user: str | None = None) -> str:
    ask = [
        "Отправьте <b>адрес FTP-сервера</b>:\n<code>185.12.34.56</code> или <code>ftp.host.ru:21</code>",
        "Теперь <b>логин</b> от FTP 👇",
        "И <b>пароль</b> 🔒\nСообщение с паролем я сразу удалю из чата.",
    ][step]
    info = []
    if host:
        info.append(f"🌐 Хост: <code>{esc(short(host, 40))}</code>")
    if user:
        info.append(f"👤 Логин: <code>{esc(short(user, 30))}</code>")
    info.append("📤 Заливаем: <b>только .amx</b>" if amx_only else "📤 Заливаем: <b>весь мод</b> (с готовым .amx)")
    return card("🚀 Залить на FTP", panel(_steps(step), "", *info), "", ask)


def _form_kb(cfg: Config, amx_only: bool, step: int):
    rows = []
    if step == 0:
        rows.append([("🎮 Только .amx" if not amx_only else "📦 Весь мод", "ftp:mode")])
        if cfg.webapp_url:
            rows.append([("📱 Открыть Mini App", "webapp", cfg.webapp_url)])
    rows.append(CANCEL)
    return kb(*rows)


async def _swap(bot: Bot, m: Message, state: FSMContext, text: str, markup, banner: str) -> Message:
    """Старую карточку убираем, новую шлём — в чате всегда одна карточка формы."""
    data = await state.get_data()
    old = data.get("card")
    if old:
        try:
            await bot.delete_message(m.chat.id, old)
        except Exception:
            pass
    new = await send(m, text, markup, banner=banner)
    await state.update_data(card=new.message_id)
    return new


async def _try_delete(m: Message) -> None:
    try:
        await m.delete()
    except Exception:
        pass


# ---------- вход в раздел ----------
async def _open(target, state: FSMContext, db: DB, cfg: Config) -> None:
    uid = target.from_user.id
    isc = isinstance(target, CallbackQuery)

    async def deny(text: str):
        if isc:
            await target.answer(text, show_alert=True)
        else:
            await send(target, card("🚀 Залить на FTP", text), kb(BACK), banner="locked")

    if not await db.has_access(uid):
        return await deny("Нет доступа: активируйте промокод или пригласите друзей")
    if not await db.get_mod(uid):
        return await deny("Сначала загрузите мод")
    await state.clear()
    await state.set_state(FtpSt.host)
    await state.update_data(amx_only=False)
    if isc:
        await target.answer()
    msg = await show(target, _form(0, False), _form_kb(cfg, False, 0), banner="ftp")
    await state.update_data(card=msg.message_id)


@router.callback_query(F.data == "ftp")
async def cb_ftp(c: CallbackQuery, state: FSMContext, db: DB, cfg: Config):
    await _open(c, state, db, cfg)


@cmd_router.message(Command("ftp"))
async def cmd_ftp(m: Message, state: FSMContext, db: DB, cfg: Config):
    await _open(m, state, db, cfg)


@router.callback_query(FtpSt.host, F.data == "ftp:mode")
async def cb_mode(c: CallbackQuery, state: FSMContext, cfg: Config):
    d = await state.get_data()
    amx_only = not d.get("amx_only", False)
    await state.update_data(amx_only=amx_only)
    await c.answer("Только .amx" if amx_only else "Весь мод")
    await show(c, _form(0, amx_only), _form_kb(cfg, amx_only, 0), banner="ftp")


# ---------- шаги формы ----------
@router.message(FtpSt.host, F.text, ~F.text.startswith("/"))
async def on_host(m: Message, state: FSMContext, cfg: Config, bot: Bot):
    raw = m.text.strip()
    await _try_delete(m)
    d = await state.get_data()
    try:
        host, port, path = parse_host(raw)
    except FtpError as e:
        await _swap(bot, m, state, _form(0, d.get("amx_only", False)) + f"\n\n⚠️ {e}", _form_kb(cfg, d.get("amx_only", False), 0), "ftp")
        return
    await state.update_data(host=host, port=port, path=path)
    await state.set_state(FtpSt.user)
    label = host if port == 21 else f"{host}:{port}"
    await _swap(bot, m, state, _form(1, d.get("amx_only", False), label), kb(CANCEL), "ftp")


@router.message(FtpSt.user, F.text, ~F.text.startswith("/"))
async def on_user(m: Message, state: FSMContext, bot: Bot):
    user = m.text.strip()
    await _try_delete(m)
    d = await state.get_data()
    label = d["host"] if d["port"] == 21 else f"{d['host']}:{d['port']}"
    if not user or len(user) > 64 or any(ord(c) < 32 for c in user):
        await _swap(bot, m, state, _form(1, d.get("amx_only", False), label) + "\n\n⚠️ Некорректный логин.", kb(CANCEL), "ftp")
        return
    await state.update_data(user=user)
    await state.set_state(FtpSt.password)
    await _swap(bot, m, state, _form(2, d.get("amx_only", False), label, user), kb(CANCEL), "ftp")


@router.message(FtpSt.password, F.text, ~F.text.startswith("/"))
async def on_password(m: Message, state: FSMContext, bot: Bot, deployer: DeployManager):
    password = m.text.strip()
    await _try_delete(m)  # пароль не должен оставаться в истории чата
    d = await state.get_data()
    label = d["host"] if d["port"] == 21 else f"{d['host']}:{d['port']}"
    try:
        check_credentials(d["user"], password)
        job = await deployer.start(m.from_user.id, d["host"], d["port"], d["user"], password, d.get("path", ""), d.get("amx_only", False))
    except FtpError as e:
        await _swap(bot, m, state, _form(2, d.get("amx_only", False), label, d["user"]) + f"\n\n⚠️ {e}", kb(CANCEL), "ftp")
        return
    finally:
        password = ""
    msg = await _swap(bot, m, state, _running_text(job), _run_kb(), "deploy")
    await state.clear()
    t = asyncio.create_task(_watch(deployer, job, msg, m.from_user.id))
    _TASKS.add(t)
    t.add_done_callback(_TASKS.discard)


@router.message(FtpSt.host)
@router.message(FtpSt.user)
@router.message(FtpSt.password)
async def on_wrong(m: Message):
    await m.answer("Отправьте значение <b>текстом</b>.", reply_markup=kb(CANCEL))


# ---------- экран прогресса ----------
def _run_kb():
    return kb([("⏹ Остановить", "ftp:stop")])


def _stage_line(job: Job) -> str:
    if job.stage == "compile":
        return "⏳ Сборка  ›  ▫️ Загрузка"
    return "✅ Сборка  ›  ⏳ Загрузка"


def _running_text(job: Job) -> str:
    rows = [
        f"🌐 <code>{esc(job.label)}</code>",
        f"⏱ <b>{_clock(job.elapsed)}</b> · {_stage_line(job)}",
        bar(job.pct, 100),
    ]
    if job.stage == "upload" and job.bytes_total:
        rows.append(f"📤 {job.files_done}/{job.files_total} файлов · {_mb(job.bytes_done)} / {_mb(job.bytes_total)}")
    logs = "\n".join(f"{LV_ICON.get(x['lv'], '•')} {esc(short(x['m'], 46))}" for x in job.tail(5))
    return card("🚀 Заливка на FTP", panel(*rows), "", f"<pre>{logs or '…'}</pre>")


def _final(job: Job):
    """(текст, клавиатура, баннер) итоговой карточки."""
    log_btn = [("📋 Полный лог", "ftp:log")]
    if job.state == "ok":
        r = job.result
        speed = f" · {_mb(r['speed'])}/с" if r.get("speed") else ""
        rows = [
            f"🌐 <code>{esc(job.label)}</code>" + (f" → <code>{esc(job.remote_dir)}</code>" if job.remote_dir != "/" else ""),
            f"📤 Файлов: <b>{r['files']}</b> · {_mb(r['bytes'])}",
            f"⏱ Всего: <b>{_clock(job.elapsed)}</b>{speed}",
            "🔐 Канал: <b>FTPS</b>" if r.get("secure") else "🔓 Канал: <b>обычный FTP</b>",
        ]
        return card("✅ Мод залит!", panel(*rows)), kb([("🔁 Залить ещё раз", "ftp")], log_btn, BACK), "ftpok"
    if job.state == "cancelled":
        return card("⏹ Остановлено", "Заливка прервана. Запрос не списан."), kb([("🔁 Заново", "ftp")], log_btn, BACK), "fail"
    tail = "\n".join(f"{LV_ICON.get(x['lv'], '•')} {esc(short(x['m'], 50))}" for x in job.tail(4))
    return (
        card("❌ Не получилось", esc(short(job.error or "Неизвестная ошибка", 300)), "", f"<pre>{tail}</pre>", "↩️ Запрос не списан."),
        kb([("🔁 Повторить", "ftp")], log_btn, BACK),
        "fail",
    )


async def _watch(deployer: DeployManager, job: Job, msg: Message, uid: int) -> None:
    cur, last = msg, ""
    while job.running:
        await asyncio.sleep(2.5)
        if not job.running:
            break
        text = _running_text(job)
        if text == last:
            continue
        try:
            cur = await edit(cur, text, _run_kb())
            last = text
        except Exception as e:  # флуд-лимит / сообщение удалено — просто пробуем в следующий тик
            log.debug("progress edit: %s", e)
    text, markup, banner = _final(job)
    try:
        await edit(cur, text, markup, banner=banner)
    except Exception:
        try:
            await send(cur, text, markup, banner=banner)
        except Exception:
            log.warning("не смог показать итог заливки uid=%s", uid)


# ---------- кнопки ----------
@router.callback_query(F.data == "ftp:stop")
async def cb_stop(c: CallbackQuery, deployer: DeployManager):
    job = deployer.get(c.from_user.id)
    if job and job.running:
        job.cancel.set()
        await c.answer("Останавливаю…")
    else:
        await c.answer("Сейчас ничего не выполняется")


@router.callback_query(F.data == "ftp:log")
async def cb_log(c: CallbackQuery, deployer: DeployManager):
    job = deployer.get(c.from_user.id)
    if not job:
        await c.answer("Лог уже очищен", show_alert=True)
        return
    await c.answer()
    await c.message.answer_document(BufferedInputFile(job.full_log_text().encode("utf-8"), filename="ftp-deploy-log.txt"), caption="📋 <b>Лог заливки</b>")
