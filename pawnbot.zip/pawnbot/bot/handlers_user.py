from __future__ import annotations

import asyncio
import io
import logging
import re
import shutil
from pathlib import Path
from urllib.parse import quote

from aiogram import Bot, F, Router
from aiogram.exceptions import TelegramBadRequest
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, FSInputFile, Message

from .ai import AIFixer
from .config import Config
from .db import DB, Mod
from .fixer import autofix
from .injector import integrate
from .modtools import ModError, Workspace, find_main, find_root, make_zip, safe_extract, sensitive_files
from .ui import (
    BACK,
    CANCEL,
    HELP_TEXT,
    STUB_TEXT,
    bar,
    card,
    edit,
    esc,
    kb,
    kv,
    menu_kb,
    menu_text,
    panel,
    rank,
    send,
    short,
    show,
    stub_kb,
)

log = logging.getLogger("user")
router = Router()
cmd_router = Router()  # команды обрабатываются раньше любых состояний FSM
BUSY: set[int] = set()
TG_SEND_LIMIT = 49 * 1024 * 1024


class PromoSt(StatesGroup):
    code = State()


class ModSt(StatesGroup):
    zip = State()


class SysSt(StatesGroup):
    code = State()


# ---------- меню ----------
async def render_menu(target, db: DB) -> None:
    uid = target.from_user.id
    admin = await db.is_admin(uid)
    if not await db.has_access(uid):
        await show(target, STUB_TEXT, stub_kb(), banner="locked")
        return
    u = await db.get_user(uid)
    mod = await db.get_mod(uid)
    text = menu_text(None if admin else u.balance, mod.name if mod else None, mod.main_file if mod else None, target.from_user.first_name)
    await show(target, text, menu_kb(admin, bool(mod)), banner="menu")


async def _need_access(c: CallbackQuery, db: DB) -> bool:
    if await db.has_access(c.from_user.id):
        return True
    await c.answer("Нет доступа: активируйте промокод или пригласите друзей", show_alert=True)
    return False


@cmd_router.message(CommandStart())
@cmd_router.message(Command("menu"))
async def cmd_start(m: Message, state: FSMContext, db: DB):
    await state.clear()
    await render_menu(m, db)


@cmd_router.message(Command("help"))
async def cmd_help(m: Message, state: FSMContext):
    await state.clear()
    await send(m, HELP_TEXT, kb(BACK), banner="help")


@cmd_router.message(Command("profile"))
async def cmd_profile(m: Message, state: FSMContext, db: DB):
    await state.clear()
    await _profile(m, db)


@router.callback_query(F.data == "help")
async def cb_help(c: CallbackQuery, state: FSMContext):
    await state.clear()
    await c.answer()
    await show(c, HELP_TEXT, kb(BACK), banner="help")


@router.callback_query(F.data == "profile")
async def cb_profile(c: CallbackQuery, state: FSMContext, db: DB):
    await state.clear()
    await c.answer()
    await _profile(c, db)


async def _profile(target, db: DB) -> None:
    u_tg = target.from_user
    u = await db.get_user(u_tg.id)
    admin = await db.is_admin(u_tg.id)
    st = await db.user_stats(u_tg.id)
    acts = st["acts"]
    built = acts.get("compile", (0, 0))[0] + acts.get("add_system", (0, 0))[0]
    ico, title = rank(built)
    mod = await db.get_mod(u_tg.id)
    nxt = u.ref_count % 5
    text = card(
        "👤 Профиль",
        panel(
            f"{ico} <b>{esc(short(u_tg.first_name or 'Без имени', 24))}</b> · {title}",
            f"🪪 ID: <code>{u_tg.id}</code>",
            kv("💎", "Запросов", "∞" if admin else str(u.balance)),
            f"📦 Мод: <code>{esc(short(mod.name, 30))}</code>" if mod else "📦 Мод: <i>не загружен</i>",
        ),
        "",
        panel(
            f"⚡ Успешных сборок: <b>{built}</b>",
            f"🧩 Вшито систем: <b>{acts.get('add_system', (0, 0))[0]}</b>",
            f"📦 Модов загружено: <b>{acts.get('add_mod', (0, 0))[0]}</b>",
        ),
        "",
        f"👥 Друзья: <b>{u.ref_count}</b> · до награды {bar(nxt, 5, 5)}",
    )
    await show(target, text, kb([("👥 Позвать друзей", "ref"), ("🎁 Промокод", "promo")], BACK), banner="profile")

@router.callback_query(F.data.in_({"menu", "check_sub", "cancel"}))
async def cb_menu(c: CallbackQuery, state: FSMContext, db: DB):
    await state.clear()
    await c.answer()
    await render_menu(c, db)


# ---------- промокод / рефералы ----------
@router.callback_query(F.data == "promo")
async def cb_promo(c: CallbackQuery, state: FSMContext):
    await state.set_state(PromoSt.code)
    await c.answer()
    await show(c, card("🎁 Промокод", "Отправьте промокод <b>одним сообщением</b> 👇"), kb(CANCEL), banner="promo")


@router.message(PromoSt.code, F.text, ~F.text.startswith("/"))
async def on_promo(m: Message, state: FSMContext, db: DB):
    status, n = await db.activate_promo(m.text, m.from_user.id)
    await state.clear()
    texts = {
        "ok": card("🎉 Промокод активирован", panel(f"Начислено: <b>+{n}</b> запросов 🎁")),
        "none": card("❌ Промокод не найден", "Проверьте написание и попробуйте ещё раз."),
        "used": card("⚠️ Уже использован", "Вы уже активировали этот промокод."),
        "exhausted": card("⚠️ Промокод закончился", "Лимит активаций исчерпан."),
    }
    await send(m, texts[status], kb(BACK, [("🎁 Ещё промокод", "promo")]), banner="ok" if status == "ok" else "fail")


@router.callback_query(F.data == "ref")
async def cb_ref(c: CallbackQuery, db: DB, bot: Bot):
    me = await bot.me()
    u = await db.get_user(c.from_user.id)
    link = f"https://t.me/{me.username}?start=ref_{c.from_user.id}"
    got = u.ref_count % 5
    share = f"https://t.me/share/url?url={quote(link, safe='')}&text={quote('Собирай моды SA-MP / CRMP в один клик 🔥')}"
    await c.answer()
    await show(
        c,
        card(
            "👥 Друзья",
            "За каждых <b>5</b> приглашённых друзей — <b>+2 запроса</b> 🎁",
            "",
            panel(f"🔗 Твоя ссылка:\n<code>{link}</code>"),
            "",
            f"Приглашено: <b>{u.ref_count}</b>",
            f"До награды: {bar(got, 5, 5)} ({got}/5)",
        ),
        kb([("📤 Поделиться ссылкой", "url", share)], BACK),
        banner="ref",
    )


# ---------- добавить мод ----------
@router.callback_query(F.data == "mod:add")
async def cb_mod_add(c: CallbackQuery, state: FSMContext, db: DB, cfg: Config):
    if not await _need_access(c, db):
        return
    await state.set_state(ModSt.zip)
    await c.answer()
    await show(
        c,
        card(
            "📦 Загрузить мод",
            f"Отправьте архив <b>.zip</b> файлом (до {cfg.max_zip_mb} МБ).",
            "",
            panel("📂 Внутри должна быть папка <code>gamemodes</code>", "♻️ Новый архив заменит предыдущий мод"),
        ),
        kb(CANCEL),
        banner="mod",
    )


@router.message(ModSt.zip, F.document)
async def on_zip(m: Message, state: FSMContext, db: DB, cfg: Config, bot: Bot):
    uid = m.from_user.id
    doc = m.document
    if not (doc.file_name or "").lower().endswith(".zip"):
        await m.answer("Нужен файл в формате <b>.zip</b>.", reply_markup=kb(CANCEL))
        return
    if (doc.file_size or 0) > cfg.max_zip_mb * 1024 * 1024:
        await m.answer(f"Архив больше {cfg.max_zip_mb} МБ.", reply_markup=kb(CANCEL))
        return
    if uid in BUSY:
        await m.answer("⏳ Подождите, предыдущая операция ещё выполняется.")
        return
    BUSY.add(uid)
    status = await send(m, card("📦 Загрузка мода", panel(bar(15, 100), "⏳ Скачиваю архив…")), banner="work")
    base = cfg.data_dir / "mods" / str(uid)
    new = base / "new"
    try:
        shutil.rmtree(new, ignore_errors=True)
        new.mkdir(parents=True)
        zip_path = new / "original.zip"
        await bot.download(doc, destination=zip_path)
        status = await edit(status, card("📦 Загрузка мода", panel(bar(45, 100), "📂 Распаковываю и анализирую структуру…")))
        src = new / "src"
        await asyncio.to_thread(safe_extract, zip_path, src, cfg.max_unpacked_mb << 20, cfg.max_files)
        root = find_root(src)
        main = find_main(root)
        sens = sensitive_files(root)
        n_pwn = sum(1 for _ in root.rglob("*.pwn"))
        main_kb = (root / main).stat().st_size // 1024
        cur = base / "current"
        shutil.rmtree(cur, ignore_errors=True)
        new.rename(cur)
        final_root = cur / "src" / root.relative_to(src)
        await db.save_mod(Mod(uid, doc.file_name, str(final_root), str(cur / "original.zip"), main, doc.file_size or 0, ""))
        await db.log(uid, "add_mod", True)
        lines = [
            panel(
                f"📦 <code>{esc(short(doc.file_name, 34))}</code>",
                f"📄 Main: <code>{esc(short(main, 34))}</code> ({main_kb} КБ)",
                f"🗂 Файлов .pwn: <b>{n_pwn}</b>",
            )
        ]
        if sens:
            lines += ["", "⚠️ В архиве есть файлы с данными (пароли, БД):", *[f"• <code>{esc(short(s, 40))}</code>" for s in sens[:3]]]
        await state.clear()
        await edit(status, card("✅ Мод загружен", *lines), kb([("⚡ Собрать", "mod:compile"), ("🧩 Вшить систему", "sys:add")], BACK), banner="ok")
    except ModError as e:
        shutil.rmtree(new, ignore_errors=True)
        await db.log(uid, "add_mod", False)
        await edit(status, card("❌ Не удалось загрузить мод", str(e)), kb(CANCEL), banner="fail")
    except TelegramBadRequest as e:
        shutil.rmtree(new, ignore_errors=True)
        msg = "Telegram не отдаёт боту файлы больше 20 МБ. Пришлите архив полегче (без .sql дампа и лишних плагинов) или подключите локальный Bot API сервер."
        await edit(status, card("❌ Файл не скачался", msg if "too big" in str(e).lower() else esc(short(str(e), 300))), kb(CANCEL), banner="fail")
    except Exception:
        log.exception("add_mod failed")
        shutil.rmtree(new, ignore_errors=True)
        await edit(status, card("❌ Ошибка", "Не удалось обработать архив. Попробуйте ещё раз."), kb(CANCEL), banner="fail")
    finally:
        BUSY.discard(uid)


@router.message(ModSt.zip)
async def on_zip_wrong(m: Message):
    await m.answer("Отправьте архив мода файлом <b>.zip</b>.", reply_markup=kb(CANCEL))


@router.callback_query(F.data == "mod:dl")
async def cb_dl(c: CallbackQuery, db: DB, cfg: Config):
    mod = await db.get_mod(c.from_user.id)
    if not mod:
        await c.answer("Сначала добавьте мод", show_alert=True)
        return
    await c.answer("Собираю архив…")
    out = cfg.data_dir / "tmp" / f"{c.from_user.id}.zip"
    out.parent.mkdir(parents=True, exist_ok=True)
    try:
        await asyncio.to_thread(make_zip, Path(mod.root), out)
        if out.stat().st_size > TG_SEND_LIMIT:
            await c.message.answer("Архив больше 50 МБ — Telegram не даёт отправить его ботом.")
        else:
            await c.message.answer_document(FSInputFile(out, filename=f"{Path(mod.name).stem}_build.zip"), caption="📦 <b>Текущая версия мода</b>")
    finally:
        out.unlink(missing_ok=True)


# ---------- добавить систему ----------
@router.callback_query(F.data == "sys:add")
async def cb_sys_add(c: CallbackQuery, state: FSMContext, db: DB):
    if not await _need_access(c, db):
        return
    if not await db.get_mod(c.from_user.id):
        await c.answer("Сначала добавьте мод", show_alert=True)
        return
    await state.set_state(SysSt.code)
    await c.answer()
    await show(
        c,
        card(
            "🧩 Вшить систему",
            "Отправьте файл <b>.pwn</b> / <b>.inc</b> или вставьте код сообщением.",
            "",
            panel(
                "🔎 найду места для вставки",
                "🔗 подключу колбэки и инклуды",
                "🛠 соберу и починю ошибки",
            ),
            "",
            "💎 Спишется <b>1 запрос</b> — только за успешную сборку.",
        ),
        kb(CANCEL),
        banner="system",
    )


@router.message(SysSt.code, F.document)
async def on_sys_doc(m: Message, state: FSMContext, db: DB, cfg: Config, ai: AIFixer, bot: Bot):
    doc = m.document
    name = doc.file_name or "system.pwn"
    if not name.lower().endswith((".pwn", ".inc", ".txt")):
        await m.answer("Принимаю файлы <b>.pwn</b>, <b>.inc</b> или текст кода.", reply_markup=kb(CANCEL))
        return
    if (doc.file_size or 0) > 3 * 1024 * 1024:
        await m.answer("Файл системы больше 3 МБ.", reply_markup=kb(CANCEL))
        return
    buf = io.BytesIO()
    await bot.download(doc, destination=buf)
    if name.lower().endswith(".txt"):
        name = name[:-4] + ".pwn"
    await _system_job(m, state, db, cfg, ai, bot, name, buf.getvalue())


@router.message(SysSt.code, F.text, ~F.text.startswith("/"))
async def on_sys_text(m: Message, state: FSMContext, db: DB, cfg: Config, ai: AIFixer, bot: Bot):
    await _system_job(m, state, db, cfg, ai, bot, "system.pwn", m.text.encode("utf-8"))


async def _system_job(m, state, db, cfg, ai, bot, name: str, raw: bytes):
    await state.clear()
    status = await send(m, card("🧩 Вшиваю систему", panel(bar(5, 100), "⏳ Запускаю…")), banner="work")
    await run_job(bot, db, cfg, ai, status, m.from_user.id, "add_system", name, raw)


# ---------- компиляция ----------
@router.callback_query(F.data == "mod:compile")
async def cb_compile(c: CallbackQuery, db: DB, cfg: Config, ai: AIFixer, bot: Bot):
    if not await _need_access(c, db):
        return
    if not await db.get_mod(c.from_user.id):
        await c.answer("Сначала добавьте мод", show_alert=True)
        return
    await c.answer()
    status = await show(c, card("⚡ Сборка мода", panel(bar(5, 100), "⏳ Запускаю…")), banner="work")
    await run_job(bot, db, cfg, ai, status, c.from_user.id, "compile")


# ---------- общий конвейер ----------
def _pct(text: str) -> float:
    """Грубая оценка прогресса по тексту шага автофикса."""
    m = re.search(r"попытка (\d+)", text)
    n = int(m[1]) if m else 1
    if "ИИ" in text:
        return min(40 + n * 5, 92)
    if "Компиляция" in text:
        return min(25 + n * 4, 85)
    return 12


async def run_job(bot: Bot, db: DB, cfg: Config, ai: AIFixer, status: Message, uid: int, kind: str, filename: str | None = None, raw: bytes | None = None):
    title = "🧩 Вшиваю систему" if kind == "add_system" else "⚡ Сборка мода"
    cur = [status]  # карточка может смениться (фото ↔ текст), поэтому держим актуальную в списке

    async def progress(text: str):
        try:
            cur[0] = await edit(cur[0], card(title, panel(bar(_pct(text), 100), text)))
        except Exception:
            pass

    if uid in BUSY:
        await progress("⏳ Предыдущая операция ещё выполняется.")
        return
    mod = await db.get_mod(uid)
    admin = await db.is_admin(uid)
    if not mod or not (admin or await db.has_access(uid)):
        await edit(cur[0], card("🔒 Нет доступа", "Нужен мод и хотя бы 1 запрос."), kb(BACK), banner="locked")
        return

    BUSY.add(uid)
    ws = Workspace(Path(mod.root))
    try:
        own: set[str] = set()
        prefix = ""
        info = None
        if kind == "add_system":
            await progress("🧩 Анализирую структуру мода и вшиваю систему…")
            info = await asyncio.to_thread(integrate, ws, mod.main_file, filename, raw)
            own, prefix = {info.rel}, info.prefix
        rep = await autofix(cfg, ai, ws, mod.main_file, progress, own, prefix)
        ok = rep.ok
        await db.log(uid, kind, ok)

        if ok:
            if not admin:
                await db.spend(uid)
            res = rep.result
            amx = ws.root / res.amx_rel
            stats = [
                f"⏱ Время: <b>{res.seconds:.0f} с</b> · попыток: <b>{rep.rounds}</b>",
                f"⚠️ Предупреждений: <b>{len(res.warnings)}</b>",
            ]
            if info:
                stats.insert(
                    0,
                    f"🧩 <code>{esc(short(info.rel, 36))}</code>",
                )
                stats.insert(1, f"🔗 Колбэков подключено: <b>{len(info.injected)}</b>")
            lines = [panel(bar(100, 100), *stats)]
            if info and info.warnings:
                lines += ["", *[f"⚠️ {esc(short(w, 90))}" for w in info.warnings[:2]]]
            if rep.changes:
                lines += ["", f"🔧 Автоисправлений: <b>{len(rep.changes)}</b>"]
                lines += [f"• {esc(short(c, 80))}" for c in rep.changes[:4]]
            await edit(
                cur[0],
                card("✅ Готово!", *lines),
                kb([("⬇️ Архив мода", "mod:dl"), ("🧩 Ещё систему", "sys:add")], BACK),
                banner="ok",
            )
            if amx.stat().st_size <= TG_SEND_LIMIT:
                await bot.send_document(uid, FSInputFile(amx, filename=amx.name), caption="🎮 <b>Готовый .amx</b>")
            else:
                await bot.send_message(uid, "Файл .amx больше 50 МБ — скачайте архив мода.")
        else:
            ws.rollback()
            res = rep.result
            lines = []
            if res and res.errors:
                lines.append("<pre>" + esc("\n".join(short(d.short(), 110) for d in res.errors[:4])) + "</pre>")
            if rep.reason:
                lines.append(esc(short(rep.reason, 300)))
            lines += ["", "↩️ Изменения откачены, запрос не списан."]
            await edit(cur[0], card("❌ Не удалось собрать", *lines), kb([("🔁 Повторить", "mod:compile")], BACK), banner="fail")
    except ModError as e:
        ws.rollback()
        await db.log(uid, kind, False)
        await edit(cur[0], card("❌ Ошибка", str(e)), kb(BACK), banner="fail")
    except Exception:
        log.exception("job failed")
        ws.rollback()
        await db.log(uid, kind, False)
        await edit(cur[0], card("❌ Внутренняя ошибка", "Изменения откачены, запрос не списан."), kb(BACK), banner="fail")
    finally:
        BUSY.discard(uid)


# ---------- всё остальное ----------
@router.message(F.chat.type == "private")
async def fallback(m: Message, state: FSMContext, db: DB):
    await state.clear()
    await render_menu(m, db)
