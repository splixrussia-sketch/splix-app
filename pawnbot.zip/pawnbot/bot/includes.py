"""Инклюды без учёта регистра: моды делались на Windows (mxINI ≙ mxini.inc), а Linux-pawncc регистр различает.

Перед компиляцией сканируем #include во всех .pwn/.inc, ищем файл без учёта регистра по всему архиву
и кладём копию с точным именем в служебную папку SHIM_DIR, которая подключается через -i.
Исходники мода не трогаем."""
from __future__ import annotations

import os
import re
import shutil
from pathlib import Path

from .modtools import read_text

SHIM_DIR = ".incshim"
INC_RE = re.compile(r'^\s*#\s*(?:try)?include\s*([<"])\s*([^>"\r\n]+?)\s*[>"]', re.M | re.I)
EXTS = ("", ".inc", ".p", ".pwn")
STD = {"a_samp", "a_npc", "a_objects", "a_players", "a_sampdb", "a_vehicles", "a_actor", "core", "float",
       "string", "file", "time", "console", "datagram", "omp", "open.mp", "omp_", "a_http"}


def _norm(ref: str) -> str:
    ref = re.sub(r"/+", "/", ref.replace("\\", "/").strip())
    while ref.startswith(("./", "../")):
        ref = ref[3:] if ref.startswith("../") else ref[2:]
    return ref.lstrip("/")


def _index(root: Path) -> dict[str, list[Path]]:
    idx: dict[str, list[Path]] = {}
    for dp, dirs, files in os.walk(root):
        dirs[:] = [d for d in dirs if d != SHIM_DIR]
        for f in files:
            p = Path(dp) / f
            idx.setdefault(f.lower(), []).append(p)
    return idx


def _rank(p: Path, root: Path) -> int:
    rel = p.relative_to(root).as_posix().lower()
    for i, pref in enumerate(("pawno/include/", "qawno/include/", "include/", "gamemodes/")):
        if rel.startswith(pref):
            return i
    return 9


def prepare_includes(root: Path) -> tuple[bool, list[str]]:
    """Возвращает (shim создан?, список инклюдов, которых нет в архиве вообще)."""
    shim = root / SHIM_DIR
    shutil.rmtree(shim, ignore_errors=True)
    idx = _index(root)
    refs: set[str] = set()
    for p in root.rglob("*"):
        if p.suffix.lower() in (".pwn", ".inc", ".p") and p.is_file() and SHIM_DIR not in p.parts:
            try:
                for m in INC_RE.finditer(read_text(p)):
                    refs.add(_norm(m[2]))
            except OSError:
                pass
    made = False
    missing: list[str] = []
    for ref in sorted(refs):
        if not ref or ref.lower() in STD:
            continue
        found: Path | None = None
        want_ext = ""
        for ext in EXTS:
            tail = (ref + ext).lower()
            base = tail.rsplit("/", 1)[-1]
            cands = [c for c in idx.get(base, [])
                     if c.relative_to(root).as_posix().lower().endswith(tail)]
            if cands:
                found = min(cands, key=lambda c: _rank(c, root))
                want_ext = ext
                break
        if found is None:
            missing.append(ref)
            continue
        dest = shim / (ref + want_ext)
        if dest.exists():
            continue
        try:
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(found, dest)
            made = True
        except OSError:
            pass
    return made, missing


def cleanup_includes(root: Path) -> None:
    shutil.rmtree(root / SHIM_DIR, ignore_errors=True)
