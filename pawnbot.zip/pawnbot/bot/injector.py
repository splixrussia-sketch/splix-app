"""Умное вшивание системы (.pwn / .inc / фрагмент кода) в мод.

Логика:
1. Файл кладётся в gamemodes/systems/ (.pwn) или include/ (.inc).
2. Стандартные колбэки системы (public OnPlayerConnect и т.д.) переименовываются в sN_OnPlayerConnect и
   вызываются из «головного» колбэка мода — так не бывает дубликатов public-функций, а порядок
   выполнения остаётся предсказуемым. Системы, которые уже используют ALS-цепочки (#define _ALS_On...),
   подключаются как есть, в шапке файла.
3. #include вставляется в нужное место главного .pwn.
Дальше работает цикл автофикса (fixer.py).
"""
from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, field
from pathlib import Path

from .modtools import ModError, Workspace, decode_upload, detect_newline

# имя колбэка -> «обработан ли» (если система вернула 1, дальше не идём)
STD: dict[str, bool] = {
    "OnGameModeInit": False, "OnGameModeExit": False,
    "OnPlayerConnect": False, "OnPlayerDisconnect": False, "OnPlayerSpawn": False, "OnPlayerDeath": False,
    "OnVehicleSpawn": False, "OnVehicleDeath": False, "OnPlayerText": False, "OnPlayerCommandText": True,
    "OnPlayerEnterVehicle": False, "OnPlayerExitVehicle": False, "OnPlayerStateChange": False,
    "OnPlayerEnterCheckpoint": False, "OnPlayerLeaveCheckpoint": False,
    "OnPlayerEnterRaceCheckpoint": False, "OnPlayerLeaveRaceCheckpoint": False,
    "OnPlayerRequestClass": False, "OnPlayerRequestSpawn": False, "OnPlayerPickUpPickup": False,
    "OnPlayerSelectedMenuRow": False, "OnPlayerExitedMenu": False, "OnPlayerInteriorChange": False,
    "OnPlayerKeyStateChange": False, "OnPlayerUpdate": False, "OnPlayerClickPlayer": False,
    "OnPlayerClickTextDraw": True, "OnPlayerClickPlayerTextDraw": True, "OnDialogResponse": True,
    "OnPlayerGiveDamage": False, "OnPlayerTakeDamage": False, "OnPlayerWeaponShot": False,
    "OnPlayerEditObject": False, "OnPlayerEditAttachedObject": False, "OnPlayerSelectObject": False,
    "OnPlayerEnterDynamicCP": False, "OnPlayerLeaveDynamicCP": False, "OnPlayerPickUpDynamicPickup": False,
    "OnPlayerEnterDynamicArea": False, "OnPlayerLeaveDynamicArea": False,
    "OnVehicleMod": False, "OnVehicleStreamIn": False, "OnVehicleStreamOut": False,
    "OnPlayerStreamIn": False, "OnPlayerStreamOut": False, "OnRconCommand": True,
}

STATE_FILE = ".bot_systems.json"


@dataclass
class Integration:
    n: int
    rel: str
    prefix: str
    mode: str  # hooks | als | plain-file
    injected: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    include_line: str = ""


def param_names(params: str) -> list[str] | None:
    names: list[str] = []
    for part in params.split(","):
        part = part.strip()
        if not part:
            continue
        if "..." in part:
            return None
        part = part.split("=")[0].strip()
        part = re.sub(r"\[[^\]]*\]", "", part).replace("&", "").strip()
        tok = re.split(r"[\s:]+", part)[-1]
        if not re.fullmatch(r"[A-Za-z_@][\w@]*", tok):
            return None
        names.append(tok)
    return names


def find_callbacks(code: str) -> dict[str, str]:
    res: dict[str, str] = {}
    for m in re.finditer(r"^[ \t]*public[ \t]+(On\w+)[ \t]*\(([^)]*)\)", code, re.M):
        if m[1] in STD:
            res.setdefault(m[1], re.sub(r"\s+", " ", m[2]).strip())
    return res


def uses_als(code: str) -> bool:
    if re.search(r"^[ \t]*#[ \t]*define[ \t]+_ALS_On", code, re.M):
        return True
    return any(re.search(rf"^[ \t]*#[ \t]*define[ \t]+{n}\b", code, re.M) for n in STD)


def find_head(text: str, name: str):
    """Первое «настоящее» определение public OnX (до любых #define OnX — после них имя уже подменено ALS)."""
    d = re.search(rf"^[ \t]*#[ \t]*define[ \t]+{name}\b", text, re.M)
    limit = d.start() if d else len(text)
    for m in re.finditer(rf"^[ \t]*public[ \t]+{name}[ \t]*\(([^)]*)\)", text, re.M):
        if m.start() >= limit:
            return None
        k = m.end()
        while k < len(text) and text[k] in " \t\r\n":
            k += 1
        if k < len(text) and text[k] == "{":
            return m, k
        return None
    return None


def _header_pos(text: str) -> int:
    fp = re.search(r"^[ \t]*(?:public|forward|stock|main)\b", text, re.M)
    limit = fp.start() if fp else len(text)
    pos = 0
    for m in re.finditer(r"^[ \t]*#[ \t]*include[^\n]*\n", text, re.M):
        if m.end() <= limit:
            pos = m.end()
        else:
            break
    return pos


def _load_state(ws: Workspace) -> dict:
    if ws.exists(STATE_FILE):
        try:
            return json.loads(ws.read(STATE_FILE))
        except ValueError:
            pass
    return {"n": 0, "items": []}


def _apply(text: str, edits: list[tuple[int, str]]) -> str:
    for pos, ins in sorted(edits, key=lambda e: e[0], reverse=True):
        text = text[:pos] + ins + text[pos:]
    return text


def integrate(ws: Workspace, main_rel: str, filename: str, raw: bytes) -> Integration:
    code = decode_upload(raw)
    if len(code.strip()) < 10:
        raise ModError("Файл системы пустой.")
    main_text = ws.read(main_rel)
    nl = detect_newline(main_text)
    code = code.replace("\r\n", "\n")
    if nl == "\r\n":
        code = code.replace("\n", "\r\n")

    state = _load_state(ws)
    n = int(state.get("n", 0)) + 1
    if n > 99:
        raise ModError("Достигнут лимит вшитых систем (99) для одного мода.")
    prefix = f"s{n}_"

    stem = re.sub(r"[^A-Za-z0-9_]+", "_", Path(filename).stem).strip("_") or "system"
    is_inc = filename.lower().endswith(".inc")
    folder, ext = ("include", ".inc") if is_inc else ("gamemodes/systems", ".pwn")
    rel = f"{folder}/{stem}{ext}"
    if ws.exists(rel):
        rel = f"{folder}/{stem}_{n}{ext}"

    callbacks = find_callbacks(code)
    als = uses_als(code)
    mode = "als" if als else ("hooks" if callbacks else "plain-file")
    info = Integration(n=n, rel=rel, prefix=prefix, mode=mode)

    # 1. переименование колбэков системы
    renamed: dict[str, str] = {}
    if mode == "hooks":
        for name, params in callbacks.items():
            new = prefix + name
            code = re.sub(rf"^[ \t]*forward[ \t]+{name}[ \t]*\([^;\r\n]*\)[ \t]*;?[ \t]*\r?\n", "", code, flags=re.M)
            code = re.sub(rf"(?<![\w@]){name}(?![\w@])", new, code)
            renamed[name] = new

    # 2. правки главного файла (+ других файлов, если «голова» колбэка определена там)
    edits: dict[str, list[tuple[int, str]]] = {main_rel: []}
    texts: dict[str, str] = {main_rel: main_text}
    appended: list[str] = []
    others: list[str] | None = None

    for name, new in renamed.items():
        sys_params = callbacks[name]
        handled = STD[name]
        head_rel, head = main_rel, find_head(main_text, name)
        if head is None:
            if others is None:
                root = ws.root
                others = []
                for sub in ("gamemodes", "include"):
                    for p in sorted((root / sub).rglob("*")):
                        if p.suffix.lower() in (".pwn", ".inc") and p.is_file():
                            r = p.relative_to(root).as_posix()
                            if r != main_rel and r != rel:
                                others.append(r)
            for r in others:
                t = texts.get(r) or ws.read(r)
                h = find_head(t, name)
                if h:
                    texts[r], head_rel, head = t, r, h
                    edits.setdefault(r, [])
                    break
        if head is None:
            names = param_names(sys_params)
            if names is None:
                info.warnings.append(f"{name}: не смог разобрать параметры — колбэк не подключён")
                continue
            call = f"{new}({', '.join(names)});"
            body = f"if ({new}({', '.join(names)})) return 1;" if handled else call
            appended.append(
                f"forward {new}({sys_params});{nl}public {name}({sys_params}){nl}{{{nl}\t{body}{nl}"
                f"\treturn {0 if handled else 1};{nl}}}{nl}"
            )
            info.warnings.append(f"{name}: в моде нет такого колбэка — создан новый в конце файла")
            info.injected.append(name)
            continue
        m, brace = head
        names = param_names(m[1]) or param_names(sys_params)
        if names is None:
            info.warnings.append(f"{name}: не смог разобрать параметры — колбэк не подключён")
            continue
        args = ", ".join(names)
        call = f"if ({new}({args})) return 1;" if handled else f"{new}({args});"
        edits[head_rel].append((m.start(), f"forward {new}({sys_params});{nl}"))
        edits[head_rel].append((brace + 1, f"{nl}\t{call}"))
        info.injected.append(name)

    # 3. #include
    inc_path = os.path.relpath(rel, str(Path(main_rel).parent)).replace("\\", "/")
    info.include_line = f'#include "{inc_path}"'
    if mode == "plain-file" and not is_inc or mode == "hooks" and not is_inc:
        end = len(main_text)
        prefix_nl = "" if main_text.endswith("\n") or not main_text else nl
        edits[main_rel].append((end, f"{prefix_nl}{nl}{info.include_line}{nl}"))
    else:
        edits[main_rel].append((_header_pos(main_text), f"{info.include_line}{nl}"))

    # 4. запись
    ws.write(rel, code if code.endswith("\n") else code + nl)
    for r, ed in edits.items():
        if not ed:
            continue
        new_text = _apply(texts[r], ed)
        if r == main_rel and appended:
            new_text += nl + nl.join(appended)
        ws.write(r, new_text)
    if appended and not edits[main_rel]:
        ws.write(main_rel, main_text + nl + nl.join(appended))

    state["n"] = n
    state.setdefault("items", []).append({"n": n, "file": rel, "mode": mode})
    ws.write(STATE_FILE, json.dumps(state, ensure_ascii=True))
    return info
