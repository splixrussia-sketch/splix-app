from __future__ import annotations

import asyncio
import logging

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.client.session.aiohttp import AiohttpSession
from aiogram.client.telegram import TelegramAPIServer
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import BotCommand, MenuButtonWebApp, WebAppInfo

from . import handlers_admin, handlers_ftp, handlers_user
from .ai import AIFixer
from .config import load_config
from .db import DB
from .deploy import DeployManager
from .middleware import SubscriptionMiddleware, UserMiddleware
from .webapp import start_webapp


async def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    cfg = load_config()
    db = DB(cfg.data_dir / "bot.db")
    await db.init(cfg.owner_id)
    await db.upsert_user(cfg.owner_id, None, "Owner")
    ai = AIFixer(cfg)
    if not ai.enabled:
        logging.warning("AI_API_KEY не задан — автоисправление ошибок кода отключено (компиляция и вшивание работают).")

    session = None
    if cfg.telegram_api_url:
        session = AiohttpSession(api=TelegramAPIServer.from_base(cfg.telegram_api_url, is_local=True))
    bot = Bot(
        cfg.bot_token,
        session=session,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML, link_preview_is_disabled=True),
    )

    deployer = DeployManager(cfg, db, ai, handlers_user.BUSY)
    dp = Dispatcher(storage=MemoryStorage(), db=db, cfg=cfg, ai=ai, deployer=deployer)
    for observer in (dp.message, dp.callback_query):
        observer.outer_middleware(UserMiddleware(db))
        observer.outer_middleware(SubscriptionMiddleware(db))
    dp.include_routers(
        handlers_user.cmd_router,
        handlers_ftp.cmd_router,
        handlers_admin.cmd_router,
        handlers_admin.router,
        handlers_ftp.router,
        handlers_user.router,  # содержит «ловушку» всех сообщений — должен идти последним
    )

    await bot.set_my_commands(
        [
            BotCommand(command="start", description="♟ Главное меню"),
            BotCommand(command="ftp", description="🚀 Залить мод на FTP"),
            BotCommand(command="profile", description="👤 Мой профиль"),
            BotCommand(command="help", description="❓ Как это работает"),
        ]
    )
    try:  # красивое описание в карточке бота (необязательно)
        await bot.set_my_short_description("♟ Pawn Forge — вшиваю системы в моды SA-MP / CRMP, собираю и сам чиню ошибки.")
        await bot.set_my_description(
            "♟ Pawn Forge\n\nЗагрузи мод SA-MP / CRMP, пришли систему (.pwn / .inc) — "
            "я вошью её, скомпилирую и сам исправлю ошибки. Готовый .amx — тебе.\n\nНажми «Начать» 👇"
        )
    except Exception as e:
        logging.warning("Не удалось обновить описание бота: %s", e)
    runner = None
    if cfg.webapp_url:  # Mini App: свой HTTP-сервер (HTTPS даёт Caddy) + кнопка меню у бота
        runner = await start_webapp(cfg, db, bot, deployer)
        try:
            await bot.set_chat_menu_button(menu_button=MenuButtonWebApp(text="🚀 FTP", web_app=WebAppInfo(url=cfg.webapp_url)))
        except Exception as e:
            logging.warning("Не удалось поставить кнопку Mini App: %s", e)
    await bot.delete_webhook(drop_pending_updates=True)
    me = await bot.me()
    logging.info("Бот @%s запущен", me.username)
    try:
        await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())
    finally:
        if runner:
            await runner.cleanup()
        await bot.session.close()


if __name__ == "__main__":
    asyncio.run(main())
