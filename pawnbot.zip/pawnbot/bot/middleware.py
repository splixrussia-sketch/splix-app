from __future__ import annotations

import logging
import re
import time

from aiogram import BaseMiddleware
from aiogram.types import CallbackQuery, Message

from .db import DB
from .ui import card, kb, show

log = logging.getLogger("mw")


class UserMiddleware(BaseMiddleware):
    """Регистрирует/обновляет пользователя до любых проверок (чтобы реферал не терялся)."""

    def __init__(self, db: DB):
        self.db = db

    async def __call__(self, handler, event, data):
        u = data.get("event_from_user")
        if u and not u.is_bot:
            ref = None
            if isinstance(event, Message) and event.text and event.text.startswith("/start"):
                parts = event.text.split(maxsplit=1)
                if len(parts) > 1:
                    m = re.fullmatch(r"ref_(\d+)", parts[1].strip())
                    if m:
                        ref = int(m[1])
            await self.db.upsert_user(u.id, u.username, u.first_name, ref)
        return await handler(event, data)


class SubscriptionMiddleware(BaseMiddleware):
    """Обязательная подписка (ОП). Админы проходят без проверки. После прохождения засчитывает реферала."""

    def __init__(self, db: DB):
        self.db = db
        self._ok_until: dict[int, float] = {}

    async def _missing(self, bot, uid: int):
        missing = []
        for ch in await self.db.list_channels():
            try:
                mem = await bot.get_chat_member(ch.chat_id, uid)
                if mem.status in ("left", "kicked"):
                    missing.append(ch)
            except Exception as e:  # бот не админ канала и т.п. — не блокируем людей из-за настроек
                log.warning("ОП: не могу проверить %s: %s", ch.chat_id, e)
        return missing

    async def __call__(self, handler, event, data):
        u = data.get("event_from_user")
        bot = data["bot"]
        if not u or u.is_bot:
            return await handler(event, data)

        is_admin = await self.db.is_admin(u.id)
        missing = []
        if not is_admin and self._ok_until.get(u.id, 0) < time.monotonic():
            missing = await self._missing(bot, u.id)
            if not missing:
                self._ok_until[u.id] = time.monotonic() + 30

        if missing:
            rows = [[(f"📢 {c.title}", "url", c.link)] for c in missing]
            rows.append([("✅ Проверить подписку", "check_sub")])
            text = card("🔒 Обязательная подписка", "Чтобы пользоваться ботом, подпишитесь на каналы ниже и нажмите «Проверить» 👇")
            if isinstance(event, CallbackQuery) and event.data == "check_sub":
                await event.answer("Подписка не найдена 🙁", show_alert=True)
                return None
            if isinstance(event, CallbackQuery):
                await event.answer()
            await show(event, text, kb(*rows), banner="sub")
            return None

        rf = await self.db.credit_referral(u.id)
        if rf and rf[2]:
            try:
                await bot.send_message(
                    rf[0],
                    card("🎉 Бонус за друзей", f"Приглашено: <b>{rf[1]}</b>", "Вам начислено <b>+2 запроса</b> 🎁"),
                )
            except Exception:
                pass
        return await handler(event, data)
