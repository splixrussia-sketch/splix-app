"""Работа с архивом мода: безопасная распаковка, поиск структуры, кодировка cp1251, откат правок."""
from __future__ import annotations

import os
import re
import zipfile
from pathlib import Path, PurePosixPath

ENC = "cp1251"


class ModError(Exception):
    """Ошибка, текст которой можно показать пользователю."""


# ---------- текст (cp1251 без потерь) ----------
def decode_bytes(b: bytes) -> str:
    return b.decode(ENC, errors="surrogateescape")


def encode_text(s: str) -> bytes:
    try:
        return s.encode(ENC, errors="surrogateescape")
    except UnicodeEncodeError:
        out = bytearray()
        for ch in s:
            try:
                out += ch.encode(ENC, errors="surrogateescape")
            except UnicodeEncodeError:
                out += b"?"
        return bytes(out)


def read_text(p: Path) -> str:
    return decode_bytes(p.read_bytes())


def write_text(p: Path, s: str) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(encode_text(s))


def printable(s: str) -> str:
    """Строка, безопасная для JSON/Telegram (битые байты → '?')."""
    return s.encode("utf-8", errors="replace").decode("utf-8")


def detect_newline(text: str) -> str:
    return "\r\n" if text.count("\r\n") > text.count("\n") / 2 else "\n"


def decode_upload(raw: bytes) -> str:
    """Загруженный пользователем код: UTF-8 (с BOM или без) → текст, иначе считаем, что это уже cp1251."""
    if raw.startswith(b"\xef\xbb\xbf"):
        raw = raw[3:]
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError:
        return decode_bytes(raw)


# ---------- распаковка ----------
def safe_extract(zip_path: Path, dest: Path, max_unpacked: int, max_files: int) -> None:
    try:
        z = zipfile.ZipFile(zip_path)
    except zipfile.BadZipFile as e:
        raise ModError("Файл не похож на корректный .zip архив.") from e
    with z:
        infos = z.infolist()
        if len(infos) > max_files:
            raise ModError(f"В архиве слишком много файлов (> {max_files}).")
        dest = dest.resolve()
        dest.mkdir(parents=True, exist_ok=True)
        total = 0
        for info in infos:
            name = info.filename.replace("\\", "/")
            parts = PurePosixPath(name).parts
            if name.startswith("/") or ".." in parts:
                raise ModError("В архиве найден небезопасный путь (../). Распаковка остановлена.")
            if (info.external_attr >> 16) & 0o170000 == 0o120000:  # symlink — пропускаем
                continue
            target = (dest / name).resolve()
            if target != dest and dest not in target.parents:
                raise ModError("В архиве найден небезопасный путь. Распаковка остановлена.")
            if info.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            try:
                target.parent.mkdir(parents=True, exist_ok=True)
                with z.open(info) as src, open(target, "wb") as out:
                    while chunk := src.read(1 << 20):
                        total += len(chunk)
                        if total > max_unpacked:
                            raise ModError(f"Распакованный размер больше {max_unpacked // (1 << 20)} МБ.")
                        out.write(chunk)
            except OSError:
                continue  # файл с нечитаемым именем — не критично для сборки


def find_root(dest: Path) -> Path:
    if (dest / "gamemodes").is_dir():
        return dest
    for pat in ("*/gamemodes", "*/*/gamemodes"):
        for p in sorted(dest.glob(pat)):
            if p.is_dir():
                return p.parent
    raise ModError("Не нашёл папку <code>gamemodes</code> в архиве. Структура должна быть как у сервера SA-MP / CRMP.")


def find_main(root: Path) -> str:
    gm = root / "gamemodes"
    cfg = root / "server.cfg"
    if cfg.is_file():
        for line in read_text(cfg).splitlines():
            m = re.match(r"\s*gamemode\d*\s+(\S+)", line)
            if m:
                p = gm / (m.group(1) + ".pwn")
                if p.is_file():
                    return p.relative_to(root).as_posix()
    pwns = sorted(gm.glob("*.pwn"), key=lambda p: p.stat().st_size, reverse=True)
    if not pwns:
        raise ModError("В папке <code>gamemodes</code> нет ни одного .pwn файла.")
    return pwns[0].relative_to(root).as_posix()


def sensitive_files(root: Path) -> list[str]:
    found = []
    for p in root.rglob("*"):
        if not p.is_file():
            continue
        n = p.name.lower()
        if n in ("server.cfg", "server.cfg.bak", ".env") or n.endswith(".sql") or ("mysql" in n and n.endswith((".ini", ".cfg"))):
            found.append(p.relative_to(root).as_posix())
            if len(found) >= 8:
                break
    return found


def include_dirs(root: Path) -> list[str]:
    return [d for d in ("pawno/include", "qawno/include", "include") if (root / d).is_dir()]


def read_flags(root: Path) -> list[str]:
    cfg = root / "pawno" / "pawn.cfg"
    flags: list[str] = []
    if cfg.is_file():
        for tok in read_text(cfg).split():
            if tok.startswith("-") and not tok.startswith(("-i", "-o", "-D", "-e", "-w")):
                flags.append(tok)
    return flags or ["-S4096", "-O1", "-v2", "-d0"]


def make_zip(root: Path, out_path: Path) -> None:
    base = root.name or "mod"
    with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for dirpath, _dirs, files in os.walk(root):
            _dirs[:] = [d for d in _dirs if d != ".incshim"]
            for f in files:
                full = Path(dirpath) / f
                if full.is_symlink():
                    continue
                z.write(full, f"{base}/{full.relative_to(root).as_posix()}")


# ---------- рабочая область с откатом ----------
class Workspace:
    def __init__(self, root: Path):
        self.root = root.resolve()
        self.orig: dict[str, bytes | None] = {}

    def _p(self, rel: str) -> Path:
        p = (self.root / rel).resolve()
        if p != self.root and self.root not in p.parents:
            raise ModError(f"Путь вне проекта: {rel}")
        return p

    def exists(self, rel: str) -> bool:
        return self._p(rel).is_file()

    def snapshot(self, rel: str) -> None:
        if rel not in self.orig:
            p = self._p(rel)
            self.orig[rel] = p.read_bytes() if p.is_file() else None

    def read(self, rel: str) -> str:
        return read_text(self._p(rel))

    def write(self, rel: str, text: str) -> None:
        self.snapshot(rel)
        write_text(self._p(rel), text)

    def rollback(self) -> None:
        for rel, data in self.orig.items():
            p = self._p(rel)
            if data is None:
                p.unlink(missing_ok=True)
            else:
                p.write_bytes(data)
        self.orig.clear()

    def checkpoint(self) -> dict[str, bytes]:
        """Текущее содержимое всех уже изменённых файлов (для отката одного раунда)."""
        return {rel: self._p(rel).read_bytes() for rel in self.orig if self._p(rel).is_file()}

    def revert_to(self, cp: dict[str, bytes]) -> None:
        for rel in list(self.orig):
            p = self._p(rel)
            if rel in cp:
                p.write_bytes(cp[rel])
            else:  # файл тронут только в этом раунде — вернуть оригинал
                data = self.orig.pop(rel)
                if data is None:
                    p.unlink(missing_ok=True)
                else:
                    p.write_bytes(data)

    def changed(self) -> list[str]:
        return sorted(self.orig)
