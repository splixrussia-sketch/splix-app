"""Грубый разбор Pawn-кода: границы функций по скобкам (без учёта строк и комментариев)."""
from __future__ import annotations

import re

_HEAD = re.compile(r"^\s*(?:(?:public|stock|static|forward|native)\s+)*(?:[A-Za-z_@][\w@]*:)?\s*[A-Za-z_@][\w@]*\s*\(")
_CTRL = ("if", "else", "for", "while", "switch", "do", "return", "case", "new", "default", "break", "continue",
         "goto", "assert", "sizeof", "#")
_STR = re.compile(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'')


def _code(line: str) -> str:
    line = _STR.sub('""', line)
    return line.split("//", 1)[0]


def _is_head(lines: list[str], j: int) -> bool:
    ln = _code(lines[j]).strip()
    if not ln or ln.endswith(";") or not _HEAD.match(ln):
        return False
    word = re.match(r"[A-Za-z_@#][\w@]*", ln)
    if word and word.group(0) in _CTRL:
        return False
    if "{" in ln:
        return True
    for k in range(j + 1, min(j + 6, len(lines))):
        nxt = _code(lines[k]).strip()
        if nxt:
            return nxt.startswith("{")
    return False


def _body_end(lines: list[str], j: int) -> int:
    depth, seen = 0, False
    for k in range(j, len(lines)):
        for ch in _code(lines[k]):
            if ch == "{":
                depth += 1
                seen = True
            elif ch == "}":
                depth -= 1
        if seen and depth <= 0:
            return k
    return len(lines) - 1


def functions(lines: list[str]) -> list[tuple[int, int]]:
    """Все функции верхнего уровня одним проходом: [(первая_строка, последняя_строка)], 0-based.
    Работает и для гигантских функций (OnDialogResponse на тысячи строк)."""
    res: list[tuple[int, int]] = []
    depth, start, opened = 0, None, False
    for idx, line in enumerate(lines):
        if line.lstrip().startswith("#"):
            continue
        code = _code(line)
        if depth == 0 and start is None and _is_head(lines, idx):
            start, opened = idx, False
        for ch in code:
            if ch == "{":
                depth += 1
                opened = True
            elif ch == "}" and depth > 0:
                depth -= 1
        if start is not None:
            if opened and depth == 0:
                res.append((start, idx))
                start = None
            elif not opened and idx - start > 6:
                start = None  # ложный заголовок
    return res


def func_span(lines: list[str], i: int) -> tuple[int, int] | None:
    """Границы (0-based, включительно) функции, содержащей строку i, или None."""
    for a, b in functions(lines):
        if a <= i <= b:
            return a, b
    return None
