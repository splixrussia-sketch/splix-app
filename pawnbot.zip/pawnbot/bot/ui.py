"""Pawn Forge — единый визуальный стиль.

* каждый экран — «фото-карточка»: баннер из bot/assets + подпись + inline-кнопки;
* переходы между экранами идут правкой одного сообщения (edit_media / edit_caption), без спама;
* если подпись не влезает в лимит Telegram (1024), экран автоматически показывается обычным текстом.
"""
from __future__ import annotations

import html
import logging
from pathlib import Path
from typing import Union

from aiogram.exceptions import TelegramBadRequest
from aiogram.types import (
    WebAppInfo,
    CallbackQuery,
    FSInputFile,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    InputMediaPhoto,
    Message,
)

log = logging.getLogger("ui")

BRAND = "Pawn Forge"
ASSETS = Path(__file__).parent / "assets"
CAPTION_MAX = 1024
esc = html.escape

_FILE_IDS: dict[str, str] = {}  # banner -> file_id (после первой отправки Telegram хранит картинку у себя)


# ---------- мелкие «кирпичики» оформления ----------
def kb(*rows) -> InlineKeyboardMarkup:
    """Строки: [(текст, callback_data), (текст, 'url', https://...)]."""
    out = []
    for row in rows:
        btns = []
        for b in row:
            if len(b) == 3 and b[1] == "webapp":
                btns.append(InlineKeyboardButton(text=b[0], web_app=WebAppInfo(url=b[2])))
            elif len(b) == 3:
                btns.append(InlineKeyboardButton(text=b[0], url=b[2]))
            else:
                btns.append(InlineKeyboardButton(text=b[0], callback_data=b[1]))
        out.append(btns)
    return InlineKeyboardMarkup(inline_keyboard=out)


def card(title: str, *lines: str) -> str:
    """Заголовок + тело. Пустые строки — отступы."""
    body = "\n".join(lines)
    return f"<b>{title}</b>\n\n{body}" if body else f"<b>{title}</b>"


def panel(*lines: str) -> str:
    """Цитата-панель для «данных» (ключ — значение)."""
    return "<blockquote>" + "\n".join(lines) + "</blockquote>"


def bar(done: float, total: float = 1, width: int = 10) -> str:
    """▰▰▰▱▱▱▱▱▱▱  30%"""
    frac = 0.0 if total <= 0 else max(0.0, min(1.0, done / total))
    n = round(frac * width)
    return "▰" * n + "▱" * (width - n) + f"  {round(frac * 100)}%"


def kv(icon: str, label: str, value: str) -> str:
    return f"{icon} {label}: <b>{value}</b>"


def short(s: str, n: int) -> str:
    return s if len(s) <= n else s[: n - 1] + "…"


def rank(done: int) -> tuple[str, str]:
    """Ранг по числу успешных операций."""
    if done >= 30:
        return "👑", "Легенда"
    if done >= 12:
        return "🛠", "Мастер"
    if done >= 4:
        return "🔧", "Кодер"
    if done >= 1:
        return "🌱", "Ученик"
    return "🆕", "Новичок"


# ---------- показ экранов ----------
def _has(banner: str | None) -> bool:
    return bool(banner) and (ASSETS / f"{banner}.jpg").is_file()


def _media(banner: str):
    return _FILE_IDS.get(banner) or FSInputFile(ASSETS / f"{banner}.jpg")


def _remember(banner: str, msg) -> None:
    if isinstance(msg, Message) and msg.photo:
        _FILE_IDS[banner] = msg.photo[-1].file_id


def fits(text: str) -> bool:
    return len(text) <= CAPTION_MAX


async def send(target: Message, text: str, markup: InlineKeyboardMarkup | None = None, banner: str | None = None) -> Message:
    """Новое сообщение: фото-карточка, а если не получилось — обычный текст."""
    if _has(banner) and fits(text):
        for _ in range(2):
            try:
                m = await target.answer_photo(_media(banner), caption=text, reply_markup=markup)
                _remember(banner, m)
                return m
            except TelegramBadRequest as e:
                log.warning("photo send failed (%s): %s", banner, e)
                _FILE_IDS.pop(banner, None)  # возможно, протух file_id — второй заход отправит файл заново
    return await target.answer(text, reply_markup=markup)


async def edit(msg: Message, text: str, markup: InlineKeyboardMarkup | None = None, banner: str | None = None) -> Message:
    """Правит сообщение на месте. Возвращает актуальное сообщение (оно может смениться, если тип экрана другой)."""
    has_photo = bool(msg.photo)
    try:
        if has_photo:
            if not fits(text):
                return await _replace(msg, text, markup, None)
            if banner and _has(banner):
                try:
                    res = await msg.edit_media(InputMediaPhoto(media=_media(banner), caption=text), reply_markup=markup)
                except TelegramBadRequest as e:
                    if "not modified" in str(e):
                        return msg
                    _FILE_IDS.pop(banner, None)
                    res = await msg.edit_media(InputMediaPhoto(media=_media(banner), caption=text), reply_markup=markup)
                _remember(banner, res)
                return res if isinstance(res, Message) else msg
            res = await msg.edit_caption(caption=text, reply_markup=markup)
            return res if isinstance(res, Message) else msg
        # сообщение было обычным текстом
        if _has(banner) and fits(text):
            return await _replace(msg, text, markup, banner)
        res = await msg.edit_text(text, reply_markup=markup)
        return res if isinstance(res, Message) else msg
    except TelegramBadRequest as e:
        if "not modified" in str(e):
            return msg
        log.warning("edit failed: %s", e)
        return await _replace(msg, text, markup, banner)


async def _replace(msg: Message, text: str, markup, banner: str | None) -> Message:
    try:
        await msg.delete()
    except Exception:
        pass
    return await send(msg, text, markup, banner)


async def show(target: Union[Message, CallbackQuery], text: str, markup: InlineKeyboardMarkup | None = None, banner: str | None = None) -> Message:
    """Для callback — правит текущую карточку, для message — отправляет новую."""
    if isinstance(target, CallbackQuery):
        return await edit(target.message, text, markup, banner)
    return await send(target, text, markup, banner)


# ---------- кнопки ----------
BACK = [("◀️ В меню", "menu")]
CANCEL = [("✖️ Отмена", "cancel")]


def menu_kb(is_admin: bool, has_mod: bool) -> InlineKeyboardMarkup:
    rows = [
        [("📦 Загрузить мод", "mod:add"), ("🧩 Вшить систему", "sys:add")],
        [("⚡ Собрать мод", "mod:compile"), ("🚀 Залить на FTP", "ftp")],
    ]
    if has_mod:
        rows.append([("⬇️ Скачать архив мода", "mod:dl")])
    rows.append([("👤 Профиль", "profile"), ("🎁 Промокод", "promo")])
    rows.append([("👥 Друзья · +2", "ref"), ("❓ Как это работает", "help")])
    if is_admin:
        rows.append([("⚙️ Админ-панель", "adm")])
    return kb(*rows)


def stub_kb() -> InlineKeyboardMarkup:
    return kb([("🔑 Ввести промокод", "promo")], [("👥 Пригласить друзей", "ref")], [("❓ Как это работает", "help")])


# ---------- тексты главных экранов ----------
def menu_text(balance: int | None, mod_name: str | None, main_file: str | None, name: str | None = None) -> str:
    bal = "∞" if balance is None else str(balance)
    hello = f"Привет, {esc(short(name, 24))}! 👋" if name else "Привет! 👋"
    if mod_name:
        mod = [f"📦 Мод: <code>{esc(short(mod_name, 34))}</code>", f"📄 Main: <code>{esc(short(main_file or '', 34))}</code>"]
    else:
        mod = ["📦 Мод: <i>ещё не загружен</i>"]
    return card(
        f"♟ {BRAND}",
        hello,
        "",
        panel(f"💎 Запросов: <b>{bal}</b>", *mod),
        "",
        "<i>Выбирай действие 👇</i>",
    )


STUB_TEXT = card(
    "🔒 Доступ закрыт",
    "Запросы закончились — но это легко исправить:",
    "",
    panel("🎁 введи <b>промокод</b>", "👥 или позови друзей: за каждых 5 — <b>+2 запроса</b>"),
)

HELP_TEXT = card(
    "❓ Как это работает",
    panel(
        "<b>1 · Загрузи мод</b>",
        "Архив .zip с папкой <code>gamemodes</code> — как на сервере SA-MP / CRMP.",
        "",
        "<b>2 · Вшей систему</b>",
        "Пришли .pwn / .inc или вставь код — я сам подключу колбэки и инклуды.",
        "",
        "<b>3 · Забери результат</b>",
        "Компиляция + автоисправление ошибок. Готовый <code>.amx</code> и архив — тебе.",
        "",
        "<b>4 · Залей на сервер</b>",
        "«🚀 Залить на FTP»: хост, логин, пароль — соберу и сам загружу мод на твой сервер.",
    ),
    "",
    "💎 <b>1 запрос</b> списывается только за успешную сборку.",
    "↩️ Не получилось — всё откатывается, запрос цел.",
)


def admin_kb(is_owner: bool) -> InlineKeyboardMarkup:
    rows = [
        [("📊 Статистика", "adm:stats"), ("📣 Рассылка", "adm:bc")],
        [("🔒 Подписка (ОП)", "adm:op"), ("🎟 Промокоды", "adm:promo")],
        [("💰 Баланс", "adm:bal"), ("🗂 База модов", "adm:dump:0")],
    ]
    if is_owner:
        rows.append([("👮 Админы", "adm:admins")])
    rows.append(BACK)
    return kb(*rows)
