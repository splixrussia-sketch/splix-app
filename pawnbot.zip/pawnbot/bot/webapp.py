"""Mini App «Залить на FTP»: маленький aiohttp-сервер внутри процесса бота.

Авторизация — подпись Telegram initData (HMAC), поэтому подделать чужой id нельзя.
Права те же, что в боте: доступ (баланс/админ), обязательная подписка (ОП), один мод на пользователя.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import logging
import time
from pathlib import Path
from urllib.parse import parse_qsl

from aiohttp import web

from .config import Config
from .db import DB
from .deploy import DeployManager
from .ftpdeploy import FtpError

log = logging.getLogger("webapp")
INDEX = Path(__file__).parent / "webapp" / "index.html"
INIT_MAX_AGE = 24 * 3600


def verify_init_data(init_data: str, token: str, max_age: int = INIT_MAX_AGE, now: float | None = None) -> dict | None:
    """Проверка подписи Telegram WebApp initData. Возвращает dict пользователя или None."""
    if not init_data or len(init_data) > 4096:
        return None
    try:
        pairs = dict(parse_qsl(init_data, keep_blank_values=True, strict_parsing=True))
    except ValueError:
        return None
    got = pairs.pop("hash", "")
    if not got:
        return None
    check = "\n".join(f"{k}={v}" for k, v in sorted(pairs.items()))
    secret = hmac.new(b"WebAppData", token.encode(), hashlib.sha256).digest()
    want = hmac.new(secret, check.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(want, got):
        return None
    try:
        if (now or time.time()) - int(pairs.get("auth_date", "0")) > max_age:
            return None
        user = json.loads(pairs.get("user", "{}"))
    except (ValueError, TypeError):
        return None
    return user if isinstance(user, dict) and isinstance(user.get("id"), int) else None


def _err(msg: str, status: int = 400) -> web.Response:
    return web.json_response({"ok": False, "error": msg}, status=status)


@web.middleware
async def security_headers(request: web.Request, handler):
    resp = await handler(request)
    resp.headers["X-Content-Type-Options"] = "nosniff"
    resp.headers["Referrer-Policy"] = "no-referrer"
    resp.headers["Cache-Control"] = "no-store"
    if request.path == "/":
        resp.headers["Content-Security-Policy"] = (
            "default-src 'none'; script-src 'self' 'unsafe-inline' https://telegram.org; "
            "style-src 'unsafe-inline'; img-src data:; connect-src 'self'; base-uri 'none'; form-action 'none'"
        )
    return resp


def make_app(cfg: Config, db: DB, bot, deployer: DeployManager) -> web.Application:
    app = web.Application(middlewares=[security_headers], client_max_size=16 * 1024)

    async def auth(request: web.Request) -> dict | None:
        return verify_init_data(request.headers.get("X-Init-Data", ""), cfg.bot_token)

    async def missing_channels(uid: int) -> list[str]:
        out = []
        for ch in await db.list_channels():
            try:
                mem = await bot.get_chat_member(ch.chat_id, uid)
                if mem.status in ("left", "kicked"):
                    out.append(ch.title)
            except Exception:
                pass  # как и в боте: не блокируем людей из-за настроек канала
        return out

    async def index(_: web.Request) -> web.StreamResponse:
        return web.FileResponse(INDEX)

    async def health(_: web.Request) -> web.Response:
        return web.Response(text="ok")

    async def state(request: web.Request) -> web.Response:
        u = await auth(request)
        if not u:
            return _err("Откройте приложение из Telegram.", 401)
        uid = u["id"]
        admin = await db.is_admin(uid)
        usr = await db.get_user(uid)
        mod = await db.get_mod(uid)
        job = deployer.get(uid)
        return web.json_response(
            {
                "ok": True,
                "name": u.get("first_name", ""),
                "balance": None if admin else (usr.balance if usr else 0),
                "access": await db.has_access(uid),
                "mod": {"name": mod.name, "main": mod.main_file} if mod else None,
                "missing": await missing_channels(uid) if not admin else [],
                "job": job.snapshot(0) if job else None,
            }
        )

    async def start(request: web.Request) -> web.Response:
        u = await auth(request)
        if not u:
            return _err("Откройте приложение из Telegram.", 401)
        uid = u["id"]
        try:
            body = await request.json()
            host = str(body.get("host", ""))
            user = str(body.get("user", ""))
            password = str(body.get("password", ""))
            path = str(body.get("path", ""))
            amx_only = bool(body.get("amx_only", False))
            port = body.get("port")
            port = int(port) if str(port or "").strip() else None
        except (ValueError, TypeError):
            return _err("Некорректные данные формы.")
        if not await db.is_admin(uid):
            miss = await missing_channels(uid)
            if miss:
                return _err("Сначала подпишитесь на каналы в боте: " + ", ".join(miss), 403)
        try:
            job = await deployer.start(uid, host, port, user, password, path, amx_only)
        except FtpError as e:
            return _err(_plain(str(e)))
        return web.json_response({"ok": True, "job": job.snapshot(0)})

    async def status(request: web.Request) -> web.Response:
        u = await auth(request)
        if not u:
            return _err("Откройте приложение из Telegram.", 401)
        job = deployer.get(u["id"])
        if not job:
            return web.json_response({"ok": True, "job": None})
        try:
            since = int(request.query.get("since", "0"))
        except ValueError:
            since = 0
        return web.json_response({"ok": True, "job": job.snapshot(since)})

    async def stop(request: web.Request) -> web.Response:
        u = await auth(request)
        if not u:
            return _err("Откройте приложение из Telegram.", 401)
        job = deployer.get(u["id"])
        if job and job.running:
            job.cancel.set()
        return web.json_response({"ok": True})

    app.router.add_get("/", index)
    app.router.add_get("/health", health)
    app.router.add_get("/api/state", state)
    app.router.add_post("/api/deploy", start)
    app.router.add_get("/api/status", status)
    app.router.add_post("/api/stop", stop)
    return app


def _plain(text: str) -> str:
    """Тексты ошибок для бота содержат HTML-теги — для Mini App оставляем чистый текст."""
    import re

    return re.sub(r"<[^>]+>", "", text)


async def start_webapp(cfg: Config, db: DB, bot, deployer: DeployManager) -> web.AppRunner:
    runner = web.AppRunner(make_app(cfg, db, bot, deployer), access_log=None)
    await runner.setup()
    site = web.TCPSite(runner, "0.0.0.0", cfg.webapp_port)
    await site.start()
    log.info("Mini App слушает порт %s (%s)", cfg.webapp_port, cfg.webapp_url or "WEBAPP_URL не задан")
    return runner
