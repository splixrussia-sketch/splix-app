"""Mini App «Pawn Forge»: aiohttp-сервер внутри процесса бота — все функции бота в одном приложении.

Авторизация — подпись Telegram initData (HMAC), поэтому подделать чужой id нельзя.
Права те же, что в боте: доступ (баланс/админ), обязательная подписка (ОП), один активный процесс на пользователя,
админ-разделы — только для админов, управление админами — только для владельца.
"""
from __future__ import annotations

import asyncio
import hashlib
import hmac
import html
import json
import logging
import re
import secrets
import shutil
import time
from pathlib import Path
from urllib.parse import parse_qsl, unquote

from aiohttp import web

from .config import Config
from .db import DB, Mod
from .deploy import DeployManager
from .ftpdeploy import FtpError
from .modtools import ModError, find_main, find_root, make_zip, safe_extract, sensitive_files

log = logging.getLogger("webapp")
INDEX = Path(__file__).parent / "webapp" / "index.html"
INIT_MAX_AGE = 24 * 3600
TG_SEND_LIMIT = 49 * 1024 * 1024
SYSTEM_MAX = 3 * 1024 * 1024
PAGE = 8


def verify_init_data(init_data: str, token: str, max_age: int = INIT_MAX_AGE, now: float | None = None) -> dict | None:
    """Проверка подписи Telegram WebApp initData. Возвращает dict пользователя или None."""
    if not init_data or len(init_data) > 4096:
        return None
    try:
        pairs = dict(parse_qsl(init_data, keep_blank_values=True, strict_parsing=True))
    except ValueError:
        return None
    got = pairs.pop("hash", "")
    if not got:
        return None
    check = "\n".join(f"{k}={v}" for k, v in sorted(pairs.items()))
    secret = hmac.new(b"WebAppData", token.encode(), hashlib.sha256).digest()
    want = hmac.new(secret, check.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(want, got):
        return None
    try:
        if (now or time.time()) - int(pairs.get("auth_date", "0")) > max_age:
            return None
        user = json.loads(pairs.get("user", "{}"))
    except (ValueError, TypeError):
        return None
    return user if isinstance(user, dict) and isinstance(user.get("id"), int) else None


def _err(msg: str, status: int = 400) -> web.Response:
    return web.json_response({"ok": False, "error": msg}, status=status)


def _plain(text: str) -> str:
    """Тексты ошибок для бота содержат HTML-теги — для Mini App оставляем чистый текст."""
    return html.unescape(re.sub(r"<[^>]+>", "", text))


def _rank(done: int) -> tuple[int, str]:
    if done >= 30:
        return 4, "Легенда"
    if done >= 12:
        return 3, "Мастер"
    if done >= 4:
        return 2, "Кодер"
    if done >= 1:
        return 1, "Ученик"
    return 0, "Новичок"


@web.middleware
async def security_headers(request: web.Request, handler):
    resp = await handler(request)
    resp.headers["X-Content-Type-Options"] = "nosniff"
    resp.headers["Referrer-Policy"] = "no-referrer"
    resp.headers["Cache-Control"] = "no-store"
    if request.path == "/":
        resp.headers["Content-Security-Policy"] = (
            "default-src 'none'; script-src 'self' 'unsafe-inline' https://telegram.org; "
            "style-src 'unsafe-inline'; img-src data: https://t.me; connect-src 'self'; base-uri 'none'; form-action 'none'"
        )
    return resp


class Denied(Exception):
    def __init__(self, msg: str, status: int = 400):
        self.msg, self.status = msg, status


def make_app(cfg: Config, db: DB, bot, deployer: DeployManager) -> web.Application:
    app = web.Application(middlewares=[security_headers], client_max_size=SYSTEM_MAX + 64 * 1024)
    tasks: set[asyncio.Task] = set()
    bc_state: dict = {"running": False, "done": 0, "total": 0, "ok": 0, "fail": 0, "finished": False}
    bot_name: list[str] = []

    # ---------- общие помощники ----------
    async def username() -> str:
        if not bot_name:
            bot_name.append((await bot.me()).username or "")
        return bot_name[0]

    async def missing_channels(uid: int) -> list[str]:
        out = []
        for ch in await db.list_channels():
            try:
                mem = await bot.get_chat_member(ch.chat_id, uid)
                if mem.status in ("left", "kicked"):
                    out.append(ch.title)
            except Exception:
                pass  # как и в боте: не блокируем людей из-за настроек канала
        return out

    async def who(request: web.Request, *, sub: bool = True, admin: bool = False, owner: bool = False) -> tuple[int, bool]:
        """Проверяет подпись, регистрирует пользователя, ОП и права. Возвращает (uid, is_admin)."""
        u = verify_init_data(request.headers.get("X-Init-Data", ""), cfg.bot_token)
        if not u:
            raise Denied("Откройте приложение из Telegram.", 401)
        uid = u["id"]
        await db.upsert_user(uid, u.get("username"), u.get("first_name"))
        is_admin = await db.is_admin(uid)
        if owner and uid != cfg.owner_id:
            raise Denied("Только для владельца.", 403)
        if admin and not is_admin:
            raise Denied("Только для администраторов.", 403)
        if sub and not is_admin:
            miss = await missing_channels(uid)
            if miss:
                raise Denied("Сначала подпишитесь на каналы в боте: " + ", ".join(miss), 403)
        return uid, is_admin

    async def need_access(uid: int) -> None:
        if not await db.has_access(uid):
            raise Denied("Нет доступа: активируйте промокод или пригласите друзей.", 403)

    def spawn(coro) -> None:
        t = asyncio.create_task(coro)
        tasks.add(t)
        t.add_done_callback(tasks.discard)

    async def body_json(request: web.Request) -> dict:
        try:
            data = await request.json()
        except (ValueError, TypeError):
            raise Denied("Некорректные данные.")
        if not isinstance(data, dict):
            raise Denied("Некорректные данные.")
        return data

    async def read_raw(request: web.Request, limit: int) -> bytes:
        if (request.content_length or 0) > limit:
            raise Denied("Файл слишком большой.", 413)
        buf = bytearray()
        async for chunk in request.content.iter_chunked(1 << 16):
            buf += chunk
            if len(buf) > limit:
                raise Denied("Файл слишком большой.", 413)
        return bytes(buf)

    def filename(request: web.Request, default: str) -> str:
        name = unquote(request.headers.get("X-Filename", "")).replace("\\", "/").split("/")[-1].strip()
        return name[:120] or default

    def handler(fn):
        async def wrapped(request: web.Request) -> web.StreamResponse:
            try:
                return await fn(request)
            except Denied as e:
                return _err(e.msg, e.status)
            except (FtpError, ModError) as e:
                return _err(_plain(str(e)))
            except web.HTTPException:
                raise
            except Exception:
                log.exception("api error: %s", request.path)
                return _err("Внутренняя ошибка. Попробуйте ещё раз.", 500)

        return wrapped

    def ok(**kw) -> web.Response:
        return web.json_response({"ok": True, **kw})

    # ---------- страницы ----------
    async def index(_: web.Request) -> web.StreamResponse:
        return web.FileResponse(INDEX)

    async def health(_: web.Request) -> web.Response:
        return web.Response(text="ok")

    # ---------- состояние ----------
    @handler
    async def state(request: web.Request):
        uid, admin = await who(request, sub=False)
        u = await db.get_user(uid)
        mod = await db.get_mod(uid)
        job = deployer.get(uid)
        st = await db.user_stats(uid)
        acts = st["acts"]
        built = acts.get("compile", (0, 0))[0] + acts.get("add_system", (0, 0))[0]
        tier, title = _rank(built)
        missing = await missing_channels(uid) if not admin else []
        if not missing:  # засчитываем приглашение, как это делает бот после ОП
            rf = await db.credit_referral(uid)
            if rf and rf[2]:
                try:
                    await bot.send_message(rf[0], f"🎉 <b>Бонус за друзей</b>\n\nПриглашено: <b>{rf[1]}</b>\nВам начислено <b>+2 запроса</b> 🎁")
                except Exception:
                    pass
            u = await db.get_user(uid)
        name = (u.first_name if u else "") or ""
        uname = await username()
        return ok(
            id=uid,
            name=name,
            admin=admin,
            owner=uid == cfg.owner_id,
            balance=None if admin else (u.balance if u else 0),
            access=await db.has_access(uid),
            mod={
                "name": mod.name,
                "main": mod.main_file,
                "size": mod.size,
                "uploaded": mod.uploaded_at,
            } if mod else None,
            missing=missing,
            channels=[{"title": c.title, "link": c.link} for c in await db.list_channels()] if missing else [],
            job=job.snapshot(0) if job else None,
            has_amx=bool(job and job.artifact and Path(job.artifact).is_file()),
            profile={
                "rank": title,
                "tier": tier,
                "built": built,
                "systems": acts.get("add_system", (0, 0))[0],
                "mods": acts.get("add_mod", (0, 0))[0],
                "deploys": acts.get("deploy", (0, 0))[0],
                "joined": st["joined"],
                "refs": u.ref_count if u else 0,
                "next": (u.ref_count if u else 0) % 5,
            },
            ref_link=f"https://t.me/{uname}?start=ref_{uid}" if uname else "",
            limits={"zip_mb": cfg.max_zip_mb, "system_mb": SYSTEM_MAX // (1 << 20)},
        )

    # ---------- мод ----------
    @handler
    async def upload_mod(request: web.Request):
        uid, _admin = await who(request)
        await need_access(uid)
        name = filename(request, "mod.zip")
        if not name.lower().endswith(".zip"):
            raise Denied("Нужен файл в формате .zip")
        limit = cfg.max_zip_mb * 1024 * 1024
        if (request.content_length or 0) > limit:
            raise Denied(f"Архив больше {cfg.max_zip_mb} МБ.", 413)
        if uid in deployer.busy or (deployer.get(uid) and deployer.get(uid).running):
            raise Denied("Подождите, предыдущая операция ещё выполняется.")
        deployer.busy.add(uid)
        base = cfg.data_dir / "mods" / str(uid)
        new = base / "new"
        try:
            shutil.rmtree(new, ignore_errors=True)
            new.mkdir(parents=True)
            zip_path = new / "original.zip"
            size = 0
            with open(zip_path, "wb") as f:
                async for chunk in request.content.iter_chunked(1 << 16):
                    size += len(chunk)
                    if size > limit:
                        raise Denied(f"Архив больше {cfg.max_zip_mb} МБ.", 413)
                    f.write(chunk)
            if size == 0:
                raise Denied("Пустой файл.")
            src = new / "src"
            await asyncio.to_thread(safe_extract, zip_path, src, cfg.max_unpacked_mb << 20, cfg.max_files)
            root = find_root(src)
            main = find_main(root)
            sens = sensitive_files(root)
            n_pwn = sum(1 for _ in root.rglob("*.pwn"))
            main_kb = (root / main).stat().st_size // 1024
            cur = base / "current"
            shutil.rmtree(cur, ignore_errors=True)
            new.rename(cur)
            final_root = cur / "src" / root.relative_to(src)
            await db.save_mod(Mod(uid, name, str(final_root), str(cur / "original.zip"), main, size, ""))
            await db.log(uid, "add_mod", True)
            return ok(mod={"name": name, "main": main, "size": size}, pwn=n_pwn, main_kb=main_kb, sensitive=sens[:4])
        except (ModError, Denied):
            shutil.rmtree(new, ignore_errors=True)
            await db.log(uid, "add_mod", False)
            raise
        except Exception:
            shutil.rmtree(new, ignore_errors=True)
            await db.log(uid, "add_mod", False)
            raise
        finally:
            deployer.busy.discard(uid)

    @handler
    async def add_system(request: web.Request):
        uid, _admin = await who(request)
        await need_access(uid)
        name = filename(request, "system.pwn")
        low = name.lower()
        if not low.endswith((".pwn", ".inc", ".txt")):
            raise Denied("Принимаю файлы .pwn, .inc или текст кода.")
        if low.endswith(".txt"):
            name = name[:-4] + ".pwn"
        raw = await read_raw(request, SYSTEM_MAX)
        if not raw.strip():
            raise Denied("Файл пустой.")
        job = await deployer.start_build(uid, "system", name, raw)
        return ok(job=job.snapshot(0))

    @handler
    async def compile_mod(request: web.Request):
        uid, _admin = await who(request)
        await need_access(uid)
        job = await deployer.start_build(uid, "compile")
        return ok(job=job.snapshot(0))

    @handler
    async def send_files(request: web.Request):
        """Присылает готовый .amx или архив мода в чат с ботом (скачивание из Mini App в Telegram ненадёжно)."""
        uid, _admin = await who(request)
        body = await body_json(request)
        what = str(body.get("what", ""))
        from aiogram.types import FSInputFile

        if what == "amx":
            job = deployer.get(uid)
            p = Path(job.artifact) if job and job.artifact else None
            if not p or not p.is_file():
                raise Denied("Сначала соберите мод.")
            if p.stat().st_size > TG_SEND_LIMIT:
                raise Denied("Файл .amx больше 50 МБ — скачайте архив мода.")
            await bot.send_document(uid, FSInputFile(p, filename=p.name), caption="🎮 <b>Готовый .amx</b>")
        elif what == "zip":
            mod = await db.get_mod(uid)
            if not mod:
                raise Denied("Сначала добавьте мод.")
            out = cfg.data_dir / "tmp" / f"{uid}.zip"
            out.parent.mkdir(parents=True, exist_ok=True)
            try:
                await asyncio.to_thread(make_zip, Path(mod.root), out)
                if out.stat().st_size > TG_SEND_LIMIT:
                    raise Denied("Архив больше 50 МБ — Telegram не даёт отправить его ботом.")
                await bot.send_document(uid, FSInputFile(out, filename=f"{Path(mod.name).stem}_build.zip"), caption="📦 <b>Текущая версия мода</b>")
            finally:
                out.unlink(missing_ok=True)
        else:
            raise Denied("Неизвестное действие.")
        return ok()

    # ---------- FTP ----------
    @handler
    async def start_ftp(request: web.Request):
        uid, _admin = await who(request)
        body = await body_json(request)
        try:
            port = body.get("port")
            port = int(port) if str(port or "").strip() else None
            args = (str(body.get("host", "")), port, str(body.get("user", "")), str(body.get("password", "")), str(body.get("path", "")), bool(body.get("amx_only", False)))
        except (ValueError, TypeError):
            raise Denied("Некорректные данные формы.")
        job = await deployer.start(uid, *args)
        return ok(job=job.snapshot(0))

    @handler
    async def status(request: web.Request):
        uid, _admin = await who(request, sub=False)
        job = deployer.get(uid)
        if not job:
            return ok(job=None)
        try:
            since = int(request.query.get("since", "0"))
        except ValueError:
            since = 0
        return ok(job=job.snapshot(since), has_amx=bool(job.artifact and Path(job.artifact).is_file()))

    @handler
    async def stop(request: web.Request):
        uid, _admin = await who(request, sub=False)
        job = deployer.get(uid)
        if job and job.running:
            job.cancel.set()
        return ok()

    # ---------- промокод ----------
    @handler
    async def promo(request: web.Request):
        uid, _admin = await who(request)
        code = str((await body_json(request)).get("code", "")).strip()
        if not code or len(code) > 40:
            raise Denied("Введите промокод.")
        status_, n = await db.activate_promo(code, uid)
        msgs = {
            "none": "Промокод не найден. Проверьте написание.",
            "used": "Вы уже активировали этот промокод.",
            "exhausted": "Лимит активаций промокода исчерпан.",
        }
        if status_ != "ok":
            raise Denied(msgs[status_])
        u = await db.get_user(uid)
        return ok(added=n, balance=u.balance if u else n)

    # ---------- админка ----------
    @handler
    async def adm_stats(request: web.Request):
        await who(request, admin=True)
        s = await db.stats()
        return ok(
            users=s["users"], day=s["day"], live=s["live"], mods=s["mods"], channels=s["channels"],
            acts=[{"action": a, "ok": int(o or 0), "total": int(t)} for a, o, t in s["acts"]],
            promos=[{"code": c, "requests": r, "max": m, "used": u} for c, r, m, u in await db.list_promos()],
        )

    @handler
    async def adm_channels(request: web.Request):
        await who(request, admin=True)
        return ok(channels=[{"id": c.chat_id, "title": c.title, "link": c.link} for c in await db.list_channels()])

    @handler
    async def adm_channel_add(request: web.Request):
        await who(request, admin=True)
        key = str((await body_json(request)).get("key", "")).strip()
        mt = re.match(r"^(?:https?://)?t\.me/([A-Za-z0-9_]+)/?$", key)
        if mt:
            key = "@" + mt[1]
        elif re.fullmatch(r"-?\d+", key):
            key = int(key)
        elif not key:
            raise Denied("Укажите @username, ссылку или ID канала.")
        try:
            chat = await bot.get_chat(key)
            me = await bot.me()
            mem = await bot.get_chat_member(chat.id, me.id)
            if mem.status not in ("administrator", "creator"):
                raise ValueError("Бот не администратор канала.")
            link = f"https://t.me/{chat.username}" if chat.username else (await bot.create_chat_invite_link(chat.id)).invite_link
        except Exception as e:
            raise Denied(f"Не получилось: {str(e)[:160]}. Проверьте, что бот добавлен админом.")
        await db.add_channel(chat.id, chat.title or str(chat.id), link)
        return ok()

    @handler
    async def adm_channel_del(request: web.Request):
        await who(request, admin=True)
        try:
            await db.del_channel(int((await body_json(request)).get("id")))
        except (TypeError, ValueError):
            raise Denied("Некорректный канал.")
        return ok()

    @handler
    async def adm_promo_new(request: web.Request):
        await who(request, admin=True)
        b = await body_json(request)
        try:
            uses, reqs = int(b.get("uses")), int(b.get("requests"))
        except (TypeError, ValueError):
            raise Denied("Числа должны быть больше нуля.")
        if uses < 1 or reqs < 1 or uses > 1_000_000 or reqs > 100_000:
            raise Denied("Числа должны быть больше нуля.")
        code = str(b.get("code") or "").strip().upper() or secrets.token_hex(4).upper()
        if not re.fullmatch(r"[A-Z0-9_-]{3,32}", code):
            raise Denied("Код: 3–32 символа, латиница/цифры/-/_.")
        if not await db.create_promo(code, reqs, uses):
            raise Denied("Такой код уже существует.")
        return ok(code=code)

    @handler
    async def adm_balance(request: web.Request):
        await who(request, admin=True)
        b = await body_json(request)
        try:
            n = int(b.get("amount"))
        except (TypeError, ValueError):
            raise Denied("Количество должно быть числом.")
        if n == 0 or abs(n) > 1_000_000:
            raise Denied("Некорректное количество.")
        if b.get("all"):
            if n < 1:
                raise Denied("Для всех — положительное число.")
            return ok(users=await db.add_balance_all(n))
        target = str(b.get("target", "")).strip()
        u = await db.find_user(target) if target else None
        if not u:
            raise Denied("Пользователь не найден (он должен хотя бы раз запустить бота).")
        await db.add_balance(u.id, n)
        if n > 0:
            try:
                await bot.send_message(u.id, f"🎁 <b>Начисление</b>\n\nВам начислено <b>+{n}</b> запросов.")
            except Exception:
                pass
        return ok(name=u.first_name or str(u.id), id=u.id)

    # рассылка
    async def broadcast_job(text: str, buttons: list[list[str]]) -> None:
        from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError, TelegramRetryAfter
        from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

        markup = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text=t, url=u)] for t, u in buttons]) if buttons else None
        ids = await db.all_user_ids()
        bc_state.update(running=True, finished=False, done=0, total=len(ids), ok=0, fail=0)
        for uid in ids:
            sent = False
            for _ in range(3):
                try:
                    await bot.send_message(uid, text, reply_markup=markup)
                    sent = True
                    break
                except TelegramRetryAfter as e:
                    await asyncio.sleep(e.retry_after + 1)
                except (TelegramForbiddenError, TelegramBadRequest):
                    break
                except Exception:
                    break
            bc_state["ok" if sent else "fail"] += 1
            bc_state["done"] += 1
            await asyncio.sleep(0.05)
        bc_state.update(running=False, finished=True)

    @handler
    async def adm_broadcast(request: web.Request):
        uid, _ = await who(request, admin=True)
        b = await body_json(request)
        text = str(b.get("text", "")).strip()
        if not text or len(text) > 3800:
            raise Denied("Введите текст рассылки (до 3800 символов).")
        buttons = []
        for line in str(b.get("buttons", "")).splitlines():
            if "|" in line:
                t, u = (x.strip() for x in line.split("|", 1))
                if t and re.match(r"^(https?://|tg://)", u):
                    buttons.append([t[:60], u])
        safe = html.escape(text)
        if b.get("test"):
            from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

            markup = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text=t, url=u)] for t, u in buttons]) if buttons else None
            await bot.send_message(uid, safe, reply_markup=markup)
            return ok(test=True)
        if bc_state["running"]:
            raise Denied("Рассылка уже идёт.")
        bc_state.update(running=True, finished=False, done=0, total=len(await db.all_user_ids()), ok=0, fail=0)
        spawn(broadcast_job(safe, buttons))
        return ok(total=bc_state["total"])

    @handler
    async def adm_broadcast_status(request: web.Request):
        await who(request, admin=True)
        return ok(**bc_state)

    @handler
    async def adm_mods(request: web.Request):
        await who(request, admin=True)
        try:
            page = max(0, int(request.query.get("page", "0")))
        except ValueError:
            page = 0
        total = await db.count_mods()
        mods = await db.list_mods(page * PAGE, PAGE)
        return ok(total=total, page=page, per=PAGE, mods=[{"user_id": m.user_id, "name": m.name, "size": m.size, "at": m.uploaded_at} for m in mods])

    async def send_mod(to: int, mod) -> None:
        from aiogram.types import FSInputFile

        p = Path(mod.zip_path)
        if not p.is_file():
            await bot.send_message(to, f"Файл мода {mod.user_id} не найден на диске.")
        elif p.stat().st_size > TG_SEND_LIMIT:
            await bot.send_message(to, f"Мод {mod.user_id} больше 50 МБ, лежит на сервере: <code>{html.escape(str(p))}</code>")
        else:
            await bot.send_document(to, FSInputFile(p, filename=f"{mod.user_id}_{mod.name}"), caption=f"👤 <code>{mod.user_id}</code> · {html.escape(mod.name)}")

    @handler
    async def adm_mod_send(request: web.Request):
        uid, _ = await who(request, admin=True)
        b = await body_json(request)
        if b.get("all"):
            async def job():
                offset = 0
                while mods := await db.list_mods(offset, 20):
                    for m in mods:
                        try:
                            await send_mod(uid, m)
                        except Exception:
                            pass
                        await asyncio.sleep(0.7)
                    offset += 20
                await bot.send_message(uid, "✅ Все моды отправлены.")

            spawn(job())
            return ok(all=True)
        try:
            mod = await db.get_mod(int(b.get("user_id")))
        except (TypeError, ValueError):
            raise Denied("Некорректный мод.")
        if not mod:
            raise Denied("Мод не найден.")
        await send_mod(uid, mod)
        return ok()

    @handler
    async def adm_admins(request: web.Request):
        await who(request, admin=True, owner=True)
        return ok(owner=cfg.owner_id, admins=await db.list_admins())

    @handler
    async def adm_admin_toggle(request: web.Request):
        await who(request, admin=True, owner=True)
        try:
            target = int((await body_json(request)).get("id"))
        except (TypeError, ValueError):
            raise Denied("Нужен числовой ID.")
        if target == cfg.owner_id:
            raise Denied("Владельца менять нельзя.")
        added = await db.toggle_admin(target)
        return ok(added=added, admins=await db.list_admins())

    r = app.router
    r.add_get("/", index)
    r.add_get("/health", health)
    r.add_get("/api/state", state)
    r.add_post("/api/mod", upload_mod)
    r.add_post("/api/system", add_system)
    r.add_post("/api/compile", compile_mod)
    r.add_post("/api/send", send_files)
    r.add_post("/api/deploy", start_ftp)
    r.add_get("/api/status", status)
    r.add_post("/api/stop", stop)
    r.add_post("/api/promo", promo)
    r.add_get("/api/admin/stats", adm_stats)
    r.add_get("/api/admin/channels", adm_channels)
    r.add_post("/api/admin/channels/add", adm_channel_add)
    r.add_post("/api/admin/channels/del", adm_channel_del)
    r.add_post("/api/admin/promo", adm_promo_new)
    r.add_post("/api/admin/balance", adm_balance)
    r.add_post("/api/admin/broadcast", adm_broadcast)
    r.add_get("/api/admin/broadcast", adm_broadcast_status)
    r.add_get("/api/admin/mods", adm_mods)
    r.add_post("/api/admin/mods/send", adm_mod_send)
    r.add_get("/api/admin/admins", adm_admins)
    r.add_post("/api/admin/admins/toggle", adm_admin_toggle)
    return app


async def start_webapp(cfg: Config, db: DB, bot, deployer: DeployManager) -> web.AppRunner:
    runner = web.AppRunner(make_app(cfg, db, bot, deployer), access_log=None)
    await runner.setup()
    site = web.TCPSite(runner, "0.0.0.0", cfg.webapp_port)
    await site.start()
    log.info("Mini App слушает порт %s (%s)", cfg.webapp_port, cfg.webapp_url or "WEBAPP_URL не задан")
    return runner
