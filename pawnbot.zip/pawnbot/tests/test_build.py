"""Тесты сборки/вшивания для Mini App: python -m tests.test_build (без aiogram/aiohttp — они подменяются заглушками)."""
from __future__ import annotations

import asyncio
import tempfile
from pathlib import Path
from types import SimpleNamespace

from tests.test_ftp import _stub_missing  # noqa: F401  (подменяет отсутствующие зависимости)

from bot import deploy  # noqa: E402
from bot.compiler import CompileResult  # noqa: E402
from bot.fixer import FixReport  # noqa: E402

GM = "#include <a_samp>\nmain(){}\npublic OnGameModeInit(){ return 1; }\npublic OnPlayerConnect(playerid){ return 1; }\n"
SYS = "public OnPlayerConnect(playerid){ return 1; }\nstock Hello(){ return 1; }\n"


class FakeDB:
    def __init__(self, root: Path, balance: int = 1, admin: bool = False):
        self.root, self.balance, self.admin, self.events = root, balance, admin, []

    async def is_admin(self, uid): return self.admin
    async def has_access(self, uid): return self.admin or self.balance > 0
    async def get_mod(self, uid): return SimpleNamespace(root=str(self.root), main_file="gamemodes/main.pwn")
    async def spend(self, uid): self.balance -= 1; return True
    async def log(self, uid, action, ok): self.events.append((action, ok))


def _mk(ok: bool):
    tmp = Path(tempfile.mkdtemp())
    (tmp / "gamemodes").mkdir()
    (tmp / "gamemodes" / "main.pwn").write_text(GM)
    (tmp / "gamemodes" / "main.amx").write_bytes(b"AMX")

    async def fake_autofix(cfg, ai, ws, main, progress, own, prefix):
        await progress("Компиляция (попытка 1)…")
        res = CompileResult(ok=ok, amx_rel="gamemodes/main.amx", seconds=1.5, diags=[]) if ok else None
        return FixReport(ok=ok, rounds=1, result=res, reason="" if ok else "ошибка\nподробности")

    deploy.autofix = fake_autofix
    return tmp


async def _run(kind, ok, balance=1, admin=False):
    tmp = _mk(ok)
    db = FakeDB(tmp, balance, admin)
    m = deploy.DeployManager(SimpleNamespace(max_files=100, max_unpacked_mb=10), db, None, set())
    job = await m.start_build(7, kind, "houses.pwn", SYS.encode())
    for _ in range(200):
        if not job.running:
            break
        await asyncio.sleep(0.02)
    return job, db, tmp, m


def test_compile_ok_spends():
    job, db, _tmp, m = asyncio.run(_run("compile", True))
    assert job.state == "ok" and job.kind == "compile" and job.result["rounds"] == 1
    assert db.balance == 0 and db.events == [("compile", True)]
    assert job.artifact.endswith("main.amx") and 7 not in m.busy


def test_compile_fail_keeps_balance_and_rolls_back():
    job, db, tmp, _m = asyncio.run(_run("compile", False))
    assert job.state == "failed" and "не собрался" in job.error
    assert db.balance == 1 and db.events == [("compile", False)]
    assert (tmp / "gamemodes" / "main.pwn").read_text() == GM


def test_system_ok_admin_free():
    job, db, tmp, _m = asyncio.run(_run("system", True, balance=0, admin=True))
    assert job.state == "ok" and job.result["system"], job.error
    assert db.balance == 0 and db.events == [("add_system", True)]
    assert (tmp / "gamemodes" / "main.pwn").read_text() != GM  # система реально вшита


def test_system_fail_rolls_back():
    job, db, tmp, _m = asyncio.run(_run("system", False))
    assert job.state == "failed" and db.balance == 1 and db.events == [("add_system", False)]
    assert (tmp / "gamemodes" / "main.pwn").read_text() == GM
    assert not list((tmp / "gamemodes").glob("systems/*"))


def test_no_access_and_busy():
    async def go():
        tmp = _mk(True)
        m = deploy.DeployManager(SimpleNamespace(max_files=1, max_unpacked_mb=1), FakeDB(tmp, 0), None, set())
        try:
            await m.start_build(7, "compile")
        except deploy.FtpError as e:
            return str(e)

    assert "Нет доступа" in asyncio.run(go())


if __name__ == "__main__":
    n = 0
    for k, v in list(globals().items()):
        if k.startswith("test_"):
            v()
            print("ok", k)
            n += 1
    print(n, "тестов пройдено")
