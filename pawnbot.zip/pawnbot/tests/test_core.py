"""Запуск: python -m tests.test_core  (или pytest). Используется синтетический мод — реальные моды в репозиторий не кладём."""
import tempfile
import zipfile
from pathlib import Path

from bot.compiler import parse_output
from bot.injector import find_callbacks, integrate, param_names, uses_als
from bot.modtools import ModError, Workspace, find_main, find_root, safe_extract

MAIN = """#include <a_samp>
#include "hs.inc"

new gCounter;

public OnGameModeInit()
{
    return 1;
}

public OnPlayerConnect(playerid)
{
    return 1;
}

public OnDialogResponse(playerid, dialogid, response, listitem, inputtext[])
{
    return 0;
}

#if defined _ALS_OnPlayerConnect
    #undef OnPlayerConnect
#else
    #define _ALS_OnPlayerConnect
#endif
#define OnPlayerConnect alt_OnPlayerConnect
public OnPlayerConnect(playerid)
{
    return 1;
}
""".replace("\n", "\r\n")

SYSTEM = """forward OnPlayerConnect(playerid);
public OnPlayerConnect(playerid)
{
    SendClientMessage(playerid, -1, "hi");
    return 1;
}
public OnDialogResponse(playerid, dialogid, response, listitem, inputtext[])
{
    if (dialogid == 9) return 1;
    return 0;
}
public OnPlayerKeyStateChange(playerid, newkeys, oldkeys) { return 1; }
CMD:hello(playerid, params[]) { return 1; }
"""


def make_mod(tmp: Path) -> Path:
    root = tmp / "mod"
    (root / "gamemodes").mkdir(parents=True)
    (root / "pawno" / "include").mkdir(parents=True)
    (root / "gamemodes" / "main.pwn").write_bytes(MAIN.encode("cp1251"))
    (root / "gamemodes" / "hs.inc").write_text("// h\n")
    (root / "server.cfg").write_text("gamemode0 main 1\n")
    return root


def test_param_names():
    assert param_names("playerid, dialogid, response, listitem, inputtext[]") == ["playerid", "dialogid", "response", "listitem", "inputtext"]
    assert param_names("playerid, STREAMER_TAG_AREA:areaid") == ["playerid", "areaid"]
    assert param_names("playerid, Float:x, const name[]") == ["playerid", "x", "name"]
    assert param_names("a, ...") is None


def test_callbacks_and_als():
    assert set(find_callbacks(SYSTEM)) == {"OnPlayerConnect", "OnDialogResponse", "OnPlayerKeyStateChange"}
    assert not uses_als(SYSTEM)
    assert uses_als("#define OnPlayerConnect foo_OnPlayerConnect\n")


def test_integrate_and_rollback():
    with tempfile.TemporaryDirectory() as t:
        root = make_mod(Path(t))
        assert find_main(root) == "gamemodes/main.pwn"
        ws = Workspace(root)
        before = (root / "gamemodes/main.pwn").read_bytes()
        info = integrate(ws, "gamemodes/main.pwn", "my_system.pwn", SYSTEM.encode())
        assert info.prefix == "s1_" and info.mode == "hooks"
        assert set(info.injected) == {"OnPlayerConnect", "OnDialogResponse", "OnPlayerKeyStateChange"}
        text = (root / "gamemodes/main.pwn").read_bytes().decode("cp1251")
        assert "\r\n" in text and "\n" not in text.replace("\r\n", "")  # CRLF сохранён
        # вызов попал в «голову» цепочки (до #define OnPlayerConnect), а не в переименованное продолжение
        head = text.index("public OnPlayerConnect(playerid)")
        assert "s1_OnPlayerConnect(playerid);" in text[head : head + 120]
        assert text.count("\ts1_OnPlayerConnect(playerid);") == 1
        assert "if (s1_OnDialogResponse(playerid, dialogid, response, listitem, inputtext)) return 1;" in text
        assert '#include "systems/my_system.pwn"' in text
        # в моде не было OnPlayerKeyStateChange — создан новый колбэк в конце файла
        assert text.index("public OnPlayerKeyStateChange") > text.index("systems/my_system.pwn")
        sysfile = (root / info.rel).read_text()
        assert "public s1_OnPlayerConnect(playerid)" in sysfile and "forward OnPlayerConnect" not in sysfile
        assert "CMD:hello" in sysfile
        ws.rollback()
        assert (root / "gamemodes/main.pwn").read_bytes() == before
        assert not (root / info.rel).exists()
        assert not (root / ".bot_systems.json").exists()


def test_inc_goes_to_header():
    with tempfile.TemporaryDirectory() as t:
        root = make_mod(Path(t))
        ws = Workspace(root)
        info = integrate(ws, "gamemodes/main.pwn", "lib.inc", b"stock Foo() { return 1; }\n")
        assert info.rel == "include/lib.inc"
        text = (root / "gamemodes/main.pwn").read_bytes().decode("cp1251")
        assert text.index('#include "../include/lib.inc"') < text.index("public OnGameModeInit")


def test_parse_output():
    raw = (
        "gamemodes/a.pwn(12) : error 021: symbol already defined: \"gFoo\"\n"
        "gamemodes/a.pwn(30 -- 32) : warning 213: tag mismatch\n"
        "gamemodes/b.pwn(5) : fatal error 100: cannot read from file: \"x.inc\"\n"
        "Pawn compiler 3.10.10\n"
    )
    d = parse_output(raw)
    assert [(x.file, x.line, x.kind, x.code) for x in d] == [
        ("gamemodes/a.pwn", 12, "error", 21),
        ("gamemodes/a.pwn", 30, "warning", 213),
        ("gamemodes/b.pwn", 5, "fatal error", 100),
    ]
    assert d[0].msg.endswith('"gFoo"') and d[0].is_error and not d[1].is_error


def test_safe_extract():
    with tempfile.TemporaryDirectory() as t:
        t = Path(t)
        good = t / "good.zip"
        with zipfile.ZipFile(good, "w") as z:
            z.writestr("wrap/gamemodes/main.pwn", "x")
        safe_extract(good, t / "out", 10 << 20, 100)
        assert find_root(t / "out") == (t / "out" / "wrap").resolve() or find_root(t / "out").name == "wrap"
        evil = t / "evil.zip"
        with zipfile.ZipFile(evil, "w") as z:
            z.writestr("../evil.txt", "x")
        try:
            safe_extract(evil, t / "out2", 10 << 20, 100)
            raise AssertionError("path traversal не заблокирован")
        except ModError:
            pass
        bomb = t / "bomb.zip"
        with zipfile.ZipFile(bomb, "w", zipfile.ZIP_DEFLATED) as z:
            z.writestr("gamemodes/big.pwn", "A" * (5 << 20))
        try:
            safe_extract(bomb, t / "out3", 1 << 20, 100)
            raise AssertionError("лимит размера не сработал")
        except ModError:
            pass


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn()
            print("ok", name)


def test_includes_case_insensitive():
    from bot.includes import SHIM_DIR, cleanup_includes, prepare_includes

    with tempfile.TemporaryDirectory() as t:
        root = Path(t)
        (root / "gamemodes").mkdir()
        (root / "pawno/include").mkdir(parents=True)
        (root / "gamemodes/m.pwn").write_text('#include <a_samp>\n#include <mxINI>\n#include "Utils\\\\Foo"\n#include <nope>\n')
        (root / "pawno/include/mxini.inc").write_text("//x")
        (root / "gamemodes/utils").mkdir()
        (root / "gamemodes/utils/foo.inc").write_text("//y")
        made, missing = prepare_includes(root)
        assert made and missing == ["nope"]
        assert (root / SHIM_DIR / "mxINI.inc").is_file()
        assert (root / SHIM_DIR / "Utils/Foo.inc").is_file()
        cleanup_includes(root)
        assert not (root / SHIM_DIR).exists()


def test_fix_mixed_return():
    from bot.fixer import _fix_mixed_return

    with tempfile.TemporaryDirectory() as t:
        root = Path(t)
        src = "stock A(x)\r\n{\r\n    if (!x) return;\r\n    return 1;\r\n}\r\nstock B()\r\n{\r\n    return;\r\n}\r\n"
        (root / "a.pwn").write_bytes(src.encode("cp1251"))
        ws = Workspace(root)
        assert _fix_mixed_return(ws, "a.pwn", 4) == 1
        out = (root / "a.pwn").read_bytes().decode("cp1251")
        assert "if (!x) return 0;" in out and "stock B()\r\n{\r\n    return;" in out


def test_checkpoint_revert():
    with tempfile.TemporaryDirectory() as t:
        root = Path(t)
        (root / "a.pwn").write_bytes(b"one")
        (root / "b.pwn").write_bytes(b"bee")
        ws = Workspace(root)
        ws.write("a.pwn", "two")
        cp = ws.checkpoint()
        ws.write("a.pwn", "three")
        ws.write("b.pwn", "new")
        ws.revert_to(cp)
        assert (root / "a.pwn").read_text() == "two" and (root / "b.pwn").read_text() == "bee"
        ws.rollback()
        assert (root / "a.pwn").read_text() == "one"


def test_fix_mixed_return_unindented():
    """Мод без отступов: «if (..) return;» в колонке 0 не должен приниматься за заголовок функции."""
    from bot.fixer import _fix_mixed_return

    with tempfile.TemporaryDirectory() as t:
        root = Path(t)
        src = ("stock A(playerid)\n{\nif(!IsPlayerConnected(playerid)) return;\nSendClientMessage(playerid, -1, \"x\");\n"
               "if(1)\n{\nreturn;\n}\nreturn 1;\n}\nstock B() { return; }\n")
        (root / "a.pwn").write_bytes(src.encode("cp1251"))
        ws = Workspace(root)
        assert _fix_mixed_return(ws, "a.pwn", 9) == 2
        out = (root / "a.pwn").read_text("cp1251")
        assert out.count("return 0;") == 2 and "stock B() { return; }" in out


def test_fix_self_init_and_giant_function():
    from bot.fixer import _fix_mixed_return, _fix_self_init

    with tempfile.TemporaryDirectory() as t:
        root = Path(t)
        src = "cmd:x(playerid)\r\n{\r\n    new to_player = GetPVarInt(to_player, \"k\"); // c\r\n    return 1;\r\n}\r\n"
        (root / "a.pwn").write_bytes(src.encode("cp1251"))
        ws = Workspace(root)
        assert _fix_self_init(ws, "a.pwn", 3, "to_player")
        out = (root / "a.pwn").read_bytes().decode("cp1251")
        assert "    new to_player = 0;\r\n    to_player = GetPVarInt(to_player, \"k\"); // c\r\n" in out

        # функция на 3000 строк: bare return в начале, конфликтующий return 1 — в самом конце
        body = "    if (a) return;\n" + "    x++;\n" * 3000 + "    return 1;\n"
        (root / "b.pwn").write_text("public OnDialogResponse(playerid)\n{\n" + body + "}\n\nstock Z() { return; }\n")
        assert _fix_mixed_return(ws, "b.pwn", 3004) == 1
        o = (root / "b.pwn").read_text()
        assert "if (a) return 0;" in o and "stock Z() { return; }" in o


def test_dup_native_and_ai_guard():
    from bot.fixer import _fix_dup_decl

    with tempfile.TemporaryDirectory() as t:
        root = Path(t)
        (root / "s.inc").write_bytes(b"native A();\r\nnative B(x); // c\r\nstock C() { return 1; }\r\n")
        ws = Workspace(root)
        assert _fix_dup_decl(ws, "s.inc", 1) and _fix_dup_decl(ws, "s.inc", 2)
        assert not _fix_dup_decl(ws, "s.inc", 3)
        out = (root / "s.inc").read_bytes().decode("cp1251")
        assert out.startswith("// [splixbot: дубликат] native A();\r\n")
    from bot.ai import _RISKY
    assert _RISKY.match("#include <streamer>") and _RISKY.match("  native Foo();") and not _RISKY.match("return 1;")
