"""Тесты FTP-заливки: python -m tests.test_ftp  (работают и без установленных aiogram/aiohttp — они подменяются заглушками)."""
from __future__ import annotations

import hashlib
import hmac
import importlib
import json
import socket
import sys
import tempfile
import threading
import time
from pathlib import Path
from types import ModuleType
from unittest.mock import MagicMock
from urllib.parse import urlencode


def _stub_missing() -> None:
    for name in ("aiogram", "aiogram.types", "aiogram.filters", "aiogram.fsm", "aiogram.fsm.context", "aiogram.fsm.state",
                 "aiogram.exceptions", "aiohttp", "aiosqlite", "httpx", "dotenv"):
        try:
            importlib.import_module(name)
        except Exception:
            m = MagicMock()
            m.__path__ = []
            sys.modules[name] = m
    if isinstance(sys.modules.get("aiogram.fsm.state"), MagicMock):
        sys.modules["aiogram.fsm.state"].StatesGroup = object
        sys.modules["aiogram.fsm.state"].State = lambda: object()


_stub_missing()

from bot.ftpdeploy import (  # noqa: E402
    FtpError, FtpTarget, UploadFile, collect, normalize_remote, parse_host, resolve_public, upload_tree,
)


# ---------- мини FTP-сервер ----------
class FakeFtp:
    def __init__(self, user="u", password="p", break_first_stor=False, wrong_size=False):
        self.user, self.password = user, password
        self.files: dict[str, bytes] = {}
        self.dirs: set[str] = set()
        self.break_first = break_first_stor
        self.wrong_size = wrong_size
        self.sock = socket.socket()
        self.sock.bind(("127.0.0.1", 0))
        self.sock.listen(5)
        self.port = self.sock.getsockname()[1]
        self.stop = False
        threading.Thread(target=self._accept, daemon=True).start()

    def _accept(self):
        while not self.stop:
            try:
                c, _ = self.sock.accept()
            except OSError:
                return
            threading.Thread(target=self._serve, args=(c,), daemon=True).start()

    def _serve(self, c: socket.socket):
        f = c.makefile("rwb", buffering=0)
        send = lambda s: f.write((s + "\r\n").encode())  # noqa: E731
        send("220 fake")
        pasv = None
        okuser = False
        while True:
            line = f.readline().decode().strip()
            if not line:
                return
            cmd, _, arg = line.partition(" ")
            cmd = cmd.upper()
            if cmd == "AUTH":
                send("502 no tls")
            elif cmd == "USER":
                okuser = arg == self.user
                send("331 pass")
            elif cmd == "PASS":
                send("230 ok" if okuser and arg == self.password else "530 Login incorrect")
            elif cmd in ("TYPE", "CWD"):
                send("200 ok" if cmd == "TYPE" else ("250 ok" if arg in self.dirs or arg == "/" else "550 no"))
            elif cmd == "MKD":
                if arg in self.dirs:
                    send("550 exists")
                else:
                    self.dirs.add(arg)
                    send(f'257 "{arg}"')
            elif cmd == "PASV":
                pasv = socket.socket()
                pasv.bind(("127.0.0.1", 0))
                pasv.listen(1)
                p = pasv.getsockname()[1]
                send(f"227 Entering Passive Mode (127,0,0,1,{p >> 8},{p & 255})")
            elif cmd == "STOR":
                send("150 go")
                d, _ = pasv.accept()
                data = b""
                while True:
                    chunk = d.recv(65536)
                    if not chunk:
                        break
                    data += chunk
                d.close()
                pasv.close()
                if self.break_first:
                    self.break_first = False
                    c.close()
                    return
                self.files[arg] = data
                send("226 done")
            elif cmd == "SIZE":
                if arg in self.files:
                    send(f"213 {len(self.files[arg]) + (1 if self.wrong_size else 0)}")
                else:
                    send("550 no")
            elif cmd == "QUIT":
                send("221 bye")
                return
            else:
                send("502 nope")


def _tgt(srv: FakeFtp, **kw) -> FtpTarget:
    return FtpTarget("fake.test", srv.port, kw.get("user", "u"), kw.get("password", "p"), kw.get("remote", "/srv"), "127.0.0.1")


def _mod(root: Path) -> None:
    (root / "gamemodes").mkdir(parents=True)
    (root / "gamemodes" / "main.pwn").write_text("main(){}")
    (root / "gamemodes" / "main.amx").write_bytes(b"AMX" * 1000)
    (root / "filterscripts").mkdir()
    (root / "filterscripts" / "a.amx").write_bytes(b"x" * 10)
    (root / ".incshim").mkdir()
    (root / ".incshim" / "junk.inc").write_text("x")
    (root / "link").symlink_to(root / "gamemodes")


def _run(srv, files, tgt=None, cancel=None):
    logs: list[tuple[str, str]] = []
    prog: list[tuple] = []
    res = upload_tree(tgt or _tgt(srv), files, lambda lv, m: logs.append((lv, m)), lambda *a: prog.append(a), cancel or threading.Event())
    return res, logs, prog


# ---------- тесты ----------
def test_parse_host():
    assert parse_host("185.12.34.56") == ("185.12.34.56", 21, "")
    assert parse_host("ftp://Host.Example.ru:2121/gm/x") == ("host.example.ru", 2121, "/gm/x")
    for bad in ("", "sftp://h", "u:p@h", "h:abc", "h:22", "bad host", "[::1]", "h:80", "-x.com"):
        try:
            parse_host(bad)
        except FtpError:
            continue
        raise AssertionError(f"должно было отклонить: {bad!r}")


def test_normalize_remote():
    assert normalize_remote("") == "/" and normalize_remote("a//b/./c/") == "/a/b/c" and normalize_remote("\\a\\b") == "/a/b"
    for bad in ("../x", "a/../../b", "a\nb"):
        try:
            normalize_remote(bad)
        except FtpError:
            continue
        raise AssertionError(bad)


def test_ssrf_blocked():
    for ip in ("127.0.0.1", "10.0.0.5", "192.168.1.1", "172.17.0.2", "169.254.169.254", "0.0.0.0", "100.64.0.1"):
        try:
            resolve_public(ip, 21)
        except FtpError:
            continue
        raise AssertionError(f"SSRF: {ip} пропущен")
    assert resolve_public("8.8.8.8", 21) == "8.8.8.8"


def test_collect():
    with tempfile.TemporaryDirectory() as t:
        root = Path(t)
        _mod(root)
        rels = sorted(f.rel for f in collect(root))
        assert rels == ["filterscripts/a.amx", "gamemodes/main.amx", "gamemodes/main.pwn"], rels  # без .incshim и симлинка
        assert [f.rel for f in collect(root, "gamemodes/main.amx")] == ["gamemodes/main.amx"]
        try:
            collect(root, "nope.amx")
            raise AssertionError
        except FtpError:
            pass


def test_upload_ok_and_dirs():
    srv = FakeFtp()
    with tempfile.TemporaryDirectory() as t:
        root = Path(t)
        _mod(root)
        files = collect(root)
        res, logs, prog = _run(srv, files)
        assert res.files == 3 and not res.secure
        assert srv.files["/srv/gamemodes/main.amx"] == b"AMX" * 1000
        assert {"/srv", "/srv/gamemodes", "/srv/filterscripts"} <= srv.dirs
        assert prog[-1][0] == prog[-1][1] == res.bytes and prog[-1][2] == 3
        assert any("без шифрования" in m or "не поддерживает шифрование" in m for _, m in logs)
    srv.stop = True


def test_bad_password_and_unreachable():
    srv = FakeFtp()
    try:
        _run(srv, [UploadFile(Path(__file__), "a.py", 1)], _tgt(srv, password="WRONG"))
        raise AssertionError
    except FtpError as e:
        assert "530" in str(e) and "WRONG" not in str(e)
    dead = socket.socket()
    dead.bind(("127.0.0.1", 0))
    port = dead.getsockname()[1]
    dead.close()
    try:
        _run(srv, [UploadFile(Path(__file__), "a.py", 1)], FtpTarget("x", port, "u", "p", "/", "127.0.0.1"))
        raise AssertionError
    except FtpError as e:
        assert "подключиться" in str(e)
    srv.stop = True


def test_retry_after_dropped_connection():
    srv = FakeFtp(break_first_stor=True)
    with tempfile.TemporaryDirectory() as t:
        root = Path(t)
        _mod(root)
        res, logs, _ = _run(srv, collect(root, "gamemodes/main.amx"))
        assert res.files == 1 and srv.files["/srv/gamemodes/main.amx"] == b"AMX" * 1000
        assert any("повтор" in m for _, m in logs)
    srv.stop = True


def test_size_mismatch_fails_after_retries():
    srv = FakeFtp(wrong_size=True)
    with tempfile.TemporaryDirectory() as t:
        root = Path(t)
        _mod(root)
        try:
            _run(srv, collect(root, "gamemodes/main.amx"))
            raise AssertionError
        except FtpError as e:
            assert "main.amx" in str(e)
    srv.stop = True


def test_cancel():
    srv = FakeFtp()
    ev = threading.Event()
    ev.set()
    with tempfile.TemporaryDirectory() as t:
        root = Path(t)
        _mod(root)
        try:
            _run(srv, collect(root), cancel=ev)
            raise AssertionError
        except FtpError as e:
            assert "Остановлено" in str(e)
    srv.stop = True


def test_job_masks_password_and_snapshot():
    from bot.deploy import Job

    j = Job(1, "h:21", "/", False)
    j._secret = "SuperSecret!"
    j.add("err", "login failed for SuperSecret! at host")
    snap = j.snapshot(0)
    assert "SuperSecret" not in json.dumps(snap) and "••••" in snap["log"][0]["m"]
    j.add("info", "x")
    assert [x["i"] for x in j.snapshot(1)["log"]] == [2] and "SuperSecret" not in j.full_log_text()


def _sign(token: str, fields: dict) -> str:
    check = "\n".join(f"{k}={v}" for k, v in sorted(fields.items()))
    secret = hmac.new(b"WebAppData", token.encode(), hashlib.sha256).digest()
    return urlencode({**fields, "hash": hmac.new(secret, check.encode(), hashlib.sha256).hexdigest()})


def test_init_data():
    from bot.webapp import verify_init_data

    tok = "123:ABC"
    f = {"auth_date": str(int(time.time())), "user": json.dumps({"id": 42, "first_name": "Я"}), "query_id": "q"}
    good = _sign(tok, f)
    assert verify_init_data(good, tok)["id"] == 42
    assert verify_init_data(good, "999:OTHER") is None  # чужой токен
    assert verify_init_data(good.replace("42", "43"), tok) is None  # подмена id
    assert verify_init_data(_sign(tok, {**f, "auth_date": str(int(time.time()) - 90000)}), tok) is None  # протухло
    assert verify_init_data("", tok) is None and verify_init_data("hash=abc", tok) is None


def test_screens_fit_caption():
    from bot.deploy import Job
    from bot.handlers_ftp import _final, _running_text
    from bot.ui import HELP_TEXT, fits

    j = Job(1, "very-long-hostname.example-hosting.com:2121", "/a/b", False)
    for i in range(8):
        j.add("info", "↑ filterscripts/very_long_directory_name/some_really_long_file_name_system.amx · 1.2 МБ")
    j.stage, j.pct, j.files_total, j.bytes_total, j.files_done, j.bytes_done = "upload", 63, 800, 90 << 20, 500, 55 << 20
    assert fits(_running_text(j)), len(_running_text(j))
    j.state, j.error = "failed", "Не удалось залить filterscripts/xxx.amx: " + "очень длинная ошибка " * 30
    assert fits(_final(j)[0]), len(_final(j)[0])
    j.state, j.result, j.finished = "ok", {"files": 800, "bytes": 90 << 20, "speed": 3 << 20, "secure": True}, time.time()
    assert fits(_final(j)[0])
    assert fits(HELP_TEXT), len(HELP_TEXT)


if __name__ == "__main__":
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    n = 0
    for k, v in sorted(globals().items()):
        if k.startswith("test_") and callable(v):
            v()
            n += 1
            print("ok", k)
    print(f"{n} тестов пройдено")
