"""Генератор баннеров для разделов бота: HTML → JPG (Playwright + Chromium).

Запуск (нужен playwright с chromium):
    python tools/make_banners.py
Результат — bot/assets/*.jpg (1280×640). Уже сгенерированные файлы лежат в репозитории,
этот скрипт нужен только если хочешь поменять тексты/цвета.
"""
from __future__ import annotations

import sys
from pathlib import Path

OUT = Path(__file__).resolve().parent.parent / "bot" / "assets"

# key: (заголовок, подзаголовок, цвет1, цвет2, иконка, «кодовая» строка-декор)
ICONS = {
    "pawn": '<circle cx="12" cy="6.3" r="3"/><rect x="8.3" y="9.8" width="7.4" height="1.8" rx=".9"/><path d="M9.6 11.6c0 2.9-1.1 4.2-2.6 6h10c-1.5-1.8-2.6-3.1-2.6-6"/><rect x="5.3" y="17.6" width="13.4" height="2.9" rx="1.2"/>',
    "lock": '<rect x="5" y="11" width="14" height="9.5" rx="2.2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/><circle cx="12" cy="15.7" r="1.1"/>',
    "gift": '<rect x="3.5" y="8" width="17" height="4" rx="1.2"/><path d="M5 12v8h14v-8"/><path d="M12 8v12"/><path d="M12 8C11 4.6 7 4.6 7 6.8 7 8 9 8 12 8zM12 8c1-3.4 5-3.4 5-1.2C17 8 15 8 12 8z"/>',
    "users": '<circle cx="9" cy="8" r="3.2"/><path d="M3 20c0-3.5 2.7-6 6-6s6 2.5 6 6"/><circle cx="17" cy="9" r="2.5"/><path d="M17 14c2.5 0 4.5 2 4.5 5"/>',
    "box": '<path d="M12 3l8.5 4.5v9L12 21l-8.5-4.5v-9z"/><path d="M3.5 7.5L12 12l8.5-4.5"/><path d="M12 12v9"/>',
    "blocks": '<rect x="3.5" y="3.5" width="7" height="7" rx="1.6"/><rect x="3.5" y="13.5" width="7" height="7" rx="1.6"/><rect x="13.5" y="13.5" width="7" height="7" rx="1.6"/><path d="M17 3.5v7M13.5 7h7"/>',
    "terminal": '<rect x="3" y="4.5" width="18" height="15" rx="2.6"/><path d="M7 10l3 2.5L7 15"/><path d="M12.5 15.5H17"/>',
    "check": '<circle cx="12" cy="12" r="9"/><path d="M7.8 12.4l2.9 2.9 5.6-6"/>',
    "x": '<circle cx="12" cy="12" r="9"/><path d="M9 9l6 6M15 9l-6 6"/>',
    "shield": '<path d="M12 3l7.5 3v5.5c0 4.5-3.2 8-7.5 9.5-4.3-1.5-7.5-5-7.5-9.5V6z"/><path d="M9 12l2.2 2.2L15.5 10"/>',
    "chart": '<rect x="4" y="11" width="3.5" height="9" rx="1.1"/><rect x="10.2" y="4" width="3.5" height="16" rx="1.1"/><rect x="16.5" y="8" width="3.5" height="12" rx="1.1"/>',
    "send": '<path d="M21 3L10 14"/><path d="M21 3l-6.5 18-3.5-7.5L3.5 10z"/>',
    "ticket": '<path d="M3.5 7.5h17v3a2 2 0 0 0 0 3v3h-17v-3a2 2 0 0 0 0-3z"/><path d="M14 7.5v9" stroke-dasharray="2 2"/>',
    "coin": '<circle cx="12" cy="12" r="9"/><path d="M14.8 9.2c-.5-1-1.6-1.6-2.8-1.6-1.6 0-2.8.9-2.8 2.1 0 3 5.8 1.4 5.8 4.3 0 1.2-1.3 2.1-3 2.1-1.3 0-2.4-.6-3-1.7"/><path d="M12 6v1.6M12 16.4V18"/>',
    "db": '<ellipse cx="12" cy="6" rx="7.5" ry="3"/><path d="M4.5 6v6c0 1.7 3.4 3 7.5 3s7.5-1.3 7.5-3V6"/><path d="M4.5 12v6c0 1.7 3.4 3 7.5 3s7.5-1.3 7.5-3v-6"/>',
    "crown": '<path d="M3.5 18.5L2.5 7.5 8 12l4-7 4 7 5.5-4.5-1 11z"/>',
    "bolt": '<path d="M13 2.5L5 13.5h6l-1 8 8-11h-6z"/>',
    "user": '<circle cx="12" cy="8" r="4"/><path d="M4.5 20.5c0-4 3.4-6.5 7.5-6.5s7.5 2.5 7.5 6.5"/>',
    "server": '<rect x="3.5" y="4" width="17" height="6.2" rx="2"/><rect x="3.5" y="13.8" width="17" height="6.2" rx="2"/><circle cx="7.4" cy="7.1" r=".9"/><circle cx="7.4" cy="16.9" r=".9"/><path d="M11.5 7.1h5M11.5 16.9h5"/>',
    "upload": '<path d="M7.5 17.5a4.6 4.6 0 0 1-.6-9.1 5.6 5.6 0 0 1 10.7 1.4A3.9 3.9 0 0 1 17 17.5"/><path d="M12 20.5v-9"/><path d="M8.6 14.6L12 11.2l3.4 3.4"/>',
    "help": '<circle cx="12" cy="12" r="9"/><path d="M9.3 9.5a2.8 2.8 0 0 1 5.4 1c0 1.8-2.7 2.2-2.7 3.9"/><circle cx="12" cy="17.3" r=".7"/>',
}

BANNERS = {
    "menu":    ("Pawn Forge", "Куём моды SA-MP и CRMP без боли", "#8b5cf6", "#22d3ee", "pawn", ["public OnGameModeInit()", "{", "    print(\"forged.\");", "    return 1;", "}"]),
    "locked":  ("Доступ закрыт", "Нужен промокод или друзья", "#f43f5e", "#f59e0b", "lock", ["if (balance <= 0)", "    return ACCESS_DENIED;"]),
    "promo":   ("Промокод", "Активируй и получай запросы", "#f59e0b", "#ec4899", "gift", ["new code[32];", "ActivatePromo(playerid, code);"]),
    "ref":     ("Друзья", "+2 запроса за каждых 5 приглашённых", "#10b981", "#22d3ee", "users", ["forward OnFriendJoin(id);", "ref_count += 1;"]),
    "mod":     ("Новый мод", "Отправь архив .zip с gamemodes", "#3b82f6", "#8b5cf6", "box", ["#include <a_samp>", "main() { print(\"mod\"); }"]),
    "system":  ("Новая система", "Вшью .pwn / .inc одним сообщением", "#a855f7", "#ec4899", "blocks", ["#include <systems/new>", "s1_OnPlayerConnect(playerid);"]),
    "work":    ("В работе", "Собираю, чиню, собираю снова", "#06b6d4", "#3b82f6", "bolt", ["pawncc -S4096 -O1 -v2", "Compile... attempt 1"]),
    "ok":      ("Готово!", "Мод собран, .amx уже летит к тебе", "#22c55e", "#a3e635", "check", ["Header size: 2208 bytes", "Done."]),
    "fail":    ("Не вышло", "Изменения откачены, запрос цел", "#ef4444", "#f97316", "x", ["error 017: undefined symbol", "Compilation aborted."]),
    "admin":   ("Админ-панель", "Всё под контролем", "#6366f1", "#06b6d4", "shield", ["admin.level = OWNER;", "Panel_Open(playerid);"]),
    "stats":   ("Статистика", "Цифры бота в реальном времени", "#22d3ee", "#8b5cf6", "chart", ["users: 1024", "online: 37"]),
    "bc":      ("Рассылка", "Сообщение всем пользователям", "#ec4899", "#f59e0b", "send", ["foreach (new i : Player)", "    SendClientMessage(i, -1, msg);"]),
    "sub":     ("Подписка", "Обязательные каналы (ОП)", "#14b8a6", "#3b82f6", "lock", ["CheckSubscription(uid);", "return channel_ok;"]),
    "promos":  ("Промокоды", "Генератор кодов для раздачи", "#f59e0b", "#ef4444", "ticket", ["promo[\"SUMMER\"] = 5;", "max_uses = 50;"]),
    "bal":     ("Баланс", "Выдача запросов пользователям", "#eab308", "#22c55e", "coin", ["GivePlayerMoney(id, 10);", "balance += n;"]),
    "dump":    ("База модов", "Все загруженные архивы", "#0ea5e9", "#6366f1", "db", ["SELECT * FROM mods;", "LIMIT 8 OFFSET 0;"]),
    "admins":  ("Админы", "Кому доверено управление", "#f59e0b", "#8b5cf6", "crown", ["new admins[MAX_ADMINS];", "toggle_admin(uid);"]),
    "profile": ("Профиль", "Твой баланс, моды и награды", "#8b5cf6", "#ec4899", "user", ["PlayerInfo[playerid][pLevel] = 1;", "SavePlayer(playerid);"]),
    "ftp":     ("Залить на FTP", "Хост, логин, пароль — и мод на сервере", "#8b5cf6", "#22d3ee", "server", ["ftp.connect(host, 21);", "ftp.login(user, ***);", "ftp.upload(\"gamemodes/\");"]),
    "deploy":  ("Заливаю…", "Собираю мод и гоню файлы на сервер", "#06b6d4", "#8b5cf6", "upload", ["STOR gamemodes/main.amx", "226 Transfer complete."]),
    "ftpok":   ("Мод залит!", "Сервер обновлён — можно рестартить", "#22c55e", "#22d3ee", "upload", ["226 Transfer complete.", "221 Goodbye."]),
    "help":    ("Как это работает", "Три шага от архива до .amx", "#3b82f6", "#14b8a6", "help", ["// 1. загрузи мод", "// 2. вшей систему", "// 3. забери .amx"]),
}

TEMPLATE = """<!doctype html><html><head><meta charset="utf-8"><style>
*{{box-sizing:border-box;margin:0;padding:0}}
html,body{{width:1280px;height:640px;overflow:hidden;background:#070913;font-family:'Inter','Roboto',sans-serif;color:#fff}}
.bg{{position:absolute;inset:0;
 background:
  radial-gradient(900px 560px at 88% 8%, {c1}55 0%, transparent 62%),
  radial-gradient(760px 520px at 6% 105%, {c2}44 0%, transparent 60%),
  linear-gradient(135deg,#0a0d1c 0%,#070913 60%,#0b0b1a 100%)}}
.grid{{position:absolute;inset:0;
 background-image:linear-gradient(rgba(255,255,255,.055) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.055) 1px,transparent 1px);
 background-size:56px 56px;
 -webkit-mask-image:radial-gradient(ellipse 80% 90% at 70% 40%,#000 0%,transparent 75%)}}
.code{{position:absolute;left:84px;bottom:58px;font:500 21px/1.55 'DejaVu Sans Mono',monospace;color:rgba(255,255,255,.17);white-space:pre}}
.chip{{position:absolute;left:84px;top:70px;display:flex;align-items:center;gap:14px;padding:11px 22px 11px 14px;border-radius:999px;
 background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.14);backdrop-filter:blur(8px);
 font:700 20px 'Inter';letter-spacing:.22em;color:rgba(255,255,255,.88)}}
.chip svg{{width:30px;height:30px;stroke:url(#g);fill:none;stroke-width:1.9;stroke-linecap:round;stroke-linejoin:round}}
h1{{position:absolute;left:84px;top:176px;width:720px;font:800 {fs}px/1.04 'Inter';letter-spacing:-.025em;
 background:linear-gradient(100deg,#fff 30%,{c2} 130%);-webkit-background-clip:text;color:transparent;padding-bottom:18px}}
.sub{{position:absolute;left:86px;top:{subtop}px;width:700px;font:500 33px/1.35 'Inter';color:rgba(255,255,255,.66)}}
.bar{{position:absolute;left:86px;top:{bartop}px;width:150px;height:7px;border-radius:9px;background:linear-gradient(90deg,{c1},{c2})}}
.orb{{position:absolute;right:112px;top:120px;width:400px;height:400px}}
.ring{{position:absolute;border-radius:50%;border:1.5px solid rgba(255,255,255,.12)}}
.tile{{position:absolute;left:70px;top:70px;width:260px;height:260px;border-radius:70px;
 background:linear-gradient(145deg,rgba(255,255,255,.17),rgba(255,255,255,.04));
 border:1.5px solid rgba(255,255,255,.28);
 box-shadow:0 30px 80px {c1}66,0 0 0 14px rgba(255,255,255,.035),inset 0 2px 0 rgba(255,255,255,.35);
 display:flex;align-items:center;justify-content:center;transform:rotate(-6deg)}}
.tile svg{{width:148px;height:148px;stroke:url(#g);fill:none;stroke-width:1.55;stroke-linecap:round;stroke-linejoin:round;filter:drop-shadow(0 0 18px {c1}aa)}}
.dot{{position:absolute;border-radius:50%;background:linear-gradient(135deg,{c1},{c2});box-shadow:0 0 20px {c1}}}
.ghost{{position:absolute;right:-60px;bottom:-90px;width:560px;height:560px;opacity:.07;stroke:#fff;fill:none;stroke-width:.5;stroke-linecap:round;stroke-linejoin:round}}
</style></head><body>
<svg width="0" height="0" style="position:absolute"><defs>
<linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="{c1}"/><stop offset="1" stop-color="{c2}"/></linearGradient>
<linearGradient id="gw" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff"/><stop offset="1" stop-color="{c2}"/></linearGradient>
</defs></svg>
<div class="bg"></div><div class="grid"></div>
<svg class="ghost" viewBox="0 0 24 24">{pawn}</svg>
<div class="code">{code}</div>
<div class="chip"><svg viewBox="0 0 24 24">{pawn}</svg>PAWN FORGE</div>
<h1>{title}</h1>
<div class="bar"></div>
<div class="sub">{sub}</div>
<div class="orb">
 <div class="ring" style="inset:0"></div>
 <div class="ring" style="inset:-46px;opacity:.55"></div>
 <div class="ring" style="inset:-96px;opacity:.28"></div>
 <div class="dot" style="width:18px;height:18px;left:-8px;top:190px"></div>
 <div class="dot" style="width:11px;height:11px;right:-4px;top:60px"></div>
 <div class="dot" style="width:14px;height:14px;left:150px;bottom:-60px"></div>
 <div class="tile"><svg viewBox="0 0 24 24">{icon}</svg></div>
</div>
</body></html>"""


def build_html(key: str) -> str:
    title, sub, c1, c2, icon, code = BANNERS[key]
    fs = 112 if len(title) <= 10 else 92 if len(title) <= 14 else 76
    lines = 2 if len(title) * fs * 0.56 > 700 else 1
    h = int(fs * 1.04 * lines) + 8
    top = 176
    return TEMPLATE.format(
        title=title, sub=sub, c1=c1, c2=c2, fs=fs, icon=ICONS[icon], pawn=ICONS["pawn"],
        code="\n".join(code), subtop=top + h + 40, bartop=top + h + 12,
    )


def main(only: list[str] | None = None) -> None:
    from playwright.sync_api import sync_playwright

    OUT.mkdir(parents=True, exist_ok=True)
    keys = only or list(BANNERS)
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page(viewport={"width": 1280, "height": 640}, device_scale_factor=1)
        for k in keys:
            page.set_content(build_html(k), wait_until="load")
            page.wait_for_timeout(120)
            page.screenshot(path=str(OUT / f"{k}.jpg"), type="jpeg", quality=93)
            print("ok", k)
        browser.close()


if __name__ == "__main__":
    main(sys.argv[1:] or None)
